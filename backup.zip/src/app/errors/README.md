# 🛡️ Errors

Централизованная обработка исключений в боте.

## Зачем

- Единая точка перехвата ошибок.
- Преобразование ошибок библиотек в доменные `AppError`.
- Безопасные сообщения пользователю (`UserVisibleError`).
- Богатые структурированные логи (код ошибки, URL, статус).

## Состав
```bash
errors/
├─ init.py                 # экспорт публичного API
├─ custom_errors.py            # AppError / UserVisibleError + AI/Parsing/Network
├─ strategies.py               # стратегии: OpenAI, httpx, Telegram, …
├─ exception_handler_service.py# диспетчер, использующий стратегии
└─ error_handler.py            # фабрика декораторов для async-хендлеров
```

## Использование

```python
from app.errors import ExceptionHandlerService, make_error_handler
from app.errors.strategies import OpenAIErrorStrategy, HttpxErrorStrategy, TelegramErrorStrategy

# DI
error_service = ExceptionHandlerService([
    OpenAIErrorStrategy(),
    HttpxErrorStrategy(),
    TelegramErrorStrategy(),
])

error_handler = make_error_handler(error_service)

@error_handler
async def on_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ...
```

## Принципы
	•	OCP: добавляйте новую стратегию — не меняя сервис.
	•	SRP: ошибки описывают контекст; сервис только маршрутизирует.
	•	Никогда не «глотаем» asyncio.CancelledError.