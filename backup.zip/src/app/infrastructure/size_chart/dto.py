# app/infrastructure/size_chart/dto.py
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Optional


class SizeChartOcrStatus(str, Enum):
    OK = "ok"
    TIMEOUT = "timeout"
    INVALID_JSON = "invalid_json"
    API_ERROR = "api_error"
    IO_ERROR = "io_error"        # не смогли прочитать файл
    EMPTY = "empty"              # пустой ответ/данных нет


@dataclass
class SizeChartOcrResult:
    status: SizeChartOcrStatus
    data: Optional[Dict[str, Any]] = None
    raw_text: Optional[str] = None
    error: Optional[str] = None  # краткий код/сообщение для логов

    @property
    def ok(self) -> bool:
        return self.status == SizeChartOcrStatus.OK and isinstance(self.data, dict) and bool(self.data)