"""
📦 content — инфраструктурные сервисы, связанные с товарным контентом.

Включает:
    • GenderClassifier — классификация гендера по артикулу.
    • HashtagGenerator — генерация хештегов на основі правил + AI.
    • ProductContentService — агрегация текстового/медийного контента.
    • ProductHeaderService — лёгкий заголовок товара (title + img + url).
"""

from .gender_classifier import GenderClassifier
from .hashtag_generator import HashtagGenerator
from .product_content_service import ProductContentService, ProductContentDTO
from .product_header_service import ProductHeaderService, ProductHeaderDTO

__all__ = [
    "GenderClassifier",
    "HashtagGenerator",
    "ProductContentService",
    "ProductContentDTO",
    "ProductHeaderService",
    "ProductHeaderDTO",
]