# 🎨 app/bot/ui/message_formatter.py
"""
🎨 message_formatter.py — форматує дані про товар у HTML‑повідомлення (без бізнес‑логіки).

🔹 Клас `MessageFormatter`:
- Форматує поля товару у безпечний для HTML вигляд (parse_mode="HTML").
- Додає маркер SOLD OUT, якщо всі варіанти недоступні.
- Гарантує просту та валідну HTML‑структуру без «крихких» тегів.

⚙️ Принципи:
    • SRP — лише форматування тексту для UI;
    • KISS/DRY — мінімум умов та повторів, жодних зовнішніх залежностей;
    • Безпека — екранування потенційно небезпечних символів.
"""

# 🔠 Системні імпорти
from __future__ import annotations
from html import escape													# 🛡️ Екранування HTML-символів для безпеки
from typing import Final													# 🧰 Імм'ютабельні константи з підказками типів

# 🧩 Внутрішні модулі проєкту
from app.infrastructure.content.product_content_service import (
    ProductContentDTO,
)																		# 📦 DTO з даними про товар (title, sections, colors_text тощо)


# ==========================
# 🔧 КОНСТАНТИ МОДУЛЯ
# ==========================
_LBL_MATERIAL: Final[str] = "МАТЕРІАЛ"												# 🏷️ Ключ для секції «Матеріал»
_LBL_FIT: Final[str] = "ПОСАДКА"													# 🏷️ Ключ для секції «Посадка»
_LBL_DESC: Final[str] = "ОПИС"													# 🏷️ Ключ для секції «Опис»
_LBL_MODEL: Final[str] = "МОДЕЛЬ"													# 🏷️ Ключ для секції «Модель»
_MAX_SECTION_LEN: Final[int] = 2000												# 📏 Максимальна довжина будь-якої секції
_MAX_TITLE_LEN: Final[int] = 256													# 📏 Невеликий ліміт для заголовка (телеграмне обмеження)


# ==========================
# 🖼️ ФОРМАТУВАЛЬНИК ПОВІДОМЛЕНЬ
# ==========================
class MessageFormatter:
    """Виключно форматування фінального повідомлення для Telegram (parse_mode='HTML')."""

    # --------------------------
    # 🔎 ХЕЛПЕРИ СТАНУ НАЛИЧНОСТІ
    # --------------------------
    @staticmethod
    def is_fully_sold_out(colors_text: str) -> bool:
        """True, якщо кожен непорожній рядок у блоці кольорів містить «❌».

        Це проста евристика: якщо користувач бачить список варіантів кольорів/розмірів,
        і кожен з них позначений як недоступний — вважаємо, що товар розпроданий.
        """
        if not colors_text or not colors_text.strip():
            return False													# 🟡 Порожній блок не вважаємо SOLD OUT
        lines = [ln for ln in colors_text.splitlines() if ln.strip()]
        return bool(lines) and all("❌" in ln for ln in lines)						# ✅ Всі рядки містять «❌» → розпродано

    # --------------------------
    # 🧼 САНІТАЙЗЕРИ ТЕКСТУ
    # --------------------------
    @staticmethod
    def _sanitize_text(value: str | None, *, max_len: int = _MAX_SECTION_LEN) -> str:
        """Екранує HTML та мʼяко обрізає довгі рядки до `max_len`.

        • None/порожнє → «Немає даних»;
        • тримінг по краях;
        • safe HTML через `html.escape` з `quote=True`.
        """
        if not value:
            return "Немає даних"													# 🔕 Немає даних — нейтральний плейсхолдер
        trimmed = value.strip()
        if len(trimmed) > max_len:
            trimmed = trimmed[: max_len - 1] + "…"								# ✂️ Обрізаємо з еліпсисом наприкінці
        return escape(trimmed, quote=True)										# 🛡️ HTML-safe текст для Telegram HTML

    @staticmethod
    def _sanitize_title(title: str | None) -> str:
        """Екранує заголовок, застосовує ліміт та приводить до UPPER-case."""
        safe = MessageFormatter._sanitize_text(title, max_len=_MAX_TITLE_LEN)
        return safe.upper()													# 🔠 Візуально виділяємо шапку

    # --------------------------
    # 🧩 ГОЛОВНИЙ ФОРМАТЕР
    # --------------------------
    @staticmethod
    def format_description(data: ProductContentDTO) -> str:
        """📝 Повертає готовий HTML для `parse_mode='HTML'`.

        Не додає бізнес‑логіки: лише безпечне форматування та компактна верстка.
        """
        # 1) Безпечно готуємо секції (екранування + обрізання)
        material = MessageFormatter._sanitize_text(data.sections.get(_LBL_MATERIAL))		# 🧵 Матеріал
        fit = MessageFormatter._sanitize_text(data.sections.get(_LBL_FIT))				# 🧍 Посадка
        description = MessageFormatter._sanitize_text(data.sections.get(_LBL_DESC))		# 📄 Опис
        model = MessageFormatter._sanitize_text(data.sections.get(_LBL_MODEL))			# 🧑‍🎤 Модель (параметри, зріст тощо)
        colors_block = MessageFormatter._sanitize_text(data.colors_text)				# 🎨 Блок доступних/недоступних кольорів

        # 2) Заголовок: UPPER + префікс, якщо все SOLD OUT
        title_safe = MessageFormatter._sanitize_title(data.title)
        is_sold_out = MessageFormatter.is_fully_sold_out(data.colors_text or "")
        title_display = f"❌ РОЗПРОДАНО ❌\n\n{title_safe}" if is_sold_out else title_safe	# 🚩 Маркуємо як розпродано (вище заголовка)

        # 3) Додаткові блоки: слоган та хештеги — теж очищуємо
        slogan_safe = MessageFormatter._sanitize_text(data.slogan)						# ✨ Короткий меседж/слоган
        hashtags_safe = MessageFormatter._sanitize_text(data.hashtags)					# #Хештеги без HTML‑символів

        # 4) Фінальна HTML‑верстка: проста, без нестійких тегів, дружня до Telegram
        return (
            f"<b>{title_display}:</b>\n\n"
            f"<b>{_LBL_MATERIAL}:</b> {material}\n"
            f"<b>{_LBL_FIT}:</b> {fit}\n"
            f"<b>{_LBL_DESC}:</b> {description}\n\n"
            f"{colors_block}\n\n"
            f"<b>{_LBL_MODEL}:</b> {model}\n\n"
            f"<b>{slogan_safe}</b>\n\n"
            f"<b>{hashtags_safe}</b>"
        )
