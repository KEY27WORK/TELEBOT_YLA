# 🚻 app/infrastructure/content/gender_classifier.py
"""
🚻 gender_classifier.py — сервіс для визначення гендеру за артикулом товару.
"""

import logging
from typing import List, Dict

from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


class GenderClassifier:
    """
    🚻 Визначає гендерні хештеги на основі префікса артикула товару,
    використовуючи правила з конфігурації (наприклад: 'W' → жінки).
    """

    def __init__(self, gender_rules: Dict[str, List[str]]) -> None:
        """
        Args:
            gender_rules: словник, де ключ — префікс, а значення — список хештегів.
        """
        self.gender_rules = gender_rules

    def classify(self, article: str) -> List[str]:
        """
        Повертає список гендерних хештегів для переданого артикула.
        """
        for prefix, tags in self.gender_rules.items():
            if prefix != "default" and article.startswith(prefix):
                logger.info("🚻 Префікс '%s' → гендерні теги знайдено", prefix)
                return tags

        logger.info("👨‍🦱 Fallback: використано стандартні чоловічі хештеги.")
        return self.gender_rules.get("default", [])


__all__ = ["GenderClassifier"]