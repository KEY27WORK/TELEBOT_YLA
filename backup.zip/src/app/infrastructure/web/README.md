# 🌍 Модуль `web`

Модуль `web` відповідає за **стабільне та асинхронне завантаження HTML-сторінок** з сайту YoungLA з використанням **Playwright**.

Це незалежний інфраструктурний компонент, який використовується всіма парсерами (`BaseParser`, `UniversalCollectionParser` тощо) для забезпечення:

- ізольованих вкладок для кожного запиту  
- обходу Cloudflare через `playwright_stealth`  
- автоматичних повторних спроб  
- конфігурації через `config.yaml`  

---

## 📂 Структура

```bash
📦 web
 ┣ 📜 README.md              # Поточний файл
 ┣ 📜 __init__.py            # Експортує WebDriverService
 ┗ 📜 webdriver_service.py   # Реалізація клієнта Playwright
```

---

## 🔍 Призначення

- Завантаження HTML через Chromium (в headless-режимі)  
- Повторні спроби при виявленні захисту Cloudflare  
- Створення нової вкладки (`Page`) на кожен запит  
- Обхід антибот-захисту через `playwright_stealth`  
- Використання кастомного `User-Agent`  

---

## 📦 Основний компонент

### `webdriver_service.py`

- **DI-архітектура**: сервіс створюється через контейнер залежностей.  
- **Ізоляція**: кожен запит — окрема вкладка, без спільних cookie.  
- **Обхід Cloudflare**: використовує `stealth_async` та перевірку HTML-контенту.  
- **Retry-логіка**: при виявленні Cloudflare — до N спроб (з `config.yaml`).  
- **Асинхронне керування ресурсами**: lifecycle контролюється через `startup()` та `shutdown()`.  

---

## ✅ Архітектурні принципи

| Принцип        | Деталі |
|----------------|--------|
| SRP            | Відповідає **лише** за завантаження HTML (без парсингу). |
| DI-Driven      | Інʼєкція `ConfigService` через конструктор. |
| Config-Driven  | Усі параметри читаються з `config.yaml`. |
| Async-Only     | Побудовано на `asyncio` та `async_playwright`. |
| Fail-Safe      | Використовує fallback-значення для Cloudflare. |

---

## ⚙️ Конфігурація (фрагмент `config.yaml`)

```yaml
playwright:
  headless: true
  user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)..."
  retry_attempts: 5
  retry_delay_sec: 2
  cloudflare_phrases:
    - "Your connection needs to be verified"
    - "Please complete the security check"
    - "Verifying you are human"
```

---

📌 **Використання**:  
WebDriverService інʼєктується у всі парсери через **DI-контейнер**.  
У тестах можна підмінити його на мок, що повертає HTML напряму (без браузера).  
