from __future__ import annotations

"""
Генератор адаптивної таблиці розмірів.

— Масштабує шрифти залежно від вмісту
— Центрує таблицю на полотні
— Підлаштовується під кількість параметрів і ширину
— Використовує TableGeometryService для геометрії та FontService для стилю
"""

import logging
from typing import Dict, List

from app.shared.utils.logger import LOG_NAME
from app.infrastructure.size_chart.services import TableGeometryService
from app.infrastructure.image_generation.font_service import FontService
from app.domain.image_generation.interfaces import FontType, FontLike
from .base_generator import BaseTableGenerator

logger = logging.getLogger(LOG_NAME)


class UniqueTableGenerator(BaseTableGenerator):
    """Адаптивная таблица (параметры → размеры) с расчётом геометрии."""

    def __init__(self, size_chart: dict, output_path: str, font_service: FontService, **kwargs) -> None:
        super().__init__(size_chart, output_path, font_service, **kwargs)

        if not self.headers:
            logger.warning("⚠️ Поле 'Розмір' пусте! Використовуються стандартні розміри.")
            self.headers = ["S", "M", "L", "XL", "XXL"]

        self.base_font_size: int = 38
        self.param_cell_font: FontLike = self.font_service.get_font(FontType.BOLD, self.base_font_size)

        # заповняться під час _calculate_layout
        self.first_col_width = 0
        self.other_col_width = 0
        self.column_spacing = 0
        self.cell_height = 0
        self.title_font_size = 0
        self.padding_inside = 0

        self.header_font: FontLike = self.param_cell_font
        self.value_cell_font: FontLike = self.param_cell_font
        self.title_font: FontLike = self.param_cell_font

        self.table_height = 0
        self.table_y = 0
        self.table_start_x = self.PADDING
        self.line_y = 0
        self.rows_start_y = 0

    async def generate(self) -> str:
        logger.info("🎨 Генерація адаптивної таблиці розмірів...")
        self._calculate_layout(len(self.parameters_map))
        self._draw_title()
        self._draw_separator_line()
        self._draw_headers()
        self._draw_rows(self.parameters_map)
        logger.info("✅ Таблиця успішно збережена: %s", self.output_path)
        return self.save_png()

    # ── разметка/геометрия ───────────────────────────────────────────────
    def _calculate_layout(self, num_parameters: int) -> None:
        service = TableGeometryService(self.IMG_WIDTH, self.IMG_HEIGHT, self.PADDING)
        layout: Dict[str, int | float] = service.calculate_layout(
            headers=self.headers,
            parameters=self.parameters_map,          # ✔ строго Dict[str, List[str]]
            base_font_size=self.base_font_size,
            font_service=self.font_service,
        )

        self.first_col_width = int(layout["first_col_width"])
        self.other_col_width = int(layout["column_width"])
        self.column_spacing = int(layout["column_spacing"])
        self.cell_height = int(layout["cell_height"])
        self.title_font_size = int(layout["title_font_size"])
        self.padding_inside = int(layout["padding_inside"])

        scale = float(layout["scale_factor"])
        self.param_cell_font = self.font_service.get_font(FontType.BOLD, int(self.base_font_size * scale))
        self.header_font = self.font_service.get_font(FontType.BOLD, int(44 * scale))
        self.value_cell_font = self.font_service.get_font(FontType.MONO, int(32 * scale))
        self.title_font = self.font_service.get_font(FontType.BOLD, int(self.title_font_size))

        self.table_height = (num_parameters + 1) * self.cell_height + self.title_font_size + self.padding_inside * 3
        self.table_y = (self.IMG_HEIGHT - self.table_height) // 2
        self.table_start_x = self.PADDING  # залишаємо padding ліворуч

    # ── рисование ────────────────────────────────────────────────────────
    def _draw_title(self) -> None:
        title_w = int(self.draw.textlength(self.title, font=self.title_font))
        title_x = (self.IMG_WIDTH - title_w) // 2
        self.draw.text((title_x, self.table_y - 10), self.title, font=self.title_font, fill="black")

    def _draw_separator_line(self) -> None:
        self.line_y = self.table_y + self.title_font_size + 10
        self.draw.line([(self.PADDING, self.line_y), (self.IMG_WIDTH - self.PADDING, self.line_y)], fill="black", width=4)

    def _draw_headers(self) -> None:
        _, header_h = self._text_size("Hg", self.header_font)
        y = self.line_y + (self.cell_height - header_h) // 2

        x = self.table_start_x + self.first_col_width - self.column_spacing * 2
        for header in self.headers:
            text_w = int(self.draw.textlength(header, font=self.header_font))
            text_x = x + (self.other_col_width - text_w) // 2
            self.draw.text((text_x, y), header, font=self.header_font, fill="black")
            x += self.other_col_width + self.column_spacing

        self.rows_start_y = self.line_y + self.cell_height

    def _draw_rows(self, adjusted_parameters: Dict[str, List[str]]) -> None:
        _, param_h = self._text_size("Hg", self.param_cell_font)
        _, value_h = self._text_size("Hg", self.value_cell_font)

        y = self.rows_start_y
        for param, values in adjusted_parameters.items():
            # лівий стовпець — назва параметра
            x_param = self.table_start_x + self.column_spacing * 2
            self.draw.text(
                (x_param, y + (self.cell_height - param_h) // 2),
                str(param),
                font=self.param_cell_font,
                fill="black",
            )

            # праві стовпці — значення розмірів
            x_value = self.table_start_x + self.first_col_width - self.column_spacing * 2
            for value in values:
                txt = str(value)
                text_w = int(self.draw.textlength(txt, font=self.value_cell_font))
                text_x = x_value + (self.other_col_width - text_w) // 2
                self.draw.text(
                    (text_x, y + (self.cell_height - value_h) // 2),
                    txt,
                    font=self.value_cell_font,
                    fill="black",
                )
                x_value += self.other_col_width + self.column_spacing

            y += self.cell_height