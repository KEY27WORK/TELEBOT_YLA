# 📬 app/bot/ui/messengers/size_chart_messenger.py
"""
📬 size_chart_messenger.py — сервіс для надійного надсилання згенерованих таблиць розмірів у Telegram.

🔹 Роль класу `SizeChartMessenger`:
    • отримує шляхи до локальних PNG-файлів із таблицями розмірів;
    • безпечно перетворює їх у `InputFile` (байти в памʼяті);
    • делегує відправку в `ImageSender` (альбом/одиночні фото, ретраї).
"""

# 🌐 Зовнішні бібліотеки
from telegram import InputFile, Update  # type: ignore							# 🤖 Telegram Bot API типи

# 🔠 Системні імпорти
import asyncio																# 🔄 Асинхронність / CancelledError
import io																	# 🧠 Буфер у памʼяті для байтів зображення
import logging																# 🧾 Логування подій
from pathlib import Path														# 🛣️ Робота зі шляхами
from typing import List															# 🧰 Типізація колекцій

# 🧩 Внутрішні модулі проєкту
from app.bot.handlers.product.image_sender import ImageSender					# 🖼️ Відправник зображень (з ретраями)
from app.bot.services.custom_context import CustomContext						# 📦 Розширений Context для бота
from app.bot.ui import static_messages as msg										# 📝 Статичні повідомлення UI
from app.errors.exception_handler_service import ExceptionHandlerService		# 🛡️ Централізована обробка винятків
from app.shared.utils.logger import LOG_NAME										# 🏷️ Єдине імʼя логера


logger = logging.getLogger(LOG_NAME)												# 🧾 Ініціалізація модульного логера


# ================================
# 🏛️ КЛАС МЕСЕНДЖЕРА ТАБЛИЦЬ РОЗМІРІВ
# ================================
class SizeChartMessenger:
    """
    📤 Делегує надійну відправку таблиць розмірів сервісу `ImageSender`.

    Відповідає лише за підготовку InputFile та виклик відправника — SRP збережено.
    """

    # ================================
    # ⚙️ ІНІЦІАЛІЗАЦІЯ
    # ================================
    def __init__(self, image_sender: ImageSender, exception_handler: ExceptionHandlerService) -> None:
        self.image_sender = image_sender												# 🖼️ DI: сервіс відправки (альбом/фото + ретраї)
        self.exception_handler = exception_handler									# 🛡️ DI: сервіс обробки винятків

    # ================================
    # 📣 ПУБЛІЧНИЙ API
    # ================================
    async def send(self, update: Update, context: CustomContext, image_paths: List[str]) -> None:
        """
        📦 Відправляє всі згенеровані зображення (альбом чи окремі фото).

        Поведінка:
        1) Валідує наявність `update.message`.
        2) Перевіряє список шляхів та готує `InputFile` у памʼяті.
        3) Делегує надсилання у `ImageSender` із заголовком.
        4) Логує результат або делегує помилку у `ExceptionHandlerService`.
        """
        try:
            if not update.message:
                return																# ⛔ Нічого надсилати у відсутності message

            if not image_paths:
                await update.message.reply_text(msg.SIZE_CHART_FAILED)
                return																# 🟡 Користувача поінформовано про відсутність файлів

            files = self._prepare_input_files(image_paths)
            if not files:
                await update.message.reply_text(msg.SIZE_CHART_FAILED)
                return																# 🟡 Підготовка не вдалася — інформуємо

            sent = await self.image_sender.send_images(
                update=update,
                context=context,													# ✅ Обовʼязково передаємо CustomContext (hookʼи, локаль і т.д.)
                images=files,
                caption="📏 Таблиця розмірів",
            )

            logger.info(
                "✅ Таблиці розмірів надіслано | chat_id=%s files_requested=%d files_sent=%d",
                getattr(update.effective_chat, "id", None),
                len(image_paths),
                len(sent),
            )

        except asyncio.CancelledError:
            raise																	# 🔁 Проброс для коректного скасування задачі
        except Exception as e:  # noqa: BLE001
            await self.exception_handler.handle(e, update)						# 🛡️ Централізована обробка і сповіщення

    # ================================
    # 🧱 ДОПОМІЖНІ МЕТОДИ
    # ================================
    def _prepare_input_files(self, image_paths: List[str]) -> List[InputFile]:
        """🔧 Перетворює шляхи у `InputFile`, читаючи байти у памʼять через `io.BytesIO`."""
        prepared: List[InputFile] = []
        for raw_path in image_paths:
            try:
                path = Path(raw_path)
                if not path.is_file():
                    logger.warning("⚠️ Файл таблиці розмірів не існує: %s", raw_path)
                    continue														# ⏭️ Пропускаємо невалідний шлях

                data = path.read_bytes()											# 📥 Зчитуємо байти файлу
                buf = io.BytesIO(data)											# 🧠 Створюємо буфер у памʼяті
                buf.seek(0)														# ⤴️ Переміщуємо курсор на початок

                prepared.append(InputFile(buf, filename=path.name or "size_chart.png"))	# 🧾 Іменуємо файл для Telegram

            except Exception as e:  # noqa: BLE001
                logger.warning("⚠️ Не вдалося підготувати файл таблиці: %s (%s)", raw_path, e)

        return prepared																# 📦 Повертаємо готовий список `InputFile