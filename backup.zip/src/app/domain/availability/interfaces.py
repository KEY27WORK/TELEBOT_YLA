# 🧩 app/domain/availability/interfaces.py
"""
🧩 interfaces.py — Контракти (інтерфейси) та публічні структури даних (DTO)
для доменного сервісу перевірки наявності.
"""

# 🔠 Системные импорты
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Mapping, Protocol, runtime_checkable

# 🧩 Внутрішні модулі
from .status import AvailabilityStatus   # ✅ Enum: YES / NO / UNKNOWN

# ==========================
# 🧾 ПУБЛІЧНІ ТИПИ (алиасы)
# ==========================
Color = str            # 🎨 Ключ кольору
Size = str             # 📏 Позначення розміру
RegionCode = str       # 🌍 Код регіону (us/eu/uk…)


# ==========================
# 🏛️ СТРУКТУРИ ДАНИХ (DTO)
# ==========================
@dataclass(frozen=True, slots=True)
class RegionStock:
    """
    DTO, що описує наявність товару в одному регіоні.

    stock_data:
        { "Black": { "M": AvailabilityStatus.YES,
                     "L": AvailabilityStatus.NO,
                     "XL": AvailabilityStatus.UNKNOWN } }
    """
    region_code: RegionCode
    stock_data: Mapping[Color, Mapping[Size, AvailabilityStatus]] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class AvailabilityReport:
    """
    DTO з підсумковим, повністю обробленим звітом про наявність.
    """
    # { "Black": { "us": ["M","L"], "eu": ["S"] } }
    availability_by_region: Mapping[Color, Mapping[RegionCode, List[Size]]]

    # { "Black": ["S","M","L","XL"] }
    all_sizes_map: Mapping[Color, List[Size]]

    # { "Black": { "M": AvailabilityStatus.YES,
    #              "L": AvailabilityStatus.NO,
    #              "XL": AvailabilityStatus.UNKNOWN } }
    merged_stock: Mapping[Color, Mapping[Size, AvailabilityStatus]]


# ==============================
# 🏛️ ІНТЕРФЕЙС СЕРВІСУ (Protocol)
# ==============================
@runtime_checkable
class IAvailabilityService(Protocol):
    """
    💧 Контракт для сервісу, що відповідає за логіку перевірки наявності.
    Чистий домен: ніякого I/O, кешів, мережі — лише трансформації структур.
    """

    def create_report(self, all_regions_data: List[RegionStock]) -> AvailabilityReport:
        """
        Приймає сирі дані з усіх регіонів і повертає структурований, детерміновано відсортований звіт.
        """
        ...


# ==============================
# 📦 ПУБЛІЧНИЙ API МОДУЛЯ
# ==============================
__all__ = [
    "Color",
    "Size",
    "RegionCode",
    "RegionStock",
    "AvailabilityReport",
    "IAvailabilityService",
    "AvailabilityStatus",
]