"""
🧠 base_parser.py — Оркестратор парсингу сторінки товару.

Вихід строго під доменні контракти:
  • ProductInfo.price -> Decimal
  • ProductInfo.images -> tuple[str, ...]
  • ProductInfo.sections / stock_data -> іммутабельні Mapping

Пайплайн:
  завантаження HTML → витяг сирих даних → обробка (fallback/weight) → збірка ProductInfo
"""

from __future__ import annotations

# 🌐 Зовнішні бібліотеки
from bs4 import BeautifulSoup
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

# 🔠 Системні імпорти
import logging
import re
from decimal import Decimal
from types import MappingProxyType
from typing import Any, Dict, Optional, Union, cast
from collections.abc import Mapping as MappingABC

# 🧩 Внутрішні модулі проєкту
from app.config.config_service import ConfigService
from app.domain.products.entities import ProductInfo, Currency, Url
from app.domain.products.interfaces import IProductDataProvider
from app.domain.products.services.weight_resolver import WeightResolver
from app.infrastructure.ai.ai_task_service import AITaskService as TranslatorService
from app.infrastructure.web.webdriver_service import WebDriverService
from app.shared.utils.url_parser_service import UrlParserService
from app.shared.utils.collections import uniq_keep_order  # ✅ единая утилита дедупа
from app.shared.utils.number import decimal_from_price_str  # ✅ единая нормализация цены
from .html_data_extractor import HtmlDataExtractor
from app.shared.utils.logger import LOG_NAME
from app.domain.products.dto import ProductHeaderDTO


# ================================
# 🧾 ЛОГЕР
# ================================
logger = logging.getLogger(LOG_NAME)


# ================================
# 🏛️ ПАРСЕР
# ================================
class BaseParser(IProductDataProvider):
    """
    📦 Повний цикл обробки сторінки товару:
    завантаження → витяг → обробка → ProductInfo (іммутабельний, валідований).

    Налаштовувані поведінки:
      • enable_description_fallback (bool): якщо опис занадто короткий — підміняти першою секцією.
      • description_fallback_min_len (int): мінімальна довжина опису для підміни.
    """

    # ----- Мінімальний набір налаштувань у парсері -----
    HTML_PARSER: str = "lxml"  # дефолтний парсер BeautifulSoup

    def __init__(
        self,
        url: Union[str, Url],
        webdriver_service: WebDriverService,
        translator_service: TranslatorService,
        config_service: ConfigService,
        weight_resolver: WeightResolver,
        url_parser_service: UrlParserService,
        *,
        enable_progress: bool = True,
        html_parser: Optional[str] = None,     # можна перевизначити на "html.parser" у тестах/CI
        request_timeout_sec: int = 30,         # таймаут одного завантаження сторінки (сек)
        # ✨ Параметри керування описом
        enable_description_fallback: Optional[bool] = None,
        description_fallback_min_len: Optional[int] = None,
        # ✨ Опційні тюнінги зображень
        images_limit: Optional[int] = None,
        filter_small_images: Optional[bool] = None,
    ) -> None:
        # ── інʼєкції та базові налаштування ─────────────────────────────────────
        self.url: Url = url if isinstance(url, Url) else Url(url)
        self.webdriver_service = webdriver_service
        self.translator_service = translator_service
        self.config_service = config_service
        self.weight_resolver = weight_resolver
        self.url_parser_service = url_parser_service

        # Прогрес/HTML-парсер
        self.enable_progress = bool(enable_progress)

        allowed_parsers = {"lxml", "html.parser", "html5lib"}
        self.html_parser = (html_parser or self.HTML_PARSER)
        if self.html_parser not in allowed_parsers:
            logger.warning("Unknown HTML parser '%s' → fallback to '%s'", self.html_parser, self.HTML_PARSER)
            self.html_parser = self.HTML_PARSER

        # Єдиний «truth source» для таймаутів (мінімум 1 сек)
        try:
            self.request_timeout_sec = max(1, int(request_timeout_sec))
        except Exception:
            self.request_timeout_sec = 30

        # ── похідні поля стану ──────────────────────────────────────────────────
        try:
            cur = self.url_parser_service.get_currency(self.url.value, default=None)
            self._currency_str = cur.upper() if cur else None
        except Exception:
            # Любая ошибка трактуется як «валюта невідома» → fallback нижче
            self._currency_str = None

        self.page_source: Optional[str] = None
        self._page_soup: Optional[BeautifulSoup] = None

        # ── конфіг для опису ───────────────────────────────────────────────────
        cfg: Optional[ConfigService] = None
        try:
            cfg = self.config_service
            cfg_enabled = bool(cfg.get("parser.description_fallback.enabled", True)) if cfg else True
            cfg_min_len_raw = cfg.get("parser.description_fallback.min_len", 20, cast=int) if cfg else 20
            cfg_min_len: int = int(cfg_min_len_raw if cfg_min_len_raw is not None else 20)
        except Exception:
            cfg_enabled, cfg_min_len = True, 20

        self.enable_description_fallback = bool(
            cfg_enabled if enable_description_fallback is None else enable_description_fallback
        )
        eff_min_len = description_fallback_min_len if description_fallback_min_len is not None else cfg_min_len
        try:
            self.description_fallback_min_len = int(eff_min_len)
        except Exception:
            self.description_fallback_min_len = 20

        # ── опціональні «дрібні тюнінги» зображень ─────────────────────────────
        try:
            self.images_limit = int(images_limit) if images_limit is not None else 30
            if self.images_limit < 1:
                self.images_limit = 1
            elif self.images_limit > 200:
                self.images_limit = 200
        except Exception:
            self.images_limit = 30

        # флаг фильтрации «маленьких»/плейсхолдеров
        try:
            self.filter_small_images = bool(filter_small_images) if filter_small_images is not None else True
        except Exception:
            self.filter_small_images = True

    # ----------------------------------------
    # 🔄 ПУБЛІЧНИЙ ІНТЕРФЕЙС
    # ----------------------------------------
    async def get_product_info(self) -> ProductInfo:
        """
        Основний метод: повертає валідний ProductInfo (навіть при помилці).
        """
        try:
            await self._fetch_and_prepare_soup()
            if not self._page_soup:
                raise ConnectionError("Не вдалося завантажити або розпарсити HTML.")

            extractor = HtmlDataExtractor(self._page_soup)
            raw = self._extract_raw_data(extractor)
            processed = await self._process_data(raw)
            info = self._build_product_info(processed)
            return self._validate_info(info)

        except Exception as e:
            logger.exception("❌ Помилка при парсингу %s: %s", self.url.value, e)
            return ProductInfo(
                title=_fallback_title_from_url(self.url),
                price=Decimal("0.0"),
                description="Не вдалося отримати дані",
                currency=_safe_currency(self._currency_str),
            )

    async def get_header_info(self) -> ProductHeaderDTO:
        """
        Швидкий хедер товару для превʼю/карток.
        Повертає строго ProductHeaderDTO згідно доменного контракту.
        """
        if self._page_soup is None:
            await self._fetch_and_prepare_soup()

        title = "ТОВАР"
        image_url: Optional[str] = None

        if self._page_soup is not None:
            extractor = HtmlDataExtractor(self._page_soup)
            t = extractor.extract_title()
            if t:
                title = t
            img = extractor.extract_main_image()
            if img:
                image_url = img

        return ProductHeaderDTO(title=title, image_url=image_url, product_url=self.url)

    # ----------------------------------------
    # 🌐 ЗАВАНТАЖЕННЯ HTML
    # ----------------------------------------
    async def _fetch_and_prepare_soup(self) -> None:
        """Завантажує HTML та створює BeautifulSoup-дерево (без локальних ретраїв)."""
        url_str = self.url.value
        logger.info("🌍 Завантаження: %s … (timeout=%ss)", url_str, self.request_timeout_sec)
        task_desc = f"Завантаження [cyan]{url_str.split('/')[-1]}[/cyan]…"

        # 🔹 ЄДИНЕ джерело правди по ретраям/таймаутам — WebDriverService.
        # Тут робимо лише per-call override навігаційного таймаута (сек → мс).
        kwargs = {
            "wait_until": "networkidle",
            "timeout_ms": self.request_timeout_sec * 1000,
        }

        if self.enable_progress:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                TimeElapsedColumn(),
                transient=True
            ) as progress:
                progress.add_task(description=task_desc, total=None)
                self.page_source = await self.webdriver_service.get_page_content(url_str, **kwargs)
        else:
            self.page_source = await self.webdriver_service.get_page_content(url_str, **kwargs)

        if self.page_source:
            # На цьому рівні ми вже довіряємо HTML і будуємо дерево
            self._page_soup = BeautifulSoup(self.page_source, self.html_parser)
            logger.info("✅ Завантажено (%d байт).", len(self.page_source))
        else:
            logger.error("❌ Неможливо завантажити: %s", url_str)

    # ----------------------------------------
    # 📥 ВИТЯГ СИРИХ ДАНИХ
    # ----------------------------------------
    def _extract_raw_data(self, extractor: HtmlDataExtractor) -> Dict[str, Any]:
        images = extractor.extract_all_images()
        # застосовуємо «жорсткий» ліміт тут
        if self.images_limit:
            images = images[: self.images_limit]
        if self.filter_small_images:
            images = [u for u in images if u]

        return {
            "title": extractor.extract_title(),
            "price": extractor.extract_price(),  # сырое значение (str/float)
            "description": extractor.extract_description(),
            "main_image": extractor.extract_main_image(),
            "all_images": images,
            "sections": extractor.extract_detailed_sections(),
            "stock_data": self._get_stock_with_fallback(extractor),
        }

    # ----------------------------------------
    # ✨ ОБРОБКА ДАНИХ
    # ----------------------------------------
    async def _process_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        # Налаштовуваний fallback опису
        if self.enable_description_fallback:
            desc = str(data.get("description") or "").strip()
            if len(desc) < int(self.description_fallback_min_len or 0):
                first_key = next(iter(data.get("sections", {})), None)
                if first_key:
                    data["description"] = data["sections"][first_key]

        title = str(data.get("title") or "").strip()
        description = str(data.get("description") or "")
        image_url = str(data.get("main_image") or "")

        # Обчислення ваги (мʼяке падіння на 0)
        try:
            weight_g = await self.weight_resolver.resolve_g(title, description, image_url)
            data["weight_g"] = int(weight_g)
        except Exception as e:
            logger.warning("⚠️ Помилка обчислення ваги: %s", e)
            data["weight_g"] = 0

        return data

    # ----------------------------------------
    # 🏗️ ЗБІРКА ProductInfo (ІММУТАБЕЛЬНИЙ)
    # ----------------------------------------
    def _build_product_info(self, data: Dict[str, Any]) -> ProductInfo:
        stock_map = _map_stock_sizes(data.get("stock_data", {}))
        title = str(data.get("title") or "").strip() or _fallback_title_from_url(self.url)

        base_kwargs: Dict[str, Any] = {
            "title": title,
            "price": decimal_from_price_str(data.get("price")),  # ✅ единая нормализация → Decimal
            "description": str(data.get("description") or ""),
            "image_url": str(data.get("main_image") or ""),
            # ✅ единый дедуп + конвертация в tuple
            "images": uniq_keep_order(data.get("all_images", []), as_tuple=True),
            "currency": _safe_currency(self._currency_str),
            "sections": _deep_freeze(data.get("sections", {})),
            "stock_data": _deep_freeze(stock_map),
        }

        weight_g = data.get("weight_g")
        if weight_g is not None:
            try:
                return ProductInfo(**base_kwargs, weight_g=int(weight_g))
            except TypeError:
                pass

        return ProductInfo(**base_kwargs)

    # ----------------------------------------
    # ✅ ФІНАЛЬНА ВАЛІДАЦІЯ (без ._replace)
    # ----------------------------------------
    def _validate_info(self, info: ProductInfo) -> ProductInfo:
        title = info.title.strip() if getattr(info, "title", "") else ""
        safe_title = title or _fallback_title_from_url(self.url)

        # Decimal: if invalid → 0.0
        try:
            _ = +info.price
            safe_price = info.price
        except Exception:
            safe_price = Decimal("0.0")

        base_kwargs: Dict[str, Any] = {
            "title": safe_title,
            "price": safe_price,
            "description": getattr(info, "description", ""),
            "image_url": getattr(info, "image_url", ""),
            # уже tuple
            "images": tuple(getattr(info, "images", ()) or ()),
            "currency": getattr(info, "currency", _safe_currency(self._currency_str)),
            "sections": getattr(info, "sections", _deep_freeze({})),
            "stock_data": getattr(info, "stock_data", _deep_freeze({})),
        }

        weight_g = getattr(info, "weight_g", None)
        if weight_g is not None:
            try:
                return ProductInfo(**base_kwargs, weight_g=int(weight_g))
            except TypeError:
                pass

        return ProductInfo(**base_kwargs)

    # ----------------------------------------
    # 📦 НАЯВНІСТЬ (FALLBACK)
    # ----------------------------------------
    def _get_stock_with_fallback(self, extractor: HtmlDataExtractor) -> Dict[str, Dict[str, bool]]:
        """
        JSON-LD → legacy DOM → {}
        """
        return extractor.extract_stock_from_json_ld() or extractor.extract_stock_from_legacy() or {}

    # Примітка: детекція Cloudflare централізована у WebDriverService.
    # Локальні евристики в парсері не використовуються.


# ================================
# 🧰 УТИЛІТИ (чисті, детерміновані)
# ================================
def _deep_freeze(obj: Any) -> Any:
    """
    Рекурсивно перетворює dict/list у іммутабельні аналоги (MappingProxyType/tuple).
    """
    if isinstance(obj, MappingABC):
        return MappingProxyType({k: _deep_freeze(v) for k, v in obj.items()})
    if isinstance(obj, list):
        return tuple(_deep_freeze(v) for v in obj)
    return obj


_SIZE_ALIAS = {
    "xxs": "XXS", "xs": "XS", "s": "S", "m": "M", "l": "L", "xl": "XL",
    "xxl": "XXL", "2xl": "XXL", "xxxl": "XXXL", "3xl": "XXXL",
}

def _normalize_size_token(raw: str) -> str:
    """
    Нормалізує представлення розміру (напр., 'x-small', '2XL' → 'XS'/'XXL').
    Числові розміри (28/30/32) залишає як є (попередньо очищені).
    """
    if not raw:
        return ""
    s = re.sub(r"[^0-9a-zA-Z]", "", raw).lower()
    if s.isdigit():
        return s
    return _SIZE_ALIAS.get(s, raw.strip().upper())


def _map_stock_sizes(stock_data: Dict[str, Dict[str, bool]]) -> Dict[str, Dict[str, bool]]:
    """
    Нормалізує усі ключі-розміри у словнику наявності.
    """
    mapped: Dict[str, Dict[str, bool]] = {}
    for color, sizes in (stock_data or {}).items():
        if not color or not sizes:
            continue
        mapped[color] = {_normalize_size_token(sz): bool(avail) for sz, avail in (sizes or {}).items()}
    return mapped


def _safe_currency(code: Optional[str]) -> Currency:
    """
    Безпечно мапить строковий код у Currency.
    Приймає None/мусор → повертає дефолт USD (fallback ТОЛЬКО тут, не у UrlParserService).
    """
    try:
        if not code:
            return Currency.USD
        return Currency(code)
    except Exception:
        return Currency.USD


def _fallback_title_from_url(url: Union[Url, str]) -> str:
    """
    Дружня заглушка назви з останнього сегмента URL (якщо title зовсім порожній).
    Приймає як Url, так і str.
    """
    try:
        url_str = url.value if isinstance(url, Url) else str(url)
        tail = (url_str or "").rstrip("/").split("/")[-1]
        tail = tail.replace("-", " ").replace("_", " ").strip()
        return tail.capitalize() or "Товар"
    except Exception:
        return "Товар"