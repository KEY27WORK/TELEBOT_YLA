# 🧩 app/domain/content/interfaces.py
from __future__ import annotations
from typing import Protocol, Set
from app.domain.products.entities import ProductInfo

class IHashtagGenerator(Protocol):
    """Контракт генератора хештегов."""

    async def generate(self, product: ProductInfo) -> Set[str]:
        ...