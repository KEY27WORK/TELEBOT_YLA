# 🔎 app/infrastructure/parsers/product_search/__init__.py
"""
Пакет `product_search` — UI‑пошук товарів на youngla.com.

Використання:
    from app.infrastructure.parsers.product_search import ProductSearchResolver
"""

from .search_resolver import ProductSearchResolver

__all__ = ["ProductSearchResolver"]
