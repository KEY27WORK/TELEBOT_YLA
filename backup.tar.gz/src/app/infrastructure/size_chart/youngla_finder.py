# app/infrastructure/size_chart/youngla_finder.py
from __future__ import annotations

import logging
from typing import Iterator, List, Tuple, Set, Optional

from bs4 import BeautifulSoup
from bs4.element import Tag, PageElement

from app.domain.size_chart.interfaces import ISizeChartFinder, Url
from app.shared.utils.prompts import ChartType
from app.shared.utils.logger import LOG_NAME
from app.infrastructure.size_chart.table_generator_factory import CHART_TYPE_PRIORITY

logger = logging.getLogger(f"{LOG_NAME}.sizefinder")


# ─────────────────────────────────────────────────────────
# 🔎 Правила классификации
# ─────────────────────────────────────────────────────────
_UNIQUE_HITS: tuple[str, ...] = (
    "size_chart", "size-chart", "sizechart", "_size_", "size_", "sizechartmen",
    "mens-size-chart", "men-size-chart",
)
_GENERAL_HITS: tuple[str, ...] = (
    "women-size-chart", "womens-size-chart", "women_size_chart",
    "size_chart_top_jogger_",
)
_GRID_HITS: tuple[str, ...] = ("grid", "size-grid", "size_grid")

# доп. эвристики по атрибутам
_ATTR_HINTS_UNIQUE: tuple[str, ...] = ("data-size-chart", "data-size", "data-sizes")
_ATTR_HINTS_GENERAL: tuple[str, ...] = ("data-women-size", "data-women-chart")


# ─────────────────────────────────────────────────────────
# 🔧 Утилиты безопасной работы с атрибутами и ссылками
# ─────────────────────────────────────────────────────────
def _first_truthy(*vals: object) -> Optional[str]:
    """Возвращает первый непустой строковый value из набора (остальное игнорит)."""
    for v in vals:
        if isinstance(v, str):
            s = v.strip()
            if s:
                return s
        elif isinstance(v, list):
            # у bs4 атрибут может быть списком строк → найдём первую непустую
            for item in v:
                if isinstance(item, str):
                    si = item.strip()
                    if si:
                        return si
    return None


def _attr_str(tag: Tag, key: str) -> Optional[str]:
    """Безопасно приводит tag.get(key) к Optional[str]."""
    try:
        return _first_truthy(tag.get(key))  # type: ignore[arg-type]
    except Exception:
        return None


def _normalize_url(src: str) -> str:
    """//cdn.example → https://cdn.example; остальное — как есть."""
    s = (src or "").strip()
    if not s:
        return s
    if s.startswith("//"):
        return f"https:{s}"
    return s


def _from_srcset(srcset: str) -> List[str]:
    """
    Берём из srcset первый URL каждой пары "url <w|x>".
    Пример: "https://a 320w, https://b 640w" → ["https://a", "https://b"].
    """
    out: List[str] = []
    for part in (srcset or "").split(","):
        url = part.strip().split(" ", 1)[0].strip()
        if url:
            out.append(url)
    return out


def _img_src_candidates(img: Tag) -> Iterator[str]:
    """
    Возвращает максимально возможный набор ссылок на изображение:
    - src, data-src, data-original, data-lazy, data-zoom-image
    - srcset / data-srcset (каждый урл)
    - <picture><source srcset|data-srcset=...> (если есть)
    Дедуплирует кандидаты (с сохранением порядка).
    """
    seen: Set[str] = set()

    def _yield_unique(u: Optional[str]) -> Iterator[str]:
        if not u:
            return
        s = u.strip()
        if not s:
            return
        if s in seen:
            return
        seen.add(s)
        yield s

    # базовые на самом <img>
    for key in ("src", "data-src", "data-original", "data-lazy", "data-zoom-image"):
        for s in _yield_unique(_attr_str(img, key)):
            yield s

    # srcset / data-srcset на самом <img>
    for key in ("srcset", "data-srcset"):
        sset = _attr_str(img, key)
        if sset:
            for u in _from_srcset(sset):
                for s in _yield_unique(u):
                    yield s

    # <picture> окружение (источники)
    parent: Optional[PageElement] = img.parent
    if isinstance(parent, Tag) and parent.name == "picture":
        for source in parent.find_all("source"):
            if not isinstance(source, Tag):
                continue
            for key in ("srcset", "data-srcset"):
                sset = _attr_str(source, key)
                if sset:
                    for u in _from_srcset(sset):
                        for s in _yield_unique(u):
                            yield s


def _classify(url_lower: str, img_tag: Tag) -> Optional[ChartType]:
    """
    Возвращает ChartType или None, если определить не удалось.
    Проверяет: строгие хит-листы → эвристики по атрибутам → слабые сигналы (alt/title).
    """
    # строгие хиты по URL
    if any(k in url_lower for k in _UNIQUE_HITS) and "women-size-chart" not in url_lower:
        return ChartType.UNIQUE
    if any(k in url_lower for k in _GENERAL_HITS):
        return ChartType.GENERAL
    if any(k in url_lower for k in _GRID_HITS):
        return ChartType.UNIQUE_GRID

    # эвристики по data-атрибутам
    for k in _ATTR_HINTS_UNIQUE:
        if img_tag.has_attr(k):
            return ChartType.UNIQUE
    for k in _ATTR_HINTS_GENERAL:
        if img_tag.has_attr(k):
            return ChartType.GENERAL

    # слабые сигналы в alt/title
    alt_title = (_first_truthy(_attr_str(img_tag, "alt"), _attr_str(img_tag, "title")) or "").lower()
    if alt_title:
        if "size" in alt_title and "women" not in alt_title:
            return ChartType.UNIQUE
        if "women" in alt_title and "size" in alt_title:
            return ChartType.GENERAL
        if "grid" in alt_title and "size" in alt_title:
            return ChartType.UNIQUE_GRID

    return None


# ─────────────────────────────────────────────────────────
# 🔎 Основной класс
# ─────────────────────────────────────────────────────────
class YoungLASizeChartFinder(ISizeChartFinder):
    """
    Поиск изображений таблиц размеров на страницах YoungLA.

    Особенности:
    - учитывает разные атрибуты (<img src|data-*, srcset|data-srcset>, <picture><source ...>)
    - нормализует протокол-независимые ссылки ('//…' → 'https://…')
    - простая и расширяемая классификация в ChartType
    - защита от дубликатов
    """

    def find_images(self, page_source: str) -> List[Tuple[Url, ChartType]]:
        if not isinstance(page_source, str) or not page_source.strip():
            logger.warning("⚠️ Пустой page_source для YoungLASizeChartFinder")
            return []

        soup = BeautifulSoup(page_source, "html.parser")

        # типичные блоки + fallback на весь документ
        blocks: List[Tag] = []
        blocks.extend([b for b in soup.select(".product-info__block-item") if isinstance(b, Tag)])
        extra_info = soup.select_one("#product-extra-information")
        if isinstance(extra_info, Tag):
            blocks.append(extra_info)
        if not blocks:
            blocks = [soup]  # обойти всё — чтобы не пропускать редкие кейсы

        found: List[Tuple[Url, ChartType]] = []
        seen: Set[str] = set()

        for block in blocks:
            for el in block.find_all("img"):
                if not isinstance(el, Tag):
                    continue
                img: Tag = el

                # кандидаты-URL из разных атрибутов (уже без дублей)
                candidates = list(_img_src_candidates(img))
                if not candidates:
                    continue

                for raw in candidates:
                    url = _normalize_url(raw)
                    if not url or url in seen:
                        continue

                    ctype = _classify(url.lower(), img)
                    if ctype is None:
                        # не size-chart — пометим, чтобы не рассматривать снова
                        seen.add(url)
                        continue

                    found.append((url, ctype))
                    seen.add(url)

        # стабилизируем выдачу: UNIQUE → GENERAL → GRID
        found.sort(key=lambda x: CHART_TYPE_PRIORITY.get(x[1], 999))

        logger.info("🔎 Найдено %d изображений size-chart", len(found))
        return found