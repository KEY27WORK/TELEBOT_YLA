# 🧩 app/domain/web/__init__.py
"""
Домашній пакет `domain.web` — містить контракти для доступу до веб-сторінок.
"""

from .interfaces import IWebClient

__all__ = ["IWebClient"]
