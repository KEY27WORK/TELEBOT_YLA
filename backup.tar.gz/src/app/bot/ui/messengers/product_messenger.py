# 📬 app/bot/ui/messengers/product_messenger.py
"""
📬 product_messenger.py — сервіс для послідовної відправки скомплектованих повідомлень про товар у Telegram.

🔹 Клас `ProductMessenger` відповідає за поетапну доставку всіх UI-блоків у правильному порядку:
    1) текстовий опис товару;
    2) заголовок (назва);
    3) звіт з цінами;
    4) музичні рекомендації;
    5) фото/альбоми товару;
    6) таблиці розмірів.

✅ Принципи:
- SRP: клас відповідає тільки за оркестрацію відправки блоків.
- DIP: усі залежності (сервіси) передаються через конструктор.
- Надійність: обробка виключень + дрібні паузи між блоками для уникнення rate-limit.
"""

from __future__ import annotations

# 🌐 Зовнішні бібліотеки
from telegram import Update  # type: ignore  # 📦 Telegram API типи (ігноруємо типи бібліотеки, якщо відсутні stubs)

# 🔠 Системні імпорти
import asyncio                              # ⏱️ Керування асинхронними паузами між відправками
import logging                              # 🧾 Логування подій і діагностика

# 🧩 Внутрішні модулі проєкту
from app.bot.handlers.product.image_sender import ImageSender                     # 🖼️ Відправник фотографій/альбомів
from app.bot.handlers.size_chart_handler_bot import SizeChartHandlerBot           # 📏 Обробник таблиці розмірів
from app.bot.services.custom_context import CustomContext                         # 🧰 Розширений контекст бота
from app.bot.ui import static_messages as msg                                     # 📝 Статичні текстові повідомлення UI
from app.config.setup.constants import AppConstants                               # ⚙️ Константи застосунку (в т.ч. parse_mode)
from app.errors.exception_handler_service import ExceptionHandlerService          # 🛡️ Сервіс обробки виключень
from app.infrastructure.music.music_sender import MusicSender                     # 🎵 Відправник музичних рекомендацій
from app.infrastructure.services.product_processing_service import (
    ProcessedProductData,
)                                                                                 # 🧱 Структура агрегованих даних товару
from app.shared.utils.logger import LOG_NAME                                      # 🏷️ Назва логера проєкту
from ..formatters.message_formatter import MessageFormatter                       # 🧩 Форматер текстових блоків

# ================================
# 🧾 НАЛАШТУВАННЯ ЛОГУВАННЯ ТА КОНСТАНТИ
# ================================
logger = logging.getLogger(LOG_NAME)   # 🏷️ Отримуємо проєктний логер
_BLOCK_PAUSE_SEC: float = 0.10         # ⏳ Коротка пауза між блоками, щоб не впертись у rate limit


# ================================
# 🏛️ КЛАС ОРКЕСТРАТОРА ВІДПРАВКИ
# ================================
class ProductMessenger:
    """
    🧭 Оркеструє відправку всіх блоків по товару у правильній послідовності.

    Відповідає тільки за UI-доставку вже підготовленого контенту (SRP),
    покладаючись на передані сервіси для форматування, музики, фото та таблиці розмірів.
    """

    def __init__(
        self,
        music_sender: MusicSender,
        size_chart_handler: SizeChartHandlerBot,
        formatter: MessageFormatter,
        image_sender: ImageSender,
        exception_handler: ExceptionHandlerService,
        constants: AppConstants,
    ) -> None:
        self.music_sender = music_sender                  # 🎵 Сервіс надсилання музичних рекомендацій
        self.size_chart_handler = size_chart_handler      # 📏 Сервіс побудови/відправки таблиці розмірів
        self.formatter = formatter                        # 🧩 Форматування текстових блоків повідомлень
        self.image_sender = image_sender                  # 🖼️ Відправка фото/альбомів товару
        self.exception_handler = exception_handler        # 🛡️ Централізована обробка виключень
        self.const = constants                            # ⚙️ Константи застосунку (parse_mode тощо)

    # ================================
    # 📤 ПУБЛІЧНИЙ МЕТОД ВІДПРАВКИ
    # ================================
    async def send(self, update: Update, context: CustomContext, data: ProcessedProductData) -> None:
        """
        🚚 Відправляє всі згенеровані блоки: опис, назву, ціну, музику, фото, таблицю розмірів.

        Args:
            update (Update): 📥 Подія Telegram з повідомленням користувача.
            context (CustomContext): 🧰 Розширений контекст виконання хендлерів.
            data (ProcessedProductData): 📦 Сукупний вміст по товару (контент, музика, джерело сторінки).
        """
        try:
            if not update.message:
                return  # 🚫 Немає текстового повідомлення — нічого відправляти

            chat_id = getattr(update.effective_chat, "id", None)   # 🆔 Chat ID для діагностики
            user_id = getattr(update.effective_user, "id", None)   # 👤 User ID для діагностики

            title_upper = data.content.title.upper()                # 🔠 Заголовок капсом для візуального акценту
            description_text = self.formatter.format_description(data.content)  # 🧩 Підготовка текстового опису
            parse_mode = self.const.UI.DEFAULT_PARSE_MODE           # 📝 Режим розмітки (HTML/Markdown) з констант

            # 1) Текстові блоки
            await update.message.reply_text(description_text, parse_mode=parse_mode)
            await asyncio.sleep(_BLOCK_PAUSE_SEC)
            await update.message.reply_text(f"<b>{title_upper}</b>", parse_mode=parse_mode)
            await asyncio.sleep(_BLOCK_PAUSE_SEC)
            await update.message.reply_text(data.content.price_message, parse_mode=parse_mode)

            logger.info("📨 Текстові блоки відправлено | chat_id=%s user_id=%s title=%s", chat_id, user_id, title_upper)

            # 2) Музика
            await self._send_music_block(update, context, data.music_text, title_upper)

            # 3) Фото/альбоми
            sent_media = await self.image_sender.send_images(update=update, context=context, images=data.content.images)
            logger.info(
                "🖼️ Фото відправлено | chat_id=%s user_id=%s requested=%d sent=%d",
                chat_id,
                user_id,
                len(data.content.images),
                len(sent_media),
            )

            # 4) Таблиця розмірів
            await self.size_chart_handler.size_chart_command(
                update=update,
                context=context,
                url=data.url,                   # 🔗 Посилання на сторінку товару
                page_source=data.page_source,   # 📄 HTML-код сторінки — щоб не вантажити повторно
            )
            logger.info("📏 Таблиця розмірів відправлена | chat_id=%s user_id=%s title=%s", chat_id, user_id, title_upper)

        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001
            await self.exception_handler.handle(e, update)

    # ================================
    # 🎵 ДОПОМІЖНИЙ МЕТОД: ВІДПРАВКА МУЗИКИ
    # ================================
    async def _send_music_block(self, update: Update, context: CustomContext, music_text: str, title: str) -> None:
        """
        🎶 Відправляє музичний блок, якщо він згенерований.
        """
        if not update.message:
            return  # 🚫 Без message не можемо писати у чат
        if not music_text:
            logger.warning("🎵 Музика не згенерована | title=%s", title)
            return  # ℹ️ Тихо завершуємо, музики немає — це не помилка

        try:
            # 🧩 Парсимо «сирий» текст у простий список назв треків
            track_names = self._parse_track_names(music_text)
            if not track_names:
                logger.warning("🎵 Порожній список треків після парсингу | title=%s", title)
                return

            # 🚀 Легасі-відправка: MusicSender сам перетворить рядки у DTO і відправить
            await self.music_sender.send_recommendations_legacy(update, context, track_names)
            logger.info("🎵 Музика відправлена | title=%s tracks=%d", title, len(track_names))

        except asyncio.CancelledError:
            raise
        except Exception as e:  # noqa: BLE001
            logger.warning("🎵 Помилка відправки музики: %s | title=%s", e, title)
            await update.message.reply_text(msg.MUSIC_SEND_ERROR)

    # -------------------------------
    # 🔎 Приватний допоміжний парсер
    # -------------------------------
    def _parse_track_names(self, text: str) -> list[str]:
        """
        Виділяє назви треків зі «сирого» тексту (може бути нумерація, буліти тощо).
        Повертає список рядків виду "Artist — Title" або як є, якщо автор не вказаний.
        """
        import re

        lines = [ln.strip() for ln in (text or "").splitlines()]
        # відкидаємо порожні рядки і технічні заголовки
        lines = [ln for ln in lines if ln and not ln.lower().startswith(("музика", "music", "tracks", "рекомендації"))]

        cleaned: list[str] = []
        for ln in lines:
            # прибираємо лідируючу нумерацію/буліти: "1. ", "01) ", "- ", "• ", "— "
            ln = re.sub(r"^\s*(?:\d+[\.\)]\s+|[-–—•]\s+)", "", ln)
            # нормалізуємо пробіли
            ln = re.sub(r"\s{2,}", " ", ln).strip()
            if ln:
                cleaned.append(ln)

        return cleaned