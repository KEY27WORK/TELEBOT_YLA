# 🧾 app/infrastructure/parsers/collections/universal_collection_parser.py
"""
Універсальний парсер колекцій YoungLA (INFRA-рівень) з єдиним вибором HTML-парсера.

Фікси:
  • Один HTML-парсер на весь шар: html_parser передається ззовні (ParserInfraOptions.html_parser)
  • Ніякого хардкоду "html.parser" — використовуємо self.html_parser всюди, де створюємо BeautifulSoup
"""

from __future__ import annotations

from bs4 import BeautifulSoup
from bs4.element import Tag

import json
import logging
import re
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from app.infrastructure.web.webdriver_service import WebDriverService
from app.config.config_service import ConfigService
from app.shared.utils.url_parser_service import UrlParserService

logger = logging.getLogger(__name__)


# ================================
# 🔧 Утиліти (строго-типобезпечні)
# ================================
def _safe_json_loads(raw: Optional[str]) -> Optional[Any]:
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def _uniq_keep_order(seq: Iterable[str]) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for x in seq:
        if not x or x in seen:
            continue
        seen.add(x)
        out.append(x)
    return out


def _strip_query_and_fragment(u: str) -> str:
    if not u:
        return ""
    u = u.split("#", 1)[0]
    u = u.split("?", 1)[0]
    return u


def _is_product_like_path(href: str) -> bool:
    return "/products/" in (href or "").lower()


def _ensure_abs(base_url: str, href: str) -> str:
    if not href:
        return ""
    href = href.strip()
    if not href:
        return ""
    if href.startswith("//"):
        return "https:" + href
    if href.startswith("/"):
        return base_url.rstrip("/") + href
    if not href.startswith("http"):
        return base_url.rstrip("/") + "/" + href.lstrip("/")
    return href


def _maybe_normalize(url_parser_service: UrlParserService, url: str) -> str:
    try:
        normalize = getattr(url_parser_service, "normalize", None)
        if callable(normalize):
            out = normalize(url)  # type: ignore[no-any-return]
            return str(out or "").strip()
    except Exception:
        pass
    return url


def _get_attr_str(tag: Any, attr: str) -> str:
    if tag is None:
        return ""
    try:
        val = tag.get(attr)  # type: ignore[attr-defined]
    except Exception:
        return ""
    if isinstance(val, list):
        for v in val:
            if isinstance(v, str) and v:
                return v
        return ""
    return val if isinstance(val, str) else ""


def _get_script_text(script: Any) -> str:
    if script is None:
        return ""
    try:
        txt = getattr(script, "string", None)
        if isinstance(txt, str) and txt:
            return txt
        txt2 = getattr(script, "text", "")
        return txt2 if isinstance(txt2, str) else ""
    except Exception:
        return ""


# ================================
# 🏛️ КЛАС ПАРСЕРА КОЛЕКЦІЙ (INFRA)
# ================================
class UniversalCollectionParser:
    """
    Витягує усі посилання на товари з колекції.
    HTML парсер обирається згідно з ParserInfraOptions.html_parser (через фабрику).
    """

    MIN_PAGE_LENGTH_BYTES = 1200

    PRODUCT_LINK_SELECTORS: Tuple[str, ...] = (
        'a[href*="/products/"]',
        '[data-product-url*="/products/"]',
        '.product-card a[href*="/products/"]',
        '.grid-product a[href*="/products/"]',
        '.card a[href*="/products/"]',
        '.product-tile a[href*="/products/"]',
        '.product-item a[href*="/products/"]',
        '.collection-product-card a[href*="/products/"]',
        '.product-grid a[href*="/products/"]',
    )

    NEXT_SELECTORS: Tuple[str, ...] = (
        'link[rel="next"]',
        'a[rel="next"]',
        'a.pagination__next',
        'a[aria-label="Next"]',
        'a[title="Next"]',
        '.pagination a.next',
        '.pagination__item--next',
    )

    MAX_PAGINATION_PAGES = 5

    def __init__(
        self,
        url: str,
        webdriver_service: WebDriverService,
        config_service: ConfigService,
        url_parser_service: UrlParserService,
        *,
        html_parser: str = "lxml",  # <-- ЄДИНИЙ дефолт; фабрика підставляє ParserInfraOptions.html_parser
    ):
        self.url = url
        self.webdriver_service = webdriver_service
        self.config_service = config_service
        self.url_parser_service = url_parser_service

        self.html_parser = html_parser  # <-- зберігаємо вибір парсера
        self.soup: Optional[BeautifulSoup] = None
        self.page_source: Optional[str] = None
        self.currency: Optional[str] = self.url_parser_service.get_currency(self.url)

    # ================================
    # 🔗 ОСНОВНИЙ ПУБЛІЧНИЙ МЕТОД
    # ================================
    async def get_product_links(self) -> List[str]:
        if not await self._fetch_page(self.url):
            logger.warning("❌ Колекція не завантажена: %s", self.url)
            return []

        links = self._parse_from_json_ld(self.soup)
        if links:
            logger.info("✅ JSON-LD дав %d посилань (без пагінації).", len(links))
            return links

        acc = self._parse_from_dom(self.soup)

        base_url = self._base_url()
        next_url = self._find_next_url(self.soup, base_url)
        hops = 0
        while next_url and hops < self.MAX_PAGINATION_PAGES:
            hops += 1
            if not await self._fetch_page(next_url):
                break
            acc.extend(self._parse_from_dom(self.soup))
            next_url = self._find_next_url(self.soup, base_url)

        acc = _uniq_keep_order(acc)
        logger.info("📦 DOM-режим: зібрано %d посилань (включно з пагінацією).", len(acc))
        return acc

    # ================================
    # 🕵️‍♂️ ЗАВАНТАЖЕННЯ СТОРІНКИ
    # ================================
    async def _fetch_page(self, url: str) -> bool:
        """
        Загружаем HTML коллекции через единый API get_page_content(...).
        """
        try:
            html = await self.webdriver_service.get_page_content(
                url,
                wait_until="networkidle",
                timeout_ms=30000,
                retries=1,
                retry_delay_sec=1,
                use_stealth=True,
            )
        except Exception as e:
            logger.error("❌ Помилка під час завантаження %s: %s", url, e)
            self.page_source = None
            self.soup = None
            return False

        self.page_source = html

        if html and len(html) > self.MIN_PAGE_LENGTH_BYTES:
            # 🔧 ВАЖЛИВО: використовуємо обраний html_parser (єдиний дефолт у шарі)
            self.soup = BeautifulSoup(html, self.html_parser)
            logger.info("✅ Сторінка колекції завантажена: %s", url)
            self.url = url
            return True

        logger.error("❌ Не вдалося завантажити сторінку або вона занадто коротка: %s", url)
        self.soup = None
        return False

    # ================================
    # 📄 JSON-LD
    # ================================
    def _parse_from_json_ld(self, soup: Optional[BeautifulSoup]) -> List[str]:
        if not soup:
            return []

        base_url = self._base_url()
        found: List[str] = []

        for script in soup.find_all("script", type="application/ld+json"):
            obj = _safe_json_loads(_get_script_text(script))
            if obj is None:
                continue
            blocks = obj if isinstance(obj, list) else [obj]
            for block in blocks:
                if not isinstance(block, dict):
                    continue

                atype = block.get("@type")
                types = {str(atype).lower()} if not isinstance(atype, list) else {str(t).lower() for t in atype}
                if not {"collectionpage", "searchresultspage", "itemlist"} & types:
                    continue

                links = self._links_from_ld_collection(block)
                if not links:
                    continue

                for raw in links:
                    abs_u = _ensure_abs(base_url, raw)
                    abs_u = _strip_query_and_fragment(abs_u)
                    if _is_product_like_path(abs_u):
                        found.append(_maybe_normalize(self.url_parser_service, abs_u))

        return _uniq_keep_order(found)

    def _links_from_ld_collection(self, block: Dict[str, Any]) -> List[str]:
        def _extract_href(node: Any) -> Optional[str]:
            if not node:
                return None
            if isinstance(node, str):
                return node
            if isinstance(node, dict):
                href = node.get("url") or node.get("@id") or node.get("identifier")
                if isinstance(href, str) and href:
                    return href
                ntype = node.get("@type")
                if isinstance(ntype, str) and ntype.lower() in ("listitem", "list_item"):
                    return _extract_href(node.get("item"))
                if "item" in node:
                    return _extract_href(node.get("item"))
            return None

        items: Any = None
        if isinstance(block.get("mainEntity"), dict):
            items = block["mainEntity"].get("itemListElement")
        if items is None:
            items = block.get("itemListElement")

        if items is None:
            return []
        if not isinstance(items, list):
            items = [items]

        out: List[str] = []
        for el in items:
            href = _extract_href(el)
            if isinstance(href, str) and href:
                out.append(href)
        return out

    # ================================
    # 🌐 DOM-fallback
    # ================================
    def _parse_from_dom(self, soup: Optional[BeautifulSoup]) -> List[str]:
        if not soup:
            return []

        base_url = self._base_url()
        acc: List[str] = []

        for sel in self.PRODUCT_LINK_SELECTORS:
            try:
                for el in soup.select(sel):
                    href = (_get_attr_str(el, "href") or _get_attr_str(el, "data-product-url")).strip()
                    if not href:
                        continue
                    href = _ensure_abs(base_url, href)
                    href = _strip_query_and_fragment(href)
                    if _is_product_like_path(href):
                        acc.append(_maybe_normalize(self.url_parser_service, href))
            except Exception as e:
                logger.warning("DOM selector failed '%s': %s", sel, e)

        return _uniq_keep_order(acc)

    # ================================
    # 👉 Пагінація
    # ================================
    def _find_next_url(self, soup: Optional[BeautifulSoup], base_url: str) -> Optional[str]:
        if not soup:
            return None

        tag = soup.select_one('link[rel="next"]')
        href = _get_attr_str(tag, "href")
        if href:
            href = _ensure_abs(base_url, href)
            return _strip_query_and_fragment(href)

        for sel in self.NEXT_SELECTORS:
            a = soup.select_one(sel)
            href = _get_attr_str(a, "href")
            if href:
                href = _ensure_abs(base_url, href)
                return _strip_query_and_fragment(href)

        try:
            pag = soup.select_one(".pagination")
            if pag:
                active = pag.select_one(".active")
                if active:
                    a2 = active.find_next("a")
                    href = _get_attr_str(a2, "href")
                    if href:
                        href = _ensure_abs(base_url, href)
                        return _strip_query_and_fragment(href)
        except Exception:
            pass

        return None

    # ================================
    # 🔗 База регіону/домену
    # ================================
    def _base_url(self) -> str:
        currency = (self.currency or "USD").upper()
        try:
            base = self.url_parser_service.get_base_url(currency)
            if isinstance(base, str) and base:
                return base
        except Exception as e:
            logger.warning("url_parser_service.get_base_url failure: %s", e)
        return "https://www.youngla.com"