# 🤖 app/infrastructure/ai/dto.py
"""
DTO для AI-запитов/ответов (простые и независимы от OpenAI SDK).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class Role(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


@dataclass(frozen=True)
class ChatMessage:
    role: Role
    content: str


@dataclass(frozen=True)
class ChatPrompt:
    """
    Готовый набор сообщений для модели.
    Обычно: [SYSTEM?] + USER.
    """
    messages: List[ChatMessage]
    temperature: float = 0.3
    max_tokens: int = 1024
    model: Optional[str] = None  # если None — возьмём из конфіга