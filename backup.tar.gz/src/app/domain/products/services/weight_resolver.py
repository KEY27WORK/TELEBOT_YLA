# ⚖️ app/domain/products/services/weight_resolver.py
"""
⚖️ weight_resolver.py — Чистий доменний сервіс для визначення ваги товару.

Призначення:
- Працює лише з доменними контрактами (IWeightDataProvider, IWeightEstimator).
- Оперує цілими грамами (int) — без float/Decimal для ваги.
- Алгоритм: локальні дані → AI fallback → оновлення локальних даних.
- Детермінований матчинг: вибір найдовшого співпадіння (більш специфічний ключ).

Безпека/стабільність:
- Нормалізація ключів (lower/strip).
- Саніті-межі для ваги (мін/макс) з клампінгом.
- Жодних «глобальних» імпортів логерів з інфри.
"""

from __future__ import annotations

import logging
from typing import Dict, Iterable, Tuple

from app.domain.products.interfaces import IWeightDataProvider, IWeightEstimator

# М'які саніті-обмеження (підлаштуйте за потреби під ваш домен)
DEFAULT_MIN_WEIGHT_G = 10          # не менше 10 г
DEFAULT_MAX_WEIGHT_G = 50_000      # не більше 50 кг

logger = logging.getLogger(__name__)


def _normalize(text: str) -> str:
    """Нормалізація вхідних рядків для стабільного пошуку ключових слів."""
    return (text or "").strip().lower()


def _find_best_match(title_lower: str, weights: Dict[str, int]) -> Tuple[str, int] | None:
    """
    Повертає найкраще співпадіння (ключ із найбільшою довжиною), якщо є.
    Це дозволяє «shorts» перемагати «short», коли обидва присутні.
    """
    matches: Iterable[Tuple[str, int]] = (
        (k, w) for k, w in weights.items() if k and k in title_lower
    )
    best = None
    best_len = -1
    for k, w in matches:
        kl = len(k)
        if kl > best_len:
            best = (k, w)
            best_len = kl
    return best


def _clamp_weight(weight_g: int, min_g: int, max_g: int) -> int:
    """Клампінг ваги в межах [min_g, max_g]. Якщо weight_g <= 0 — піднімаємо до min_g."""
    if weight_g <= 0:
        return min_g
    if weight_g < min_g:
        return min_g
    if weight_g > max_g:
        return max_g
    return weight_g


class WeightResolver:
    """
    ⚖️ Визначає вагу товару (у грамах) за назвою/описом/зображенням.

    Алгоритм:
      1) Локальний словник: шукаємо ключі в заголовку (title). Беремо «найдовший» матч.
      2) Якщо не знайдено — звертаємось до AI‑оцінки (weight estimator).
      3) Після отримання валідної ваги — оновлюємо локальні дані для майбутніх звернень.

    Примітки щодо стабільності:
    - Сервіс *не* ловить довільні винятки: CancelledError/доменні помилки мають
      підніматися вище за рівнем і оброблятися там, де приймається рішення UX.
    """

    def __init__(
        self,
        weight_data_provider: IWeightDataProvider,
        weight_estimator: IWeightEstimator,
        *,
        min_weight_g: int = DEFAULT_MIN_WEIGHT_G,
        max_weight_g: int = DEFAULT_MAX_WEIGHT_G,
        update_cache: bool = True,
    ) -> None:
        self._data_provider = weight_data_provider
        self._estimator = weight_estimator
        self._min_g = int(min_weight_g)
        self._max_g = int(max_weight_g)
        self._update_cache = bool(update_cache)

    async def resolve_g(self, title: str, description: str = "", image_url: str = "") -> int:
        """
        Повертає оцінену вагу в грамах для товару.

        Args:
            title: Назва товару (головне джерело для ключових слів).
            description: Опис (може допомогти AI‑оцінці).
            image_url: URL зображення (може допомогти AI‑оцінці).

        Returns:
            int: Вага у грамах (із саніті‑клампінгом).
        """
        title_lower = _normalize(title)

        # 1) Локальні дані
        weights: Dict[str, int] = await self._data_provider.get_all_weights()
        best = _find_best_match(title_lower, weights)
        if best is not None:
            keyword, weight_g = best
            weight_g = _clamp_weight(int(weight_g), self._min_g, self._max_g)
            logger.info("⚖️ Локальна вага: '%s' → %d г", keyword, weight_g)
            return weight_g

        # 2) AI fallback
        logger.info("🤖 Локальну вагу не знайдено. Викликаємо AI для заголовка: %s", title)
        estimated_g = await self._estimator.estimate_weight_g(title=title, description=description, image_url=image_url)
        weight_g = _clamp_weight(int(estimated_g), self._min_g, self._max_g)
        logger.info("🤖 AI‑оцінка ваги: %d г (кламп → %d г)", estimated_g, weight_g)

        # 3) Оновлення локального кешу (за бажанням)
        if self._update_cache:
            try:
                await self._data_provider.update_weight(title_lower, weight_g)
                logger.info("💾 Оновлено локальні вагові дані: '%s' → %d г", title_lower, weight_g)
            except Exception:
                # Ніколи не валимо core‑флоу тільки через проміжний кеш.
                logger.warning("⚠️ Не вдалося оновити локальні вагові дані для '%s'", title_lower, exc_info=True)

        return weight_g


__all__ = ["WeightResolver"]
