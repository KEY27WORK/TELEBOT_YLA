# 🧠 app/shared/prompts/__init__.py
"""
🧠 Пакет `prompts` — текстові шаблони для генерації запитів до OpenAI.

Використовується через утиліти:
• PromptService (app.shared.utils.prompt_service)
• сумісні шари (prompts.py, prompt_loader.py)

❗ У пакеті немає Python-коду — лише статичні ресурси.
"""