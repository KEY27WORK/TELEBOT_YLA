# 📐 Services — Геометрія таблиць розмірів

Цей модуль містить **сервіси для розрахунку геометрії таблиць розмірів** у Telegram-боті YoungLA Ukraine.  
Він забезпечує адаптивну підгонку таблиць під розміри зображення, масштабування шрифтів і правильне розташування елементів.

---

## 📂 Структура
```bash
| 📄 Файл                     | 🧩 Клас                 |                  📌 Призначення                               |
|-----------------------------|-------------------------|---------------------------------------------------------------|
| `table_geometry_service.py` | `TableGeometryService`  | Розрахунок ширини колонок, висоти рядків, масштабу та шрифтів |
```
---

## 🧩 Залежності

- `FontService` (`IFontService`, `FontType`) — надає шрифти та вимірює ширину тексту.

---

## 🏭 Де використовується

Сервіс інтегрується в генератори таблиць розмірів:

- `UniqueTableGenerator` (`unique_table_generator.py`) — адаптивні таблиці з підлаштуванням ширини колонок та розмірів шрифту.

---

## 📌 Приклад використання

```python
from app.infrastructure.size_chart.services import TableGeometryService
from app.infrastructure.image_generation.font_service import FontService
from app.domain.image_generation.interfaces import FontType

# 1. Ініціалізація сервісу
geometry = TableGeometryService(img_width=1080, img_height=1920, padding=20)

# 2. Розрахунок параметрів
font_service = FontService()
layout = geometry.calculate_layout(
    headers=["S", "M", "L", "XL"],
    parameters={"Груди": ["90", "100", "110", "120"]},
    base_font_size=38,
    font_service=font_service,
)

print(layout)
```

---

## 🛠 Технології
- Python 3.10+
- Pillow (ImageFont)
- PEP 8 / type hints (mypy, pylance)

---

## 👤 Розробник

**Кирилл / @key27**  
📬 Telegram: [t.me/key27](https://t.me/key27)
