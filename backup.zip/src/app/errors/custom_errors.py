# 🚨 app/errors/custom_errors.py
"""
🚨 custom_errors.py — Кастомні виключення для доменно-специфічних помилок.

🔹 Навіщо це потрібно:
    • Відвʼязуємо бізнес-логіку від конкретних помилок бібліотек (Telegram, httpx, Playwright, OpenAI SDK тощо).
    • Даємо безпечний канал для повідомлень користувачу через `UserVisibleError`.
    • Дозволяємо єдину точку перехоплення та логування у глобальному error handlerʼі.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional # 🧰 Типізація для повідомлень/метаданих


class ErrorCode(str, Enum):
    """Короткие коды для аналитики/метрик."""
    AI = "ai_error"
    PARSING = "parsing_error"
    NETWORK = "network_error"
    UNKNOWN = "unknown_error"



class AppError(Exception):
    """Базовый класс для всех кастомных исключений в приложении."""
    code: ErrorCode = ErrorCode.UNKNOWN

    def to_log_extra(self) -> dict:
        """Переопределяйте в наследниках, чтобы добавлять контекст в логи."""
        return {"error_code": self.code}

# ================================
# 🏛️ БАЗОВИЙ КЛАС ПОМИЛОК
# ================================
class UserVisibleError(AppError):
    """
    🧱 Базовий клас для помилок, повідомлення яких **можна безпечно** показувати користувачу.

    Використання:
        - кинути цей виняток у доменній/інфраструктурній логіці;
        - зловити його на рівні Telegram handlerʼа та показати `.message` у чаті.
    """

    def __init__(self, message: str, *, details: Optional[str] = None) -> None:
        self.message = message
        self.details = details
        super().__init__(self.message)

    def __str__(self) -> str:
        return self.message if not self.details else f"{self.message} — {self.details}"

# ================================
# 🤖 AI / ПАРСИНГ / МЕРЕЖА
# ================================
class AIError(UserVisibleError):
    """Сбой интеграции с AI-сервисами (OpenAI и т.п.)."""
    code: ErrorCode = ErrorCode.AI

    def __init__(self, message: str, *, details: Optional[str] = None, model: Optional[str] = None) -> None:
        super().__init__(message, details=details)
        self.model = model

    def to_log_extra(self) -> dict:
        extra = super().to_log_extra()
        if self.model:
            extra["model"] = self.model
        return extra


class ParsingError(UserVisibleError):
    """Ошибка парсинга HTML/JSON/XML и пр."""
    code: ErrorCode = ErrorCode.PARSING

    def __init__(self, message: str, *, details: Optional[str] = None, url: Optional[str] = None) -> None:
        super().__init__(message, details=details)
        self.url = url

    def to_log_extra(self) -> dict:
        extra = super().to_log_extra()
        if self.url:
            extra["url"] = self.url
        return extra


class NetworkRequestError(UserVisibleError):
    """Сетевая ошибка (Telegram, httpx, Playwright …)."""
    code: ErrorCode = ErrorCode.NETWORK

    def __init__(
        self,
        message: str,
        *,
        details: Optional[str] = None,
        url: Optional[str] = None,
        status_code: Optional[int] = None,
        retry_after_s: Optional[int] = None,
    ) -> None:
        super().__init__(message, details=details)
        self.url = url
        self.status_code = status_code
        self.retry_after_s = retry_after_s

    def to_log_extra(self) -> dict:
        extra = super().to_log_extra()
        if self.url:
            extra["url"] = self.url
        if self.status_code is not None:
            extra["status_code"] = self.status_code
        if self.retry_after_s is not None:
            extra["retry_after_s"] = self.retry_after_s
        return extra

# ================================
# 📦 ПУБЛІЧНИЙ ІНТЕРФЕЙС МОДУЛЯ
# ================================

__all__ = [
    "ErrorCode",
    "AppError",
    "UserVisibleError",
    "AIError",
    "ParsingError",
    "NetworkRequestError",
]