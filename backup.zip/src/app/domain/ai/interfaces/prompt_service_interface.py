# 🧠 app/domain/ai/interfaces/prompt_service_interface.py
"""
🧠 IPromptService — інтерфейс для генерації промтів для мовних моделей.

🔹 Чистий домен: лише контракти й DTO, без залежностей від OpenAI чи інфри.
🔹 Типобезпека: роль як Literal, контент як структуровані TextPart / ImagePart.
🔹 Готовність до мультимодальності та A/B тестів.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import ClassVar, Literal, Optional, Protocol, Sequence, Union, runtime_checkable

# ================================
# 🏛️ ДОМЕННІ DTO ТА ENUMS
# ================================
@dataclass(frozen=True, slots=True)
class ProductPromptDTO:
    """📦 DTO з даними про товар для генерації промптів."""
    title: str
    description: str
    image_url: Optional[str] = None


# 🎭 Ролі повідомлень
Role = Literal["system", "user", "assistant"]


@dataclass(frozen=True, slots=True)
class TextPart:
    """✏️ Текстова частина повідомлення."""
    type: Literal["text"] = field(default="text", init=False)
    text: str = ""


@dataclass(frozen=True, slots=True)
class ImagePart:
    """🖼️ Частина повідомлення з зображенням (для мультимодальності)."""
    type: Literal["image_url"] = field(default="image_url", init=False)
    url: str = ""


ContentPart = Union[TextPart, ImagePart]


@dataclass(frozen=True, slots=True)
class ChatMessage:
    """💬 Повідомлення з роллю та мультимодальним контентом."""
    role: Role
    content: Sequence[ContentPart]


@dataclass(frozen=True, slots=True)
class ChatPrompt:
    """
    📦 Структурований промпт для чат-моделей.

    Метадані:
      • prompt_id — ідентифікатор для A/B тестів.
      • version — номер версії (допомагає відслідковувати зміни).
      • max_tokens — верхня межа токенів у відповіді (опціонально).
    """
    messages: Sequence[ChatMessage]
    prompt_id: Optional[str] = None
    version: int = 1
    max_tokens: Optional[int] = None

    # невеличкий guard: порожні промти та некоректні ліміти
    def __post_init__(self):
        if not self.messages:
            raise ValueError("ChatPrompt must contain at least one message.")
        if self.max_tokens is not None and self.max_tokens <= 0:
            raise ValueError("max_tokens must be a positive integer when provided.")

    # зручні фабрики (не ламають існуюче API, просто допоміжні)
    @classmethod
    def user_text(cls, text: str, *, max_tokens: Optional[int] = None) -> "ChatPrompt":
        return cls(messages=[ChatMessage(role="user", content=[TextPart(text=text)])],
                   max_tokens=max_tokens)

    @classmethod
    def system_user_text(cls, system: str, user: str, *,
                         max_tokens: Optional[int] = None) -> "ChatPrompt":
        return cls(
            messages=[
                ChatMessage(role="system", content=[TextPart(text=system)]),
                ChatMessage(role="user", content=[TextPart(text=user)]),
            ],
            max_tokens=max_tokens,
        )


class Tone(str, Enum):
    """🎨 Тональність для текстів."""
    NEUTRAL = "neutral"
    FRIENDLY = "friendly"
    SALES = "sales"


class Lang(str, Enum):
    """🌍 Цільова мова для генерації/перекладу."""
    UK = "uk"
    EN = "en"


# ================================
# 🏛️ ІНТЕРФЕЙС СЕРВІСУ ПРОМТІВ
# ================================
@runtime_checkable
class IPromptService(Protocol):
    """🔌 Контракт для сервісів генерації промтів."""

    def get_weight_prompt(self, product: ProductPromptDTO) -> ChatPrompt: ...
    def get_translation_prompt(self, text: str, target_lang: Lang = Lang.UK) -> ChatPrompt: ...
    def get_slogan_prompt(self, product: ProductPromptDTO, tone: Tone = Tone.SALES) -> ChatPrompt: ...
    def get_music_prompt(self, product: ProductPromptDTO) -> ChatPrompt: ...
    def get_hashtags_prompt(self, product: ProductPromptDTO, lang: Lang = Lang.UK) -> ChatPrompt: ...


__all__ = [
    # Контракт
    "IPromptService",
    # DTO
    "ProductPromptDTO",
    "ChatPrompt",
    "ChatMessage",
    "TextPart",
    "ImagePart",
    "ContentPart",
    # Enums/Literals
    "Tone",
    "Lang",
    "Role",
]