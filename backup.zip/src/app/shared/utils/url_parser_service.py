# app/shared/utils/url_parser_service.py
from __future__ import annotations

from typing import List, Optional
from urllib.parse import urlparse
from .interfaces import IUrlParsingStrategy
import logging
from app.shared.utils.logger import LOG_NAME

_log = logging.getLogger(f"{LOG_NAME}.url")

class UrlParserService:
    def __init__(self, strategies: List[IUrlParsingStrategy]) -> None:
        self._strategies = list(strategies)

    def get_currency(self, url: str, default: Optional[str] = None) -> Optional[str]:
        """
        Единый источник истины по валюте:
        - НИКАКОГО молчаливого fallback здесь;
        - если стратегия не поддерживает домен → WARNING и возврат default (по умолчанию None);
        - если стратегия не смогла выдать валюту → WARNING и возврат default (по умолчанию None).
        """
        u = (url or "").strip()
        if not u:
            _log.warning("UrlParserService.get_currency: пустой URL → возвращаю default=%r", default)
            return default
        s = self._pick(u)
        if not s:
            _log.warning(
                "UrlParserService.get_currency: нет стратегии для домена '%s' → default=%r",
                urlparse(u).netloc, default
            )
            return default
        ccy = s.get_currency(u)
        if not ccy:
            _log.warning(
                "UrlParserService.get_currency: стратегия %s не вернула валюту для '%s' → default=%r",
                type(s).__name__, u, default
            )
            return default
        return ccy

    def get_region_label(self, url: str) -> str:
        s = self._pick(url)
        return s.get_region_label(url) if s else "Unknown"

    def get_base_url(self, currency: str) -> Optional[str]:
        for s in self._strategies:
            base = s.get_base_url(currency)
            if base:
                return base
        return None

    def build_product_url(self, region_code: str, product_path: str) -> Optional[str]:
        for s in self._strategies:
            url = s.build_product_url(region_code, product_path)
            if url:
                return url
        return None

    def is_product_url(self, url: str) -> bool:
        s = self._pick(url)
        return s.is_product_url(url) if s else False

    def is_collection_url(self, url: str) -> bool:
        """
        Грубая проверка: «это точно коллекция?»
        Замените на свою проверку по паттерну домена/пути.
        """
        u = (url or "").lower()
        return "/collections/" in u or "/category/" in u

    def extract_product_slug(self, url: str) -> Optional[str]:
        s = self._pick(url)
        return s.extract_product_slug(url) if s else None

    def normalize(self, raw: str) -> str:
        """
        Простейшая нормализация: trim + пониж. регистр домена и т.п.
        Если у тебя уже есть свой normalize_url(...) — просто делегируй.
        """
        raw = (raw or "").strip()
        # здесь можно использовать уже имеющиеся утилиты проекта
        return raw


    # ── Внутреннее ──────────────────────────────────────────────────────────
    def _pick(self, url: str) -> Optional[IUrlParsingStrategy]:
        domain = (urlparse(url).netloc or "").lower().replace("www.", "")
        for s in self._strategies:
            if s.supports(domain):
                return s
        return None