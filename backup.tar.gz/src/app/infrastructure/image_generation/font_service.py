# app/infrastructure/image_generation/font_service.py
"""
🔤 font_service.py — сервіс для завантаження шрифтів із пріоритетом:
1) явні шляхи з конфіга (image_generation.font_paths.bold / .mono)
2) вкладені assets: app/assets/fonts/Roboto-Bold.ttf, RobotoMono-Regular.ttf
3) системні дефолти (Linux/macOS/Windows)
4) Pillow ImageFont.load_default() як останній fallback

Кеш — простий dict[(FontType, size)] -> FontLike, щоб не ловити конфлікти типів.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from PIL import Image, ImageDraw, ImageFont

from app.config.config_service import ConfigService
from app.domain.image_generation.interfaces import FontType, FontLike, IFontService
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)

# 📂 assets всередині проекту
ASSETS_DIR = Path(__file__).resolve().parents[2] / "assets"
FONTS_DIR = ASSETS_DIR / "fonts"

# 🖥️ системні дефолти
DEFAULT_BOLD_PATHS: List[str] = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",         # Linux
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",            # macOS
    "/System/Library/Fonts/Roboto-Bold.ttf",                        # macOS (іноді)
    r"C:\Windows\Fonts\arialbd.ttf",                                # Windows
    r"C:\Windows\Fonts\Roboto-Bold.ttf",                            # Windows (якщо встановлено)
]
DEFAULT_MONO_PATHS: List[str] = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",          # Linux
    "/System/Library/Fonts/Supplemental/Courier New Bold.ttf",      # macOS
    r"C:\Windows\Fonts\consola.ttf",                                # Windows Consolas
    r"C:\Windows\Fonts\cour.ttf",                                   # Windows Courier New
]


class FontService(IFontService):
    """
    Реалізація IFontService:
    • переносима (спершу дивимося в app/assets/fonts)
    • типобезпечна через FontLike
    • з ручним кешем без @lru_cache
    """

    def __init__(self, config_service: Optional[ConfigService] = None) -> None:
        self._config = config_service or ConfigService()

        cfg_bold = self._get_cfg_list("image_generation.font_paths.bold")
        cfg_mono = self._get_cfg_list("image_generation.font_paths.mono")

        self._bold_search = self._chain_paths(
            [FONTS_DIR / "Roboto-Bold.ttf"],
            [Path(p) for p in cfg_bold],
            [Path(p) for p in DEFAULT_BOLD_PATHS],
        )
        self._mono_search = self._chain_paths(
            [FONTS_DIR / "RobotoMono-Regular.ttf"],
            [Path(p) for p in cfg_mono],
            [Path(p) for p in DEFAULT_MONO_PATHS],
        )

        # легкий «полотно+кисть» для вимірів
        self._dummy_draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))

        # інформативні логи про відсутні assets (не фейлимо ініціалізацію)
        self._log_missing_asset(FONTS_DIR / "Roboto-Bold.ttf")
        self._log_missing_asset(FONTS_DIR / "RobotoMono-Regular.ttf")

        # 🔁 простий кеш шрифтів
        self._cache: Dict[tuple[FontType, int], FontLike] = {}

    # ── Публічне API ──────────────────────────────────────────────────────
    def get_font(self, font_type: FontType, size: int) -> FontLike:
        """Повертає шрифт запитаного типу і розміру; кешується."""
        key = (font_type, size)
        cached = self._cache.get(key)
        if cached is not None:
            return cached

        search_list = self._bold_search if font_type is FontType.BOLD else self._mono_search
        for path in search_list:
            try:
                if path.exists():
                    font: FontLike = ImageFont.truetype(str(path), size)
                    self._cache[key] = font
                    return font
            except OSError:
                # іноді файл існує, але пошкоджений; пробуємо наступний
                continue

        logger.warning("⚠️ Шрифт '%s' не знайдено, використовую стандартний.", font_type.value)
        font: FontLike = ImageFont.load_default()
        self._cache[key] = font
        return font

    def get_text_width(self, text: str, font: FontLike) -> int:
        """📏 Обчислює ширину тексту в пікселях для переданого шрифту."""
        if not text:
            return 0
        try:
            return int(self._dummy_draw.textlength(str(text), font=font))
        except Exception:
            bbox = self._dummy_draw.textbbox((0, 0), str(text), font=font)
            return int((bbox[2] - bbox[0]) if bbox else 0)

    # ── Внутрішні допоміжні ───────────────────────────────────────────────
    def _get_cfg_list(self, key: str) -> List[str]:
        """Акуратно читає список шляхів з конфіга; відкидає не-рядки."""
        val = self._config.get(key, [])
        if not isinstance(val, (list, tuple)):
            return []
        out: List[str] = []
        for x in val:
            try:
                s = str(x).strip()
                if s:
                    out.append(s)
            except Exception:
                continue
        return out

    @staticmethod
    def _chain_paths(*groups: Iterable[Path]) -> List[Path]:
        """Об’єднує групи шляхів, зберігаючи порядок і уникаючи дублів."""
        flat: List[Path] = []
        for g in groups:
            flat.extend(list(g))
        seen: set[Path] = set()
        uniq: List[Path] = []
        for p in flat:
            if p not in seen:
                uniq.append(p)
                seen.add(p)
        return uniq

    @staticmethod
    def _log_missing_asset(path: Path) -> None:
        if not path.exists():
            logger.info("ℹ️ Вкладений шрифт відсутній: %s (буде використано fallback)", path)


__all__ = ["FontService"]