# app/infrastructure/web/__init__.py
"""
🌍 Web-клиент для получения HTML страниц (Playwright).
Экспортирует реализацию IWebClient — WebDriverService.
"""
from .webdriver_service import WebDriverService

__all__ = ["WebDriverService"]