"""
🎵 music — домен музичних сервісів.

Публічний API пакета:
• DTO: RecommendedTrack, MusicRecommendationResult, TrackInfo
• Контракти: IMusicRecommender, IMusicDownloader, IMusicFileManager
"""

# ── Interfaces ──────────────────────────────────────────────────────────────
from .interfaces import (
    RecommendedTrack,
    MusicRecommendationResult,
    TrackInfo,
    IMusicRecommender,
    IMusicDownloader,
    IMusicFileManager,
)

__all__ = [
    # DTO
    "RecommendedTrack",
    "MusicRecommendationResult",
    "TrackInfo",
    # Interfaces
    "IMusicRecommender",
    "IMusicDownloader",
    "IMusicFileManager",
]