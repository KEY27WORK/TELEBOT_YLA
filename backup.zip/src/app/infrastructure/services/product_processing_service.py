# 🧠 app/infrastructure/product_processing/product_processing_service.py
"""
Сервис-оркестратор обработки товара:
парсинг → наличие → контент → музыка (через доменный ProductPromptDTO).

Изменения по IMP-011:
- Больше не возвращает None. Всегда возвращается ProductProcessingResult.
- Явные коды ошибок (ParsingFailed, ContentBuildFailed, UnexpectedError и т.д.).
- Частичные сбои (availability/music) не валят весь пайплайн — логируются и деградируют.
"""

from __future__ import annotations

# 🔠 stdlib
import asyncio
import logging
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional, Any

# 🧩 проект
from app.domain.ai import ProductPromptDTO
from app.domain.products.entities import ProductInfo
from app.infrastructure.availability.availability_processing_service import (
    AvailabilityProcessingService,
)
from app.infrastructure.content.product_content_service import (
    ProductContentService,
    ProductContentDTO,
)
from app.infrastructure.music.music_recommendation import MusicRecommendation
from app.infrastructure.parsers.parser_factory import ParserFactory
from app.shared.utils.logger import LOG_NAME
from app.shared.utils.url_parser_service import UrlParserService

logger = logging.getLogger(LOG_NAME)


# ================================
# 📦 Успешный DTO
# ================================
@dataclass(frozen=True)
class ProcessedProductData:
    """Единый результат для отображения в боте."""
    url: str
    page_source: str
    region_display: str
    content: ProductContentDTO
    music_text: str


# ================================
# ❌ Ошибки и итоговый Result
# ================================
class ProcessingErrorCode(Enum):
    InvalidInput = auto()          # пустой/битый URL
    ParsingFailed = auto()         # не получили валидный ProductInfo
    ContentBuildFailed = auto()    # не собрали контент
    UnexpectedError = auto()       # иные фатальные сбои


@dataclass(frozen=True)
class ProductProcessingResult:
    ok: bool
    data: Optional[ProcessedProductData] = None
    error_code: Optional[ProcessingErrorCode] = None
    error_message: Optional[str] = None
    # необязательная «сырость» для диагностики (не показывать пользователю)
    _cause: Optional[BaseException] = None

    @staticmethod
    def success(data: ProcessedProductData) -> "ProductProcessingResult":
        return ProductProcessingResult(ok=True, data=data)

    @staticmethod
    def fail(
        code: ProcessingErrorCode,
        message: str,
        *,
        cause: Optional[BaseException] = None,
    ) -> "ProductProcessingResult":
        return ProductProcessingResult(
            ok=False, error_code=code, error_message=message, _cause=cause
        )


# ================================
# 🏛️ Сервис
# ================================
class ProductProcessingService:
    """
    Оркеструет полный цикл:
    - парсинг карточки товара
    - запрос наличия (отчёт)
    - генерация контента
    - музыкальная рекомендация (через доменный ProductPromptDTO)
    """

    def __init__(
        self,
        parser_factory: ParserFactory,
        availability_processing_service: AvailabilityProcessingService,
        content_service: ProductContentService,
        music_recommendation: MusicRecommendation,
        url_parser_service: UrlParserService,
    ) -> None:
        self.parser_factory = parser_factory
        self.availability_processing_service = availability_processing_service
        self.content_service = content_service
        self.music_recommendation = music_recommendation
        self.url_parser_service = url_parser_service

    async def process_url(self, url: str) -> ProductProcessingResult:
        logger.info("⚙️ Старт обробки URL: %s", url)

        # 0) Валидация входа (best-effort, без жёсткой зависимости от UrlParserService)
        if not isinstance(url, str) or not url.strip():
            msg = "Порожній або некоректний URL."
            logger.error("❌ %s", msg)
            return ProductProcessingResult.fail(ProcessingErrorCode.InvalidInput, msg)

        # 1) Парсим карточку (источник истины)
        try:
            parser = self.parser_factory.create_product_parser(url)
            product_info = await parser.get_product_info()
        except asyncio.CancelledError:
            # прокидываем отмену по контракту
            logger.info("🛑 Отмена process_url для %s", url)
            raise
        except Exception as e:
            logger.exception("🔥 Непредвиденная ошибка парсинга: %s", url)
            return ProductProcessingResult.fail(
                ProcessingErrorCode.ParsingFailed,
                "Не вдалося обробити сторінку товару.",
                cause=e,
            )

        # простая валидация: ProductInfo должен быть и иметь title
        if not isinstance(product_info, ProductInfo) or not (product_info.title or "").strip():
            logger.error("❌ Не вдалося отримати базову інформацію про товар: %s", url)
            return ProductProcessingResult.fail(
                ProcessingErrorCode.ParsingFailed,
                "Не вдалося отримати дані про товар.",
            )

        # 2) Регион/slug (UI-метаданные)
        try:
            region_display = self.url_parser_service.get_region_label(url)
        except Exception:
            # деградация без падения пайплайна
            logger.debug("⚠️ get_region_label() недоступен — fallback на 'N/A'", exc_info=True)
            region_display = "N/A"

        # 3) Параллельно: availability + music
        #    (availability по-прежнему принимает url, не ломаем обратную совместимость)
        availability_task = self.availability_processing_service.process(url)

        # музыка — через доменный DTO (ProductPromptDTO)
        product_dto = ProductPromptDTO(
            title=product_info.title or "",
            description=product_info.description or "",
            image_url=product_info.image_url or "",
        )
        music_task = self.music_recommendation.recommend(product_dto)

        availability_data: Any = None
        music_result: Any = None
        try:
            availability_data, music_result = await asyncio.gather(
                availability_task, music_task
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            # не валим весь пайплайн — просто логируем
            logger.exception("🔥 Помилка під час паралельних запитів (наявність/музика): %s", e)

        # 4) Текст для блока цветов/размеров из отчёта о наличии
        colors_text = (
            getattr(getattr(availability_data, "reports", None), "public_report", None)
            or "Не вдалося отримати дані про наявність."
        )

        # 5) Контент для карточки
        try:
            # сигнатура: build_product_content(product: ProductInfo, *, url: str, colors_text: str)
            content_data = await self.content_service.build_product_content(
                product_info,
                url=url,
                colors_text=colors_text,
            )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.exception("❌ Не удалось собрать контент для товара: %s", e)
            return ProductProcessingResult.fail(
                ProcessingErrorCode.ContentBuildFailed,
                "Не вдалося згенерувати контент для товару.",
                cause=e,
            )

        # 6) Сбор результата
        data = ProcessedProductData(
            url=url,
            page_source=getattr(parser, "page_source", "") or "",
            region_display=region_display,
            content=content_data,
            music_text=(getattr(music_result, "raw_text", "") or ""),
        )
        return ProductProcessingResult.success(data)