"""
📦 collection_processing — інфраструктурний шар для обробки колекцій.

Призначення:
    • Нормалізація та валідація URL сторінки колекції.
    • Витягування посилань на товари за допомогою фабрики парсерів.
    • Логування ключових етапів процесу.

Публічний API:
    • CollectionProcessingService — сервіс отримання списку посилань товарів із колекції.
"""

from .collection_processing_service import CollectionProcessingService

__all__ = ["CollectionProcessingService"]