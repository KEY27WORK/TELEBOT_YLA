# 🧩 app/domain/pricing/rounding.py
"""
Общие правила округления и вспомогательные функции для Decimal.
"""

from __future__ import annotations
from decimal import Decimal, getcontext, ROUND_HALF_UP

# Достаточная точность для финансовых расчётов
getcontext().prec = 28

# Квант для денежных значений
_MONEY_Q = Decimal("0.01")


def q2(value: Decimal) -> Decimal:
    """Округление до 2 знаков по правилу ROUND_HALF_UP."""
    return value.quantize(_MONEY_Q, rounding=ROUND_HALF_UP)


def percent(value: Decimal) -> Decimal:
    """15 -> 0.15 (удобно умножать: amount * percent(x))."""
    return value / Decimal("100")