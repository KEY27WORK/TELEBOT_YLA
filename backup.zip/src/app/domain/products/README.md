# 📦 Products Domain

Домен **продуктів**. Містить чисті сутності, контракти (інтерфейси) та доменні сервіси.
Не залежить від конкретних реалізацій інфраструктури — тільки від абстракцій.

---

## 📁 Структура

```bash
products/
├── services/
│ ├── README.md
│ ├── __init__.py
│ └── weight_resolver.py
├── __init__.py
├── entities.py
└── interfaces.py
```

---

## 🧱 Складові

### `entities.py`
- `ProductInfo` — **не змінна** (`frozen`) доменна сутність товару.
  - `price: Decimal`
  - `weight_g: int` (грами — точність без проблем float)
  - `stock_data` побудований на `AvailabilityStatus`
- `Currency` — перелік валют.

### `interfaces.py`
Контракти для джерел даних і пошуку:
- `IProductDataProvider`
- `ICollectionDataProvider`
- `IProductSearchProvider`

Контракти ваги (для сервісу):
- `IWeightDataProvider` — сховище локальних даних по вазі.
- `IWeightEstimator` — AI‑оцінка ваги.

Додатково:
- `Url` — аліас для канонічних HTTPS‑URL.
- `SEARCH_DEFAULT_LIMIT`, `SEARCH_MAX_LIMIT` — рекомендації/обмеження для пошуку.
- `SearchResult` — DTO результату пошуку (з валідацією `score ∈ [0, 1]`).

> **Вимоги до реалізацій**:
> - Усі URL — **канонічні HTTPS** (після `UrlParserService.normalize(...)`).
> - Жодної мережевої роботи в `__init__`.
> - Не «ковтати» `asyncio.CancelledError`.

### `services/weight_resolver.py`
`WeightResolver` — визначає вагу:
1. Пошук у `IWeightDataProvider`.
2. Fallback до `IWeightEstimator`.
3. Оновлює локальні дані (кеш).

Повертає **`int` у грамах**.

---

## 🚀 Приклад використання

```python
from app.domain.products import (
    WeightResolver,
    IWeightDataProvider,
    IWeightEstimator,
)

resolver = WeightResolver(weight_data_provider, weight_estimator)
weight_g = await resolver.resolve_g(
    title="YoungLA 6022 Carpenter Jeans",
    description="Джинси карго з товстого деніму",
    image_url="https://..."
)
print("Вага (г):", weight_g)
```

##  🧪 Тестованість
У WeightResolver впроваджені залежності як інтерфейси — легко мокати.
ProductInfo валідує вхідні дані в __post_init__.

##  ✅ Стиль/гарантії
Доменно чисті модулі (без імпортів із інфраструктури).
Іменування у UPPER_SNAKE_CASE для констант.
Типи з typing/dataclasses, гроші — Decimal, вага — int (g).