# 🧾 app/bot/handlers/product/collection_handler.py
"""
🧾 CollectionHandler — тонкий UI‑оркестратор обробки колекцій:
- валідація посилання;
- службові повідомлення (start/region/progress/done);
- делегація в CollectionRunner;
- безпечні (непадаючі) редагування повідомлень прогресу.

Дотримано DI: зовнішні сервіси передаються через конструктор.
"""

# 🌐 Зовнішні бібліотеки
from telegram import Message, Update                                       # 📲 Telegram типи для повідомлень

# 🔠 Системні імпорти
import asyncio                                                             # ⏳ Асинхронні затримки/таски
import contextlib                                                          # 🧯 Безпечне придушення винятків
import logging                                                             # 🧾 Логування
from typing import List, Optional                                          # 🧰 Типізація

# 🧩 Внутрішні модулі проєкту
from app.bot.handlers.product.product_handler import ProductHandler        # 🛍️ Обробник одиничного товару
from app.bot.services.custom_context import CustomContext                  # 🧠 Розширений контекст бота
from app.bot.ui import static_messages as msg                              # 📝 Статичні текстові повідомлення
from app.config.setup.constants import AppConstants                        # ⚙️ Константи застосунку
from app.errors.exception_handler_service import ExceptionHandlerService   # 🧯 Централізований хендлер винятків
from app.infrastructure.collection_processing.collection_processing_service import (
    CollectionProcessingService,
)                                                                          # 🧵 Сервіс збору посилань з колекції
from app.shared.utils.logger import LOG_NAME                               # 🏷️ Ім'я логера
from app.shared.utils.url_parser_service import UrlParserService           # 🔎 Парсер/валідація URL + регіон
from .collection_runner import CollectionRunner                            # 🏃 Оркестратор багатопотокової обробки


# ==========================
# 🧾 ЛОГЕР
# ==========================
logger = logging.getLogger(LOG_NAME)


# ==========================
# 🏛️ КЛАС ОБРОБНИКА
# ==========================
class CollectionHandler:
    """Оркестрація UI навколо обробки колекції."""

    # --------------------------
    # ⚙️ ІНІЦІАЛІЗАЦІЯ
    # --------------------------
    def __init__(
        self,
        product_handler: ProductHandler,
        url_parser_service: UrlParserService,
        collection_processing_service: CollectionProcessingService,
        exception_handler: ExceptionHandlerService,
        constants: AppConstants,
        *,
        max_items: Optional[int] = 50,
        concurrency: int = 4,
        per_item_retries: int = 2,
    ) -> None:
        self._url_parser = url_parser_service									# 🔎 Сервіс валідації/розбору URL та визначення регіону
        self._proc_service = collection_processing_service						# 🧵 Джерело посилань товарів із сторінки колекції
        self._exception_handler = exception_handler							# 🧯 Єдина точка обробки винятків
        self._const = constants											# ⚙️ Константи застосунку (UI/логіка/ліміти)

        # М'яке читання блоків із констант (не ламаємо старі конфіги)
        coll_cfg = getattr(getattr(self._const, "COLLECTION", object()), "__dict__", {})	# 🧩 Опційний неймспейс COLLECTION
        self._max_items = (
            getattr(self._const, "COLLECTION_MAX_ITEMS", None)
            or coll_cfg.get("MAX_ITEMS", max_items)
        )															# 🔢 Глобальний ліміт на кількість елементів у запуску
        eff_concurrency = coll_cfg.get("CONCURRENCY", concurrency)				# 🧵 Паралелізм обробки
        eff_retries = coll_cfg.get("PER_ITEM_RETRIES", per_item_retries)			# ♻️ Ретрай на елемент
        eff_progress_sec = coll_cfg.get("PROGRESS_INTERVAL_SEC", 2.5)			# ⏱️ Частота оновлень прогресу

        self._runner = CollectionRunner(
            product_handler=product_handler,								# 🛍️ Делегуємо кожну картку товару в ProductHandler
            concurrency=eff_concurrency,								# 🧵 Скільки одночасних воркерів
            per_item_retries=eff_retries,								# ♻️ Скільки спроб для одного товару
            progress_interval_sec=eff_progress_sec,						# ⏱️ Дельта між апдейтами прогресу
        )

    # ==========================
    # ▶️ ПУБЛІЧНИЙ МЕТОД
    # ==========================
    async def handle_collection(self, update: Update, context: CustomContext) -> None:
        """
        Приймає посилання на колекцію, запускає обробку та показує прогрес.
        """
        progress_msg: Optional[Message] = None								# 💬 Повідомлення, яке оновлюємо під час прогресу
        can_edit_progress = True										# 🛡️ Після першої помилки редагування — більше не пробуємо

        try:
            if not update.message or not context.url:
                return											# 🚪 Нема що обробляти (unsafe guard)

            url = context.url.strip()										# ✂️ Нормалізуємо URL

            # ==========================
            # ✅ ВАЛІДАЦІЯ URL
            # ==========================
            try:
                # Якщо в сервісі є is_valid_url — використовуємо його
                is_valid = self._url_parser.is_valid_url(url)  # type: ignore[attr-defined]
            except Exception:
                # Фолбек — простий префікс
                is_valid = url.startswith(("http://", "https://"))

            if not is_valid:
                await update.message.reply_text(msg.COLL_INVALID_URL)
                return											# 🧱 Зупиняємось — лінк невалідний

            await update.message.reply_text(msg.COLL_START)						# ▶️ Запуск: службове повідомлення

            # ==========================
            # 🌍 РЕГІОН + ПЕРШЕ ПОВІДОМЛЕННЯ ПРОГРЕСУ
            # ==========================
            region_display = self._url_parser.get_region(url)					# 🌍 Обчислюємо регіон для UI
            parse_mode = getattr(
                getattr(self._const, "UI", object()), "DEFAULT_PARSE_MODE", None
            )												# 🧩 Опційний parse_mode (Markdown/HTML)
            progress_msg = await update.message.reply_text(
                msg.COLL_REGION.format(region=region_display),
                parse_mode=parse_mode,
            )											# 💬 Перше повідомлення прогресу (буде редагуватись далі)

            # ==========================
            # 🔗 ЗБІР ПОСИЛАНЬ (з ретраями)
            # ==========================
            urls = await self._get_links_with_retry(url)						# 🧵 Отримуємо всі посилання на товари
            if not urls:
                if progress_msg and can_edit_progress:
                    with contextlib.suppress(Exception):
                        await progress_msg.edit_text(msg.COLL_EMPTY)			# 🔕 Нічого не знайшли — інформуємо
                return

            # Ліміт на кількість
            if self._max_items and len(urls) > self._max_items:
                await update.message.reply_text(
                    msg.COLL_TOO_LARGE.format(max=self._max_items)
                )
                urls = urls[: self._max_items]								# ✂️ Обрізаємо зайві URL за лімітом

            if progress_msg and can_edit_progress:
                with contextlib.suppress(Exception):
                    await progress_msg.edit_text(
                        msg.COLL_FOUND.format(count=len(urls))
                    )											# 🔢 Показуємо скільки посилань зібрали

            # ==========================
            # 🔗 КОЛБЕКИ ДЛЯ RUNNER
            # ==========================
            modes = getattr(getattr(self._const, "LOGIC", object()), "MODES", object())
            collection_mode_value = getattr(modes, "COLLECTION", "collection")	# 🔖 Значення режиму "колекція" у контексті

            def _is_cancelled() -> bool:
                return getattr(context, "mode", None) != collection_mode_value	# 🛑 Якщо юзер змінив режим — зупиняємося

            async def _on_progress(done: int, total: int) -> None:
                nonlocal can_edit_progress
                if progress_msg and can_edit_progress:
                    try:
                        await progress_msg.edit_text(
                            msg.COLL_PROGRESS.format(processed=done, total=total)
                        )										# 🔄 Актуалізуємо прогрес
                    except Exception:
                        can_edit_progress = False							# 🧷 Фіксуємо, що редагування більше не можна

            # ==========================
            # ▶️ ЗАПУСК RUNNER
            # ==========================
            done_count = await self._runner.run(
                update, context, urls, _on_progress, _is_cancelled
            )												# 🚀 Паралельна обробка посилань з колекції

            if progress_msg and can_edit_progress:
                with contextlib.suppress(Exception):
                    await progress_msg.edit_text(
                        msg.COLL_DONE.format(total=done_count)
                    )										# 🏁 Фінальний підсумок

        except asyncio.CancelledError:
            logger.info("🛑 Collection handling cancelled")
            if progress_msg:
                with contextlib.suppress(Exception):
                    await progress_msg.edit_text(msg.COLL_CANCELLED)			# 🪫 Повідомляємо про скасування
            return
        except Exception as exc:
            await self._exception_handler.handle(exc, update)				# 🧯 Центральна обробка помилок

    # ==========================
    # 🔧 ДОПОМІЖНІ
    # ==========================
    async def _get_links_with_retry(self, url: str, attempts: int = 3) -> List[str]:
        """
        Отримує посилання з колекції з повторними спробами та дедуплікацією.
        """
        delay = 0.8											# ⏱️ Базова пауза між спробами
        for attempt in range(attempts):
            try:
                links = await self._proc_service.get_product_links(url)			# 🌐 Запит усіх посилань із сторінки колекції
                seen: set[str] = set()									# 🧺 Для дедуплікації
                out: List[str] = []
                for link in links or []:
                    if not link or link in seen:
                        continue									# 🧹 Пропускаємо пусті/дублікати
                    seen.add(link)
                    out.append(link)
                return out										# ✅ Повертаємо чистий список
            except Exception as exc:
                logger.warning(
                    "Спроба %s/%s отримати посилання з колекції невдала: %s",
                    attempt + 1,
                    attempts,
                    exc,
                )											# ⚠️ Лог попередження з номером спроби
                if attempt == attempts - 1:
                    raise									# ❌ Вичерпали спроби — пробрасываемо виняток
                await asyncio.sleep(delay)								# ⏳ Чекаємо перед наступною спробою
                delay *= 2										# 📈 Експоненційний бекоф
        return []												# 🕳️ На крайній випадок повертаємо пустий список
