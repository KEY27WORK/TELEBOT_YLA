# 🏷️ app/infrastructure/content/adapters/hashtag_adapter.py
"""
Адаптер согласует новый доменный интерфейс IHashtagGenerator (Set[str])
со старым кодом, который ждёт строку с хештегами.
"""
from __future__ import annotations
from typing import Set

from app.domain.products.entities import ProductInfo
from app.domain.content.interfaces import IHashtagGenerator

class HashtagGeneratorStringAdapter:
    def __init__(self, inner: IHashtagGenerator) -> None:
        self._inner = inner

    async def generate(self, product_info: ProductInfo) -> str:
        hashtags: Set[str] = await self._inner.generate(product_info)
        return " ".join(sorted(hashtags)) if hashtags else ""