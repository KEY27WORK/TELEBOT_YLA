 Вот готовые файлы — вставляй как есть.

# 💸 Domain: Pricing

Чистая бизнес‑логика расчёта цены.  
Здесь нет I/O, HTTP, логов или работы с файлами — только детерминированная математика на базе **`Decimal`** и строгих DTO.

---

## ⚜️ Принципы

- **Чистота и изоляция** — модуль независим от инфраструктуры.
- **Точность** — все деньги считаются через `Decimal` (никаких `float`).
- **Конфигурируемость** — коэффициенты/пороги передаются правилами, без «магических чисел».
- **Прозрачные контракты** — два совместимых интерфейса для разных сценариев:
  - `IPriceService.build_quote(PriceInput) -> PriceBreakdown` — современный минималистичный поток.
  - `IPricingService.calculate_full_price(...) -> FullPriceDetails` — расширенный отчёт (legacy‑совместимость).
- **Тестируемость** — легко покрывается unit‑тестами; валютные курсы подменяются фейковым `IMoneyConverter`.

---

## 📂 Состав пакета

```bash
app/domain/pricing/
├─ README.md           # этот файл
├─ __init__.py        # экспорт публичного API
├─ interfaces.py       # Money / DTO / контракты IPriceService и IPricingService
├─ rounding.py         # общее округление Decimal (q2/percent)
└─ services.py         # чистая реализация PriceService + PricingRules
```
---

## 🧱 Публичные типы и контракты

- **Money** — `amount: Decimal`, `currency: str`.
- **PriceInput** → **PriceBreakdown** — минималистичный сценарий «собрать квоту».
- **PricingContext + Money** → **FullPriceDetails** — расширенный расчёт с деталями (markup, округление через UAH и т.п.).
- **IPriceService** — современный контракт (`build_quote`).
- **IPricingService** — совместимость со старым кодом (`calculate_full_price`).
- **PricingRules** — правила (ставки/пороги/проценты) без «магических чисел».
- **q2 / percent** — утилиты округления и перевода процентов в коэффициент.

---

## 🔌 Зависимости домена

- Валютные операции выполняет **`IMoneyConverter`** (контракт домена `currency`), который:
  - либо поддерживает `convert(Money, to: str) -> Money`,
  - либо `convert(amount, from: str, to: str) -> amount`.  
  `PriceService` аккуратно поддерживает оба варианта и нормализует всё к `Decimal`.

---

## 🚀 Быстрый пример (современный поток)

```python
from decimal import Decimal
from app.domain.pricing import (
    Money, PriceInput, IPriceService, PriceService, PricingRules
)

# Фейковый конвертер для примера
class FakeConverter:
    rates = {("USD","UAH"): Decimal("40"), ("UAH","USD"): Decimal("0.025"), ("USD","USD"): Decimal("1")}
    def convert(self, x, *args):
        # Поддержка и Money, и скаляров
        if hasattr(x, "amount"):
            rate = self.rates[(x.currency, args[0])]
            return Money(x.amount * rate, args[0])
        amount, from_ccy, to_ccy = x, args[0], args[1]
        rate = self.rates[(from_ccy, to_ccy)]
        return amount * rate

rules = PricingRules.from_strings(
    shipping_base_uah="150",
    shipping_per_kg_uah="120",
    commission_percent="3.5",
    discount_percent="0",
    free_threshold_uah="3000",
)

svc: IPriceService = PriceService(FakeConverter(), rules)

quote = svc.build_quote(PriceInput(
    base_price=Money(Decimal("100"), "USD"),
    weight_kg=Decimal("0.7"),
    supplier_region="us",
    target_currency="UAH",
))

print("Итог:", quote.total.amount, quote.total.currency)
# Пример вывода: Итог: 4728.00 UAH  (зависит от правил и курсов)


⸻

🧾 Пример (legacy‑совместимость)

Если в проекте ещё используется расширенный отчёт с округлением через UAH — работайте через IPricingService.calculate_full_price(...) -> FullPriceDetails.
Реализацию можно поддерживать в инфраструктуре, а доменные DTO и контракт — оставить из этого пакета.

⸻

🧪 Тестирование
	•	Подменяйте IMoneyConverter фейком с фиксированными курсами.
	•	Передавайте PricingRules явно (конфиги не читаются внутри домена).
	•	Сравнивайте Decimal через quantize/q2, чтобы избежать разницы в точности.

⸻

🧰 Расширения

Легко добавить:
	•	Налоги/VAT, купоны, многоступенчатые скидки.
	•	Порог бесплатной доставки по целевой валюте.
	•	Другие политики округления (до 10/50/100 в локальной валюте).

⸻

📜 Публичный API (из __init__.py)

from .interfaces import (
    Money, PriceInput, PriceBreakdown, IPriceService,
    PricingContext, FullPriceDetails, IPricingService,
)
from .rounding import q2, percent
from .services import PriceService, PricingRules

Готово к использованию из любого слоя приложения.
