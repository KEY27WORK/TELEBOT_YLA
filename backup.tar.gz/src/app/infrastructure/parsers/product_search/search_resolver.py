# app/infrastructure/parsers/product_search/search_resolver.py
from __future__ import annotations

import asyncio
import logging
from typing import Final, List, Optional, Sequence, Tuple, cast

from playwright.async_api import (
    TimeoutError as PlaywrightTimeoutError,
    Page,
    async_playwright,
)

# ⬇️ доменные типы/контракт
from app.domain.products.entities import Url
from app.domain.products.interfaces import (
    IProductSearchProvider,
    SEARCH_DEFAULT_LIMIT,
    SEARCH_MAX_LIMIT,
    SearchResult,
)

# ⬇️ DI (опционально, но рекомендовано)
from app.config.config_service import ConfigService

logger = logging.getLogger(__name__)


class ProductSearchResolver(IProductSearchProvider):
    """
    Надёжный UI-поиск товара на youngla.com через Playwright.

    Контракт:
      • resolve_one(query) -> Optional[Url]
      • resolve_many(query, limit) -> List[SearchResult]

    Конфигурирование таймингов (ms) через ConfigService:
      • search.goto_timeout_ms        (по умолчанию 30000)
      • search.idle_timeout_ms        (по умолчанию 15000)
      • search.predictive_timeout_ms  (по умолчанию 7000)

    Если DI не передан (использование classmethod), работают дефолты.
    """

    BASE_URL: Final[str] = "https://www.youngla.com"

    # Значения по умолчанию (используются, если не переопределены конфигом)
    DEFAULT_GOTO_TIMEOUT_MS: Final[int] = 30_000
    DEFAULT_IDLE_TIMEOUT_MS: Final[int] = 15_000
    DEFAULT_PREDICTIVE_TIMEOUT_MS: Final[int] = 7_000

    # Триггеры открытия поиска
    OPEN_SEARCH_CANDIDATES: Final[Tuple[str, ...]] = (
        'a[href="/search"]',
        'a[aria-controls^="header-search"]',
        'button[aria-controls^="header-search"]',
        'button[aria-label*="Open search" i]',
    )

    # Узлы внутри открытого диалога поиска
    SEARCH_DIALOG: Final[str] = "header-search[open]"
    SEARCH_FORM: Final[str] = "form#predictive-search-form.header-search__form"
    SEARCH_INPUT: Final[str] = 'input[type="search"][name="q"].header-search__input'

    # Быстрые результаты (desktop + mobile)
    PREDICTIVE_ROOT: Final[str] = "predictive-search#header-predictive-search"
    PREDICTIVE_FIRST_PRODUCT_LINKS: Final[Tuple[str, ...]] = (
        f"{PREDICTIVE_ROOT} .predictive-search__products a.product-card__media",
        f"{PREDICTIVE_ROOT} .predictive-search__products a.product-title",
        f"{PREDICTIVE_ROOT} .horizontal-product-card a.horizontal-product-card__figure",
        f"{PREDICTIVE_ROOT} .horizontal-product-card a.product-title",
        f"{PREDICTIVE_ROOT} a[href*='/products/']",
    )

    # Кнопка "View all results"
    VIEW_ALL_RESULTS_BTN: Final[str] = 'button[form="predictive-search-form"]'

    # Страница результатов
    RESULTS_FIRST_LINKS: Final[Tuple[str, ...]] = (
        "main a.product-card__media",
        "main a.product-title",
        "main .horizontal-product-card a.horizontal-product-card__figure",
        "main .horizontal-product-card a.product-title",
        "main a[href*='/products/']",
        "a[href*='/products/']",
    )

    def __init__(
        self,
        webdriver_service=None,          # зарезервировано под будущую интеграцию
        url_parser_service=None,
        config_service: Optional[ConfigService] = None,
        *,
        # локальные override’ы (если хочется переопределить без конфига)
        goto_timeout_ms: Optional[int] = None,
        idle_timeout_ms: Optional[int] = None,
        predictive_timeout_ms: Optional[int] = None,
    ) -> None:
        self._webdriver_service = webdriver_service
        self._url_parser_service = url_parser_service
        self._cfg = config_service

        # Читаем из конфига, падаем на дефолты, затем на локальные override’ы
        def _cfg_int(key: str, default_val: int) -> int:
            if not self._cfg:
                return default_val
            try:
                return self._cfg.get(key, default_val, cast=int) or default_val
            except Exception:
                return default_val

        self._goto_timeout_ms = int(
            goto_timeout_ms if goto_timeout_ms is not None else _cfg_int("search.goto_timeout_ms", self.DEFAULT_GOTO_TIMEOUT_MS)
        )
        self._idle_timeout_ms = int(
            idle_timeout_ms if idle_timeout_ms is not None else _cfg_int("search.idle_timeout_ms", self.DEFAULT_IDLE_TIMEOUT_MS)
        )
        self._predictive_timeout_ms = int(
            predictive_timeout_ms if predictive_timeout_ms is not None else _cfg_int("search.predictive_timeout_ms", self.DEFAULT_PREDICTIVE_TIMEOUT_MS)
        )

    # ───────────────── интерфейс доменного провайдера ─────────────────

    async def resolve_one(self, query: str) -> Optional[Url]:
        href = await self._search_first_href(query)
        return Url(self._canonicalize(href)) if href else None

    async def resolve_many(self, query: str, limit: int = SEARCH_DEFAULT_LIMIT) -> List[SearchResult]:
        safe_limit = max(1, min(int(limit), int(SEARCH_MAX_LIMIT)))
        links = await self._search_many_impl(query, safe_limit)
        return [SearchResult(url=Url(self._canonicalize(h)), title=None, score=1.0) for h in links]

    # ───────────────── обратная совместимость (classmethod) ─────────────────
    @classmethod
    async def resolve(cls, query: str) -> Optional[str]:
        """
        Back-compat: вернуть только первый URL как строку.
        Использует дефолтные тайминги (если нужен конфиг — создайте инстанс).
        """
        tmp = cls()
        links = await tmp._search_many_impl(query, 1)
        return links[0] if links else None

    # ───────────────── основная логика (инстанс) ─────────────────

    async def _search_first_href(self, query: str) -> Optional[str]:
        links = await self._search_many_impl(query, 1)
        return links[0] if links else None

    async def _search_many_impl(self, raw_query: str, limit: int) -> List[str]:
        query = self._sanitize_query(raw_query)
        logger.info("YLA search: %s (limit=%s)", query, limit)

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
                ),
                locale="en-US",
            )
            page = await context.new_page()
            try:
                await self._goto(page, self.BASE_URL)
                await self._open_search(page)

                # Вводим запрос
                await page.fill(self.SEARCH_INPUT, "")
                await page.fill(self.SEARCH_INPUT, query)

                # 1) собрать из predictive
                pred = await self._collect_first_hrefs(
                    page, self.PREDICTIVE_FIRST_PRODUCT_LINKS, limit, self._predictive_timeout_ms
                )
                if pred:
                    return pred

                # 2) перейти на полные результаты и собрать там
                await self._open_full_results(page)
                return await self._collect_first_hrefs(page, self.RESULTS_FIRST_LINKS, limit, self._idle_timeout_ms)

            except asyncio.CancelledError:
                raise
            except PlaywrightTimeoutError:
                logger.exception("YLA search timeout")
                return []
            except Exception:
                logger.exception("YLA search fatal")
                return []
            finally:
                # Аккуратно закрываем всё
                for closer in (page.close, context.close, browser.close):
                    try:
                        await closer()
                    except Exception:
                        pass

    # ───────────────── helpers (инстанс) ─────────────────

    async def _goto(self, page: Page, url: str) -> None:
        await page.goto(url, timeout=self._goto_timeout_ms)
        try:
            await page.wait_for_load_state("networkidle", timeout=self._idle_timeout_ms)
        except PlaywrightTimeoutError:
            pass

    async def _open_search(self, page: Page) -> None:
        # Кликаем любой доступный триггер через JS
        for sel in self.OPEN_SEARCH_CANDIDATES:
            try:
                await page.wait_for_selector(sel, timeout=8_000, state="attached")
                await page.evaluate("s => document.querySelector(s)?.click()", sel)
                break
            except PlaywrightTimeoutError:
                continue
        await page.wait_for_selector(self.SEARCH_DIALOG, timeout=8_000, state="visible")
        await page.wait_for_selector(self.SEARCH_INPUT, timeout=8_000)

    async def _collect_first_hrefs(
        self,
        page: Page,
        selectors: Sequence[str],
        limit: int,
        wait_timeout_ms: int,
    ) -> List[str]:
        """Возвращает до `limit` уникальных абсолютных ссылок по набору селекторов."""
        if not selectors:
            return []

        try:
            if self.PREDICTIVE_ROOT in selectors[0]:
                await page.wait_for_selector(self.PREDICTIVE_ROOT, timeout=wait_timeout_ms)
        except PlaywrightTimeoutError:
            return []

        out: List[str] = []
        seen: set[str] = set()
        for sel in selectors:
            if len(out) >= limit:
                break
            try:
                for el in await page.query_selector_all(sel):
                    href = (await el.get_attribute("href")) or ""
                    if not href:
                        continue
                    abs_u = self._abs(href)
                    if abs_u and abs_u not in seen:
                        seen.add(abs_u)
                        out.append(abs_u)
                        if len(out) >= limit:
                            break
            except PlaywrightTimeoutError:
                continue
        return out

    async def _open_full_results(self, page: Page) -> None:
        try:
            if await page.locator(self.VIEW_ALL_RESULTS_BTN).count():
                try:
                    await page.click(self.VIEW_ALL_RESULTS_BTN)
                except Exception:
                    await page.locator(self.SEARCH_FORM).evaluate("f => f.submit()")
            else:
                if await page.locator(self.SEARCH_FORM).count():
                    await page.locator(self.SEARCH_FORM).evaluate("f => f.submit()")
                else:
                    await page.press(self.SEARCH_INPUT, "Enter")
        except Exception:
            pass

        try:
            await page.wait_for_load_state("domcontentloaded", timeout=self._idle_timeout_ms)
            await page.wait_for_load_state("networkidle", timeout=self._idle_timeout_ms)
        except PlaywrightTimeoutError:
            pass

        html = (await page.content()).lower()
        if "captcha" in html or "are you human" in html:
            raise PlaywrightTimeoutError("blocked by captcha")

    # ───────────────── канонизация ─────────────────

    @staticmethod
    def _sanitize_query(q: str) -> str:
        q = (q or "").strip()
        return q[:120] if len(q) > 120 else q

    def _canonicalize(self, href: str) -> str:
        u = self._abs(href)
        try:
            normalize = getattr(self._url_parser_service, "normalize", None)
            if callable(normalize):
                out = normalize(u)
                if out:
                    u = str(out)
        except Exception:
            pass
        return u

    @staticmethod
    def _abs(href: str) -> str:
        if not href:
            return ""
        href = href.strip()
        if href.startswith("//"):
            return "https:" + href
        if href.startswith("/"):
            return ProductSearchResolver.BASE_URL.rstrip("/") + href
        return href
    
# РАБОЧАЯ ВЕРСИЯ КОДА:
# 🔎 app/infrastructure/parsers/product_search/search_resolver.py
#"""
#🔍 search_resolver.py — Асинхронний UI-пошук товару на сайті YoungLA через Playwright.
#
#🔹 Переходить на головну сторінку
#🔹 Імітує клік по кнопці пошуку (через JS)
#🔹 Вводить запит у поле пошуку
#🔹 Якщо є підказки — повертає перше посилання
#🔹 Інакше сабмітить форму, чекає та парсить перший результат
#🔹 Повертає URL товару або None
#"""
#
## 🌐 Зовнішні бібліотеки
#from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError  # 🧪 Playwright для headless-пошуку
#
## 🔠 Системні імпорти
#import logging  # 🧾 Логування
#from typing import Optional, List  # 👈 ДОБАВЛЕНО: для нових методів
#
## 🧩 Внутрішні модулі проєкту
#from app.domain.products.interfaces import IProductSearchProvider
#
## ================================
## 🏛️ КЛАС РЕЗОЛВЕРА ПОШУКУ
## ================================
#
#logger = logging.getLogger(__name__)
#
#
#class ProductSearchResolver(IProductSearchProvider):
#    """
#    🔍 Виконує пошук товару за запитом, імітуючи дії користувача на сайті.
#    """
#
#    # Позволяем фабрике прокидывать зависимости, но делаем их необязательными,
#    # чтобы класс продолжал работать в "классовом" стиле.
#    def __init__(
#        self,
#        webdriver_service=None,
#        url_parser_service=None,
#        config_service=None,
#    ) -> None:
#        self._webdriver_service = webdriver_service
#        self._url_parser_service = url_parser_service
#        self._config_service = config_service
#
#    # ---- Реализации интерфейса IProductSearchProvider ----
#    async def resolve_one(self, query: str) -> Optional[str]:
#        """
#        Контрактный метод интерфейса. Делегирует в существующий classmethod `resolve`.
#        """
#        return await self.resolve(query)  # type: ignore[misc]
#
#    async def resolve_many(self, queries: List[str]) -> List[Optional[str]]:
#        """
#        Последовательно (надёжнее против rate-limit/CAPTCHA) ищет несколько запросов.
#        Если хочешь — можно заменить на gather с лимитом параллелизма.
#        """
#        results: List[Optional[str]] = []
#        for q in queries:
#            try:
#                results.append(await self.resolve(q))  # type: ignore[misc]
#            except Exception:
#                logger.exception("❌ Ошибка при поиске запроса: %r", q)
#                results.append(None)
#        return results
#
#    BASE_URL = "https://www.youngla.com"  # 🌍 Базова адреса сайту YoungLA
#
#    # 🧭 Селектори DOM-елементів, з якими працюємо
#    SEARCH_ICON_SELECTOR = 'a[href="/search"]'  # 🔍 Кнопка/іконка відкриття пошуку
#    SEARCH_INPUT_SELECTOR = 'input[type="search"]'  # 📝 Поле введення запиту
#    PREDICTIVE_LINK_SELECTOR = 'predictive-search a[href*="/products/"]'  # ⚡ Підказки з дропдауна
#    RESULT_LINK_SELECTOR = 'a[href*="/products/"]'  # 📄 Результати пошуку на сторінці
#    SEARCH_FORM_SELECTOR = 'form.header-search__form'  # 📤 HTML-форма пошуку
#
#    @classmethod
#    async def resolve(cls, query: str) -> str | None:
#        """
#        📥 Пошук товару за назвою або артикулом.
#
#        :param query: Наприклад: "W173 Nova Skirt"
#        :return: URL товару або None
#        """
#        logger.info(f"🔍 Старт пошуку за запитом: {query}")
#        try:
#            async with async_playwright() as p:
#                browser = await p.chromium.launch(headless=True)  # Запускаємо Chromium у headless-режимі
#                page = await browser.new_page()  # Створюємо нову сторінку
#
#                # Виконуємо основні кроки UI-пошуку
#                await cls._go_to_homepage(page)
#                await cls._click_search_icon(page)
#                await cls._fill_search_input(page, query)
#
#                # Перевіряємо, чи є швидкі підказки
#                result = await cls._check_predictive_suggestions(page)
#                if result:
#                    await browser.close()
#                    return result
#
#                # Якщо ні — сабмітимо форму пошуку і перевіряємо результат
#                result = await cls._submit_search_form(page)
#                await browser.close()
#                return result
#
#        except PlaywrightTimeoutError:
#            logger.exception("❌ Таймаут при пошуку")
#        except Exception as e:
#            logger.exception(f"❌ Помилка пошуку: {e}")
#
#        return None
#
#    # ================================
#    # 🔧 ДОПОМІЖНІ МЕТОДИ ДІЙ
#    # ================================
#
#    @classmethod
#    async def _go_to_homepage(cls, page):
#        """🌐 Переходить на головну сторінку сайту"""
#        logger.info(f"🌐 Переходимо на головну: {cls.BASE_URL}")
#        await page.goto(cls.BASE_URL, timeout=25000)
#
#    @classmethod
#    async def _click_search_icon(cls, page):
#        """🖱️ Клікає по іконці пошуку (через JS для стабільності)"""
#        try:
#            await page.wait_for_selector(cls.SEARCH_ICON_SELECTOR, timeout=15000, state="attached")
#            # Використовуємо evaluate для симуляції реального кліку через JS (безпечніше ніж click())
#            await page.evaluate('selector => document.querySelector(selector)?.click()', cls.SEARCH_ICON_SELECTOR)
#            logger.info("✅ Кнопка пошуку натиснута (через JS)")
#        except PlaywrightTimeoutError:
#            logger.exception("❌ Кнопка пошуку не знайдена")
#            raise
#
#    @classmethod
#    async def _fill_search_input(cls, page, query: str):
#        """⌨️ Вводить текстовий запит у поле пошуку"""
#        try:
#            await page.wait_for_selector(cls.SEARCH_INPUT_SELECTOR, timeout=5000)
#            await page.fill(cls.SEARCH_INPUT_SELECTOR, query)
#            logger.info(f"⌨️ Введено запит: {query}")
#        except PlaywrightTimeoutError:
#            logger.exception("❌ Поле пошуку не знайдено")
#            raise
#
#    @classmethod
#    async def _check_predictive_suggestions(cls, page) -> str | None:
#        """🔍 Перевіряє дропдаун з підказками і повертає перше посилання, якщо знайдено"""
#        try:
#            await page.wait_for_selector(cls.PREDICTIVE_LINK_SELECTOR, timeout=7000)
#            el = await page.query_selector(cls.PREDICTIVE_LINK_SELECTOR)
#            if el:
#                href = await el.get_attribute("href")
#                if href:
#                    full_url = cls.BASE_URL + href if href.startswith("/") else href
#                    logger.info(f"✅ Знайдено через підказки: {full_url}")
#                    return full_url
#        except PlaywrightTimeoutError:
#            logger.warning("⚠️ Підказки не зʼявились — fallback на повну сторінку")
#        return None
#
#    @classmethod
#    async def _submit_search_form(cls, page) -> str | None:
#        """📤 Сабмітить форму пошуку і парсить перший результат зі сторінки результатів"""
#        await page.locator(cls.SEARCH_FORM_SELECTOR).evaluate("form => form.submit()")
#        await page.wait_for_load_state("networkidle", timeout=20000)
#
#        # Перевірка на CAPTCHA (часто зустрічається в headless-режимі)
#        html = await page.content()
#        if "captcha" in html.lower():
#            logger.error("🛑 CAPTCHA — headless режим заблоковано")
#            return None
#
#        try:
#            # Чекаємо наявності хоча б одного результату товару на сторінці
#            await page.wait_for_selector(cls.RESULT_LINK_SELECTOR, timeout=10000)
#
#            # Вибираємо перше посилання з результатів
#            result_el = await page.query_selector(cls.RESULT_LINK_SELECTOR)
#
#            # Якщо знайдено елемент з посиланням
#            if result_el:
#                # Отримуємо значення атрибута href
#                href = await result_el.get_attribute("href")
#
#                # Перевіряємо, чи воно непорожнє
#                if href:
#                    # Додаємо базову адресу, якщо посилання починається з '/'
#                    full_url = cls.BASE_URL + href if href.startswith("/") else href
#
#                    # Логування успішного пошуку
#                    logger.info(f"✅ Знайдено на сторінці результатів: {full_url}")
#
#                    # Повертаємо повну URL-адресу товару
#                    return full_url
#        except PlaywrightTimeoutError:
#            logger.warning("❌ Не знайдено жодного результату на сторінці")
#
#        return None
#
#
#
#