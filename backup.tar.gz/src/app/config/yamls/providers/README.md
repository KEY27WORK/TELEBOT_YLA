# providers/

Конфігурації зовнішніх провайдерів.
- `delivery.yaml` — тарифи Meest (ключі країн узгоджені з `pricing.regional_costs.*.country_code`).

> Може перекривати `base/`, але сам перекривається `local/`.