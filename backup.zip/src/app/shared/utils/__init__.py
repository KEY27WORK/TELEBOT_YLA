# app/shared/utils/__init__.py
"""
Кросс-утилиты: логирование, парсинг URL (через стратегии), работа с промптами.
"""

# Логирование
from .logger import (
    LOG_NAME,
    init_logging,
    init_logging_from_config,
    get_logger,
)

# URL
from .interfaces import IUrlParsingStrategy
from .url_parser_service import UrlParserService

# Промпты
from .prompt_service import PromptService, PromptType, ChartType

# Коллекции (ре-экспорт утилиты с уникализацией)
from .collections import uniq_keep_order  # re-export

__all__ = [
    # logging
    "LOG_NAME",
    "init_logging",
    "init_logging_from_config",
    "get_logger",
    # url
    "IUrlParsingStrategy",
    "UrlParserService",
    # prompts
    "PromptService",
    "PromptType",
    "ChartType",
    # collections
    "uniq_keep_order",
]