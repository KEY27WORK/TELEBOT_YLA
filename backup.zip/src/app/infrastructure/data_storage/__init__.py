"""
Инфраструктурные хранилища данных (локальные/файловые/кэши).

Сейчас экспортируется:
    • WeightDataService — асинхронне сховище ваг (JSON-файл + in-memory кеш).
"""

from .weight_data_service import WeightDataService

__all__ = ["WeightDataService"]