# 🧠 Infrastructure / AI

Інфраструктурний шар для роботи з LLM. Приймає **чисті доменні DTO** і повертає plain-text без прив'язки бізнес-логіки.

## Склад
- `dto.py` — `ChatPrompt`, `ChatMessage`, `Role`
- `open_ai_serv.py` — тонкий клієнт OpenAI (Async)
- `prompt_service.py` — формує `ChatPrompt` із shared PromptBuilder + пер-промтові оверрайди з конфіга
- `ai_task_service.py` — реалізація доменних контрактів:
  - `IWeightEstimator`
  - `ITranslator`
  - `ISloganGenerator`

## Конфіг (yaml / .env)

Очікувані ключі (через `ConfigService`):

```yaml
openai:
  api_key: ${OPENAI_API_KEY}
  model: "gpt-4-turbo"        # дефолтна модель
  defaults:
    temperature: 0.3
    max_tokens: 1024

  prompts:
    slogan:
      temperature: 0.7
      max_tokens: 64
    music:
      temperature: 0.5
      max_tokens: 256
    translation:
      temperature: 0.3
      max_tokens: 1024
    weight:
      temperature: 0.3
      max_tokens: 32
    clothing_type:
      temperature: 0.2
      max_tokens: 64
    hashtags:
      temperature: 0.5
      max_tokens: 128
    size_chart:
      temperature: 0.0
      max_tokens: 2048
```

## .env

```yaml
OPENAI_API_KEY=sk-...
```

## Використання
```python
from app.config.config_service import ConfigService
from app.infrastructure.ai import OpenAIService, PromptService, AITaskService
from app.domain.ai.task_contracts import IWeightEstimator

cfg = ConfigService()
openai_cli = OpenAIService(cfg)
prompts = PromptService(cfg)
ai = AITaskService(openai_cli, prompts)  # IWeightEstimator / ITranslator / ISloganGenerator

# Вага
grams = await ai.estimate_weight_g(
    title="YoungLA Tee",
    description="oversized cotton",
    image_url="https://..."
)

# Переклад
sections = await ai.translate_sections(text="100% cotton. Relaxed fit...")

# Слоган
slogan = await ai.generate_slogan(title="Gladiator 4044", description="heavyweight, boxy fit")
```

## Нотатки по типам
	•	Pylance може прискіпуватись до ChatCompletionMessageParam. У open_ai_serv.py використаний cast(...) для безпечного приведення.
	•	Role — Enum у DTO; при конвертації до OpenAI використовується .value.

## Тести/моки
	•	Можна мокати OpenAIService.chat_completion() на рівні сервісу задач (AITaskService) — доменні контракти не змінюються.

---