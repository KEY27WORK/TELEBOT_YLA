# app/infrastructure/content/product_content_service.py
"""
🧠 product_content_service.py — сервіс для агрегації контенту про товар.

🔹 Клас `ProductContentService`:
   - Асинхронно збирає дані з різних джерел (AI, ціни, наявність).
   - Повертає ЖОРСТКО типізований DTO (ProductContentDTO) — без повернень None.
   - Будь-які виключення НЕ ковтає: піднімає вище, щоб оркестратор сформував
     зрозуміле для користувача повідомлення (вимога IMP-011).
"""

from __future__ import annotations

# 🔠 Стандартна бібліотека
import asyncio
import logging
from dataclasses import dataclass
from typing import Dict, List, Tuple

# 🧩 Доменні контракти
from app.domain.ai.task_contracts import ITextAI
from app.domain.content.interfaces import IHashtagGenerator
from app.domain.products.entities import ProductInfo

# 🧰 Інфраструктура (адаптери)
from app.infrastructure.adapters import (
    HashtagGeneratorStringAdapter,   # Set[str] -> str
    IPriceMessageFacade,
    PriceMessageFacade,
)
from app.bot.handlers.price_calculator_handler import PriceCalculationHandler
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


# ================================
# 📦 DTO для контенту товару
# ================================
@dataclass(frozen=True, slots=True)
class ProductContentDTO:
    title: str                 # Назва товару (як з парсера)
    slogan: str                # Слоган від AI
    hashtags: str              # Рядок з хештегами (через адаптер)
    sections: Dict[str, str]   # Перекладені/структуровані секції опису
    colors_text: str           # Блок кольорів/розмірів з availability
    price_message: str         # Готове до відправки повідомлення з ціною
    images: List[str]          # Список url-зображень (для галереї)

__all__ = ["ProductContentDTO", "ProductContentService"]


# ================================
# 🏛️ Сервіс агрегації
# ================================
class ProductContentService:
    """
    Єдина точка, що агрегує текст/медіа для картки товару на базі `ProductInfo`.
    Відповідальність: лише композиція/оркестрація підзадач; без бізнес-логіки ціноутворення.
    """

    def __init__(
        self,
        translator: ITextAI,
        hashtag_generator: IHashtagGenerator,
        price_handler: PriceCalculationHandler,
    ) -> None:
        self._translator: ITextAI = translator
        self._hashtags = HashtagGeneratorStringAdapter(hashtag_generator)  # -> str
        self._price: IPriceMessageFacade = PriceMessageFacade(price_handler)

    async def build_product_content(
        self,
        product: ProductInfo,
        *,
        url: str,
        colors_text: str,
    ) -> ProductContentDTO:
        """
        📦 Повертає повністю заповнений ProductContentDTO.
        ❗ Не повертає None. У випадку збоїв — піднімає виключення (IMP-011).
        """
        logger.info("🧠 Побудова контенту для: %s", product.title)

        # --- Підготовка задач (усе паралельно)
        slogan_task = self._translator.generate_slogan(
            title=product.title,
            description=product.description,
        )
        translate_task = self._translator.translate_sections(text=product.description)
        hashtags_task = self._hashtags.generate(product)            # -> str
        price_task = self._price.calculate_and_format(url)          # -> Tuple[Any, str, List[str]]

        try:
            slogan, sections, hashtags, price_tuple = await asyncio.gather(
                slogan_task,
                translate_task,
                hashtags_task,
                price_task,
            )
        except asyncio.CancelledError:
            # коректно пропускаємо відміну вище
            logger.info("🛑 build_product_content скасовано для: %s", product.title)
            raise
        except Exception as e:
            # не ковтаємо — хай оркестратор перетворить на дружнє повідомлення
            logger.exception("❌ Збій під час побудови контенту для '%s': %s", product.title, e)
            raise

        # --- Явне розпакування та легкі guard-и
        # очікуваний контракт: (_, price_message, images)
        if not isinstance(price_tuple, tuple) or len(price_tuple) < 3:
            # захист від неочікуваної форми відповіді фасаду
            raise ValueError("Price facade returned unexpected result shape.")

        _, price_message, images = price_tuple  # типово перший елемент — службовий об'єкт

        if not isinstance(sections, dict):
            raise TypeError("Translator returned non-dict sections.")

        if not isinstance(hashtags, str):
            raise TypeError("Hashtag generator adapter must return str.")

        if not isinstance(images, list):
            raise TypeError("Images must be a list of URLs.")

        # --- Формування DTO (строго типізовано)
        dto = ProductContentDTO(
            title=product.title,
            slogan=slogan or "",                 # захист від None із зовнішніх сервісів
            hashtags=hashtags or "",
            sections={k: v for k, v in sections.items() if isinstance(k, str) and isinstance(v, str)},
            colors_text=colors_text or "",
            price_message=price_message or "",
            images=[img for img in images if isinstance(img, str) and img],
        )

        logger.info("✅ Контент збудовано: %s", product.title)
        return dto