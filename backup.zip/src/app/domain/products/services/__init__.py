# ⚖️ app/domain/products/services/__init__.py
"""
⚖️ services — доменні сервіси для роботи з продуктами.

Містить:
    • weight_resolver.py — сервіс визначення ваги товарів (локальні дані ➝ AI fallback).
"""

from .weight_resolver import WeightResolver

__all__ = ["WeightResolver"]
