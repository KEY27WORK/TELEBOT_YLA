# 🧠 app/infrastructure/availability/availability_processing_service.py
"""
🧠 availability_processing_service.py — Оркестратор получения полной информации о наличии товара.

Что делает:
  • Извлекает product_path (slug) из входного URL.
  • Строит заголовок карточки товара (название, изображение, ссылка) через ProductHeaderService.
  • Получает агрегированный отчёт о наличии через AvailabilityManager.
  • Склеивает всё в единый DTO `ProcessedAvailabilityData` для дальнейшей отправки ботом.

Особенности:
  • Никакого форматирования под Telegram — только сбор готовых DTO.
  • Аккуратная обработка ошибок (включая asyncio.CancelledError).
  • Структурированные логи и нормализация входных данных.
  • Таймаут ожидания отчёта можно задать аргументом или взять из ConfigService.
"""

from __future__ import annotations

# 🔠 Стандартные импорты
from dataclasses import dataclass
from typing import Optional
import logging
import asyncio

# 🧩 Внутренние модули проекта
from .availability_manager import AvailabilityManager
from .dto import AvailabilityReports
from app.infrastructure.content.product_header_service import (
    ProductHeaderService,
    ProductHeaderDTO,
)
from app.shared.utils.url_parser_service import UrlParserService
from app.config.config_service import ConfigService  # ⬅️ чтобы можно было подтянуть таймаут из конфига

logger = logging.getLogger(__name__)


# ================================
# 📦 DTO ДЛЯ ПОЛНОЙ ИНФОРМАЦИИ
# ================================
@dataclass(frozen=True)
class ProcessedAvailabilityData:
    """🧩 Итоговый пакет данных: заголовок товара + отчёты о наличии."""
    header: ProductHeaderDTO
    reports: AvailabilityReports


# ================================
# 🧠 СЕРВИС ОБРАБОТКИ НАЛИЧИЯ
# ================================
class AvailabilityProcessingService:
    """
    Координирует сбор данных о товаре:
      URL -> slug -> header + availability report -> ProcessedAvailabilityData.
    Не форматирует под Telegram, не ходит в сеть сам — только orchestration.
    """

    def __init__(
        self,
        manager: AvailabilityManager,
        header_service: ProductHeaderService,
        url_parser_service: UrlParserService,
        *,
        report_timeout_sec: Optional[int] = None,
        config: Optional[ConfigService] = None,
    ) -> None:
        """
        Args:
            manager: менеджер получения отчётов о наличии.
            header_service: сервис построения заголовка карточки.
            url_parser_service: парсер для извлечения product_path из URL.
            report_timeout_sec: явный таймаут ожидания отчёта (сек). Если None — будет взят из config.
            config: опциональный ConfigService (availability.report_timeout_sec).
        """
        self.manager = manager
        self.header_service = header_service
        self.url_parser = url_parser_service

        cfg_timeout = None
        try:
            if config is not None:
                # безопасность: тип int, ключ может отсутствовать
                cfg_timeout = config.get("availability.report_timeout_sec", None, int)
        except Exception:
            logger.debug("availability.config_timeout_read_failed")

        self.report_timeout_sec = (
            report_timeout_sec
            if report_timeout_sec is not None
            else cfg_timeout
        )

    # ================================
    # 🔑 ПУБЛИЧНЫЙ МЕТОД
    # ================================
    async def process(self, url: str) -> Optional[ProcessedAvailabilityData]:
        """
        🔄 Основной сценарий: собрать header + availability отчёт для конкретного товара.

        Args:
            url: Полная ссылка на товар.

        Returns:
            ProcessedAvailabilityData или None, если собрать данные не удалось.
        """
        try:
            product_path = self._extract_product_path(url)
            if not product_path:
                logger.warning("availability.url_parse_empty", extra={"url": url})
                return None

            # 1) Заголовок товара
            header = await self.header_service.create_header(product_path)
            if not header:
                logger.warning(
                    "availability.header_failed",
                    extra={"url": url, "product_path": product_path},
                )
                return None

            # 2) Отчёт о наличии
            reports = await self._get_report_with_optional_timeout(product_path)
            if not reports:
                logger.warning(
                    "availability.report_failed",
                    extra={"url": url, "product_path": product_path},
                )
                return None

            logger.info(
                "availability.process_ok",
                extra={"product_path": product_path, "timeout": self.report_timeout_sec},
            )
            return ProcessedAvailabilityData(header=header, reports=reports)

        except asyncio.CancelledError:
            logger.info("availability.processing_cancelled", extra={"url": url})
            raise
        except Exception:
            logger.exception("availability.processing_unhandled", extra={"url": url})
            return None

    # ================================
    # 🔒 ВНУТРЕННИЕ ПОМОЩНИКИ
    # ================================
    def _extract_product_path(self, url: str) -> Optional[str]:
        """Нормализует и вытягивает product_path (slug) из входного URL."""
        if not url or not isinstance(url, str):
            return None
        slug = self.url_parser.extract_product_slug(url)
        if not slug:
            return None
        slug = slug.strip().strip("/")
        return slug or None

    async def _get_report_with_optional_timeout(self, product_path: str) -> Optional[AvailabilityReports]:
        """Оборачивает вызов менеджера в asyncio.wait_for, если задан таймаут."""
        if self.report_timeout_sec and self.report_timeout_sec > 0:
            try:
                return await asyncio.wait_for(
                    self.manager.get_availability_report(product_path),
                    timeout=self.report_timeout_sec,
                )
            except asyncio.TimeoutError:
                logger.warning(
                    "availability.report_timeout",
                    extra={"product_path": product_path, "timeout_sec": self.report_timeout_sec},
                )
                return None
        return await self.manager.get_availability_report(product_path)


__all__ = ["ProcessedAvailabilityData", "AvailabilityProcessingService"]