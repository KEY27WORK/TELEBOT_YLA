# 📦 app/infrastructure/availability/dto.py
"""
📦 dto.py — Data Transfer Object для модуля наявності.

🔹 Клас `AvailabilityReports`:
    • Інкапсулює згенеровані текстові звіти (публічний + адмінський)
    • Іммутабельний (frozen) і компактний (slots)
    • Містить дрібні утиліти для зручної експлуатації (валідація, to_dict, тощо)
"""

from __future__ import annotations

# 🔠 Стандартні імпорти
from dataclasses import dataclass
from typing import Dict, Tuple


# ================================
# 📊 DTO ДЛЯ ЗВІТІВ ПРО НАЯВНІСТЬ
# ================================
@dataclass(frozen=True, slots=True)
class AvailabilityReports:
    """
    📊 DTO для зберігання публічного та адмінського звіту.
    Обидва поля — вже відформатовані рядки, готові до відправки у Telegram.
    """
    public_report: str   # 📄 Повідомлення для користувача
    admin_report: str    # 🔒 Звіт для адміністратора (розширена інформація)

    # ----------------------------
    # 🔧 Корисні утиліти
    # ----------------------------
    def is_blank(self) -> bool:
        """Порожні обидва звіти (після trim)."""
        return not (self.public_report or "").strip() and not (self.admin_report or "").strip()

    def to_tuple(self) -> Tuple[str, str]:
        """Повертає пару рядків (public, admin) — зручно для месенджера."""
        return self.public_report, self.admin_report

    def to_dict(self) -> Dict[str, str]:
        """Серіалізація для логування/кешу/тестів."""
        return {"public_report": self.public_report, "admin_report": self.admin_report}

    def with_prefix(self, prefix: str) -> "AvailabilityReports":
        """
        Повертає новий DTO з доданим префіксом до обох звітів.
        Зручно, якщо треба додати заголовок/легенду зверху.
        """
        p = f"{prefix}{self.public_report}" if prefix else self.public_report
        a = f"{prefix}{self.admin_report}" if prefix else self.admin_report
        return AvailabilityReports(public_report=p, admin_report=a)

    def __str__(self) -> str:
        """
        Коротке представлення — публічний звіт.
        (Зручно у логах або print().)
        """
        return self.public_report


__all__ = ["AvailabilityReports"]