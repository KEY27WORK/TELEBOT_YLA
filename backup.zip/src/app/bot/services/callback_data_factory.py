# 🏭 app/bot/services/callback_data_factory.py
"""
🏭 callback_data_factory.py — Фабрика для створення та парсингу типобезпечних callback-даних.

🔹 Призначення:
    • Централізовано створювати короткі та валідні `callback_data` (до 64 байт)
    • Надійно кодувати параметри (query string) та декодувати їх назад
    • Підтримувати єдиний формат `ns:name?key=value`

✅ Особливості реалізації:
    • Валідація `ns`/`name` (допустимі символи, довжина)
    • Стабільний порядок параметрів (sorted) для відтворюваності
    • Перевірка ліміту 64 байти з урахуванням UTF‑8
    • Перехідна сумісність: старий метод `.id()` збережений (deprecated)
    • Допоміжний метод `.budget_left()` для оцінки «байтового бюджету»
"""

# 🔠 Системні імпорти
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Final, Mapping, Optional, Tuple					# 🧰 Типи для статичної перевірки
from urllib.parse import parse_qs, urlencode								# 🔗 Кодування/декодування query string


# ================================
# ⚙️ КОНСТАНТИ ТА ВАЛІДАЦІЯ
# ================================
TG_CALLBACK_MAX_BYTES: Final[int] = 64									# 📏 Жорсткий ліміт Telegram API для callback_data

# ✅ Дозволені символи та гранична довжина для ns/name
_NS_NAME_RE: Final[re.Pattern[str]] = re.compile(r"^[a-z0-9_:-]{1,32}$")	# 🔐 Валідація базової частини (namespace:name)


# ================================
# 🏛️ КЛАС-КЛЮЧ ДЛЯ CALLBACK
# ================================
@dataclass(frozen=True, slots=True)
class CallbackData:
    """
    🧩 Типобезпечний об'єкт для роботи з callback-даними.

    Забезпечує:
    - Namespace-driven структуру (`ns:name`)
    - Безпечне кодування/декодування параметрів
    - Перевірку ліміту у 64 байти (в UTF-8)
    """

    ns: str															# 📦 Простір імен, напр. "currency"
    name: str														# 🏷️ Ідентифікатор дії, напр. "show_rate"

    # ================================
    # 🔧 ПІСЛЯІНІЦІАЛІЗАЦІЯ (ВАЛІДАЦІЯ)
    # ================================
    def __post_init__(self) -> None:
        """
        ✅ Валідує ns/name одразу при створенні об'єкта.
        Дозволяються лише символи [a-z0-9_:-], довжина ≤ 32; без '?', '&', '='.
        """
        ns = self.ns.strip().lower()										# 🔽 Приводимо до канонічного вигляду
        name = self.name.strip().lower()										# 🔽 Приводимо до канонічного вигляду

        if not (_NS_NAME_RE.match(ns) and _NS_NAME_RE.match(name)):			# 🧪 Перевірка патерном
            raise ValueError(
                f"Некоректні ns/name: '{self.ns}:{self.name}'. "
                "Дозволено [a-z0-9_:-], довжина ≤ 32."
            )

        if any(ch in ns for ch in "?&=") or any(ch in name for ch in "?&="):	# 🛑 Заборонені символи в базовій частині
            raise ValueError("ns та name не повинні містити '?', '&', '='.")

        # Оскільки dataclass frozen=True, оновлюємо через object.__setattr__
        object.__setattr__(self, "ns", ns)										# ♻️ Фіксуємо нормалізовані значення
        object.__setattr__(self, "name", name)									# ♻️ Фіксуємо нормалізовані значення

    # ================================
    # 🆔 КЛЮЧ БЕЗ ПАРАМЕТРІВ
    # ================================
    @property
    def key(self) -> str:
        """Повертає ключ у форматі 'ns:name' без параметрів."""
        return f"{self.ns}:{self.name}"										# 🔑 Базова частина callback_data

    # Перехідна сумісність зі старим API: id() → key
    def id(self) -> str:  # pragma: no cover
        """DEPRECATED: використовуйте .key замість .id()."""
        return self.key														# 🧭 Повертаємо сучасний еквівалент

    # ================================
    # 🏗️ ПОБУДОВА РЯДКА CALLBACK_DATA
    # ================================
    def build(self, params: Optional[Mapping[str, str]] = None) -> str:
        """
        🏗️ Створює фінальний рядок `callback_data` з параметрами.

        Args:
            params: Словник параметрів для кодування (напр., {"sku": "YLA-123"}).

        Returns:
            Рядок, готовий для `InlineKeyboardButton`.

        Raises:
            ValueError: Якщо фінальний рядок перевищує 64 байти.
        """
        base = self.key														# 🔖 Базова частина у форматі ns:name
        payload = base														# 📦 Початкове значення (без параметрів)

        if params:															# 🧮 Якщо є параметри — кодуємо query-послідовність
            # ✅ Стабільний порядок параметрів (sorted) для відтворюваності
            # safe=":_-" — залишає корисні символи некодованими (тонке налаштування під проєкт)
            query_string = urlencode(sorted(params.items()), doseq=False, safe=":_-")	# 🔗 Побудова query string
            if query_string:												# 🧷 Додаємо тільки якщо є пари ключ=значення
                payload = f"{base}?{query_string}"							# 🧵 Об'єднуємо базу з параметрами

        # ✅ Перевірка ліміту з урахуванням UTF‑8
        if len(payload.encode("utf-8")) > TG_CALLBACK_MAX_BYTES:			# 📏 Telegram ліміт 64 байти
            raise ValueError(
                f"Callback data перевищує ліміт Telegram у {TG_CALLBACK_MAX_BYTES} байт: '{payload}'"
            )

        return payload														# ✅ Готове значення для InlineKeyboardButton

    # ================================
    # 📏 ОЦІНКА «БЮДЖЕТУ» БАЙТ
    # ================================
    def budget_left(self, params: Optional[Mapping[str, str]] = None) -> int:
        """
        Повертає кількість байт, що залишилась до ліміту 64B,
        якщо закодувати рядок із переданими параметрами.
        """
        payload = self.build(params or {})									# 🧪 Емуляція фактичної збірки
        return TG_CALLBACK_MAX_BYTES - len(payload.encode("utf-8"))			# 📉 Розрахунок залишку в байтах

    # ================================
    # 🧩 РОЗБІР РЯДКА CALLBACK_DATA
    # ================================
    @staticmethod
    def parse(raw_data: str) -> Tuple["CallbackData", Dict[str, str]]:
        """
        🧩 Розбирає рядок `callback_data` на об'єкт `CallbackData` та параметри.

        Args:
            raw_data: Вхідний рядок від Telegram.

        Returns:
            Кортеж `(CallbackData, словник_параметрів)`.

        Raises:
            ValueError: Якщо формат базової частини не `ns:name`.
        """
        params: Dict[str, str] = {}											# 🗂️ Результат парсингу параметрів
        base = raw_data														# 📄 Базова частина (поки що без параметрів)

        if "?" in raw_data:													# 🔎 Якщо є параметри — відтинаємо їх
            base, query_part = raw_data.split("?", 1)						# ✂️ Розділяємо на базу та query
            # keep_blank_values=False: ігнорує порожні параметри (?sku=)
            # strict_parsing=False: ігноруємо криві пари, не валимо парсинг
            parsed_qs = parse_qs(query_part, keep_blank_values=False, strict_parsing=False)	# 🧵 Парсимо query
            params = {k: v[0] for k, v in parsed_qs.items() if v}			# 〽️ Беремо лише перше значення ключа

        if ":" not in base:													# 🛑 Перевірка базового формату
            raise ValueError(
                "Некоректний формат callback_data: очікується 'ns:name' (без параметрів)."
            )

        ns, name = base.split(":", 1)										# 🧭 Витягуємо namespace і ім'я дії
        return CallbackData(ns, name), params								# ✅ Готовий об'єкт і словник параметрів
