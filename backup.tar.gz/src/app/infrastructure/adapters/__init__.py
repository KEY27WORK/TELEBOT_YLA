# app/infrastructure/adapters/__init__.py
"""
Инфраструктурные адаптеры — тонкие прослойки для согласования интерфейсов.
Содержит:
    • HashtagGeneratorStringAdapter — оборачивает IHashtagGenerator (Set[str]) в API, возвращающий str.
    • IPriceMessageFacade / PriceMessageFacade — фасад над PriceCalculationHandler с единым методом calculate_and_format().
"""

from .hashtag_adapter import HashtagGeneratorStringAdapter
from .price_facade import IPriceMessageFacade, PriceMessageFacade

__all__ = [
    "HashtagGeneratorStringAdapter",
    "IPriceMessageFacade",
    "PriceMessageFacade",
]