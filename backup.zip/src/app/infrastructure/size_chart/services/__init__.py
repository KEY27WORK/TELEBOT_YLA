# 📐 app/infrastructure/size_chart/services/__init__.py
"""
Сервіси для геометрії таблиць розмірів.
"""

from .table_geometry_service import TableGeometryService

__all__ = ["TableGeometryService"]