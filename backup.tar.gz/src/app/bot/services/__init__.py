# 📦 app/bot/services/__init__.py
"""
📦 services — Сервісний шар для Telegram-бота.

🔹 Містить утиліти та інфраструктурні компоненти, які використовуються
   у всіх фічах (features) та хендлерах (handlers).
🔹 Забезпечує єдиний підхід до callback-даних, контексту та реєстрації обробників.

Стандарти:
- Імпорти згруповані та підписані (🌐/🔠/🧩), як у проєктному стайлгайді.
- Експортує публічне API через `__all__`.
- Усі описи — українською, інлайн-коментарі з відступом у 7 табів.
"""

# 🧩 Внутрішні модулі проєкту
from .callback_data_factory import CallbackData							# 🏭 Типобезпечне створення/парсинг callback_data
from .callback_registry import CallbackRegistry							# 🗂️ Централізований реєстр обробників inline-кнопок
from .custom_context import CustomContext								# ✨ Розширений контекст з додатковими атрибутами
from .types import CallbackHandlerType, Registrable						# 🧰 Загальні типи/протоколи для сервісів і фіч

# ================================
# 🧭 ПУБЛІЧНЕ API МОДУЛЯ
# ================================
__all__ = [
    "CallbackData",            										# 🏷️ Експортуємо фабрику callback-даних
    "CallbackRegistry",        										# 📚 Експортуємо реєстр обробників
    "CustomContext",           										# 🧠 Експортуємо розширений контекст
    "CallbackHandlerType",     										# 🔗 Тип підпису хендлерів callback-кнопок
    "Registrable",             										# 🧩 Протокол для реєстрованих компонентів
]
