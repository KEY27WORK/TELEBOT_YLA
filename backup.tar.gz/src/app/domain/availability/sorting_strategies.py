# 🧩 app/domain/availability/sorting_strategies.py
"""
🧩 sorting_strategies.py — ключи сортировки размеров.

Навіщо окремий модуль:
- Дає можливість інʼєктувати різні стратегії сортування в доменний сервіс.
- Тестувати та розвивати сортування незалежно від бізнес‑логіки.

🔹 default_size_sort_key:
  1) Відомі літерні розміри у фіксованому порядку (XXXS..XXXL)
  2) Числові (включно з дробами 42.5 / 42,5) — за зростанням
  3) Усе інше — лексикографічно
"""

from __future__ import annotations

from typing import Callable, Tuple

# Тип ключа сортування (важливо, щоб кортежі можна було порівнювати між собою)
SizeKey = Callable[[str], Tuple[int, int, str]]

# Фіксований порядок літерних розмірів
_KNOWN_ALPHA: Tuple[str, ...] = (
    "XXXS", "XXS", "XS", "S", "M", "L", "XL", "XXL", "XXXL",
)


def _normalize(size: str) -> str:
    """Трим + upper для стабільності порівнянь."""
    return (size or "").strip().upper()


def default_size_sort_key(size: str) -> Tuple[int, int, str]:
    """
    Універсальний ключ сортування:
      0) відомі літерні → (0, index, "")
      1) числові (у т.ч. '42.5' / '42,5') → (1, int(num*100), "")
      2) інше → (2, 0, lexicographic)
    """
    s = _normalize(size)

    # 1) Літерні
    if s in _KNOWN_ALPHA:
        return (0, _KNOWN_ALPHA.index(s), "")

    # 2) Числові (підтримка десяткових крапки/коми)
    try:
        num = float(s.replace(",", "."))
        # множимо, щоб 42.5 < 42.6 тощо, і звести до int для порівнянь
        return (1, int(round(num * 100)), "")
    except ValueError:
        pass

    # 3) Решта — лексикографічно
    return (2, 0, s)


__all__ = [
    "SizeKey",
    "default_size_sort_key",
]