# 📦 app/infrastructure/availability/availability_manager.py
"""
📦 availability_manager.py — Управление проверкой наличия товаров в разных регионах.

✅ Класс `AvailabilityManager`:
    • Параллельно проверяет доступность товара в регионах (US, EU, UK, …)
    • Собирает доменный отчёт и превращает его в текстовые отчёты (через ReportBuilder)
    • Использует доменный сервис для агрегации данных (чистый слой)
    • Экспортирует метрики Prometheus (кэш‑хиты/промахи, латентность сборки отчёта)
"""

from __future__ import annotations

# 🔠 Стандартные импорты
import asyncio
import logging
from typing import Any, Dict, List, Mapping, Optional

# 🧩 Внутренние модули проекта
from app.config.config_service import ConfigService
from app.infrastructure.parsers.parser_factory import ParserFactory
from .cache_service import AvailabilityCacheService
from .dto import AvailabilityReports
from .report_builder import AvailabilityReportBuilder
from app.domain.availability.interfaces import IAvailabilityService, RegionStock
from app.domain.availability.status import AvailabilityStatus
from app.shared.utils.logger import LOG_NAME
from app.shared.utils.url_parser_service import UrlParserService
from .metrics import AV_CACHE_HITS, AV_CACHE_MISSES, AV_REPORT_LATENCY  # 📈 метрики

logger = logging.getLogger(LOG_NAME)


# ================================
# 🔧 Адаптация карт bool → AvailabilityStatus
# ================================
def _to_status(value: Any) -> AvailabilityStatus:
    """Нормирует произвольное значение к AvailabilityStatus."""
    if isinstance(value, AvailabilityStatus):
        return value
    if value is True:
        return AvailabilityStatus.YES
    if value is False:
        return AvailabilityStatus.NO
    # Всё остальное трактуем как UNKNOWN (None/пусто/левое значение)
    return AvailabilityStatus.UNKNOWN


def _adapt_stock_data(
    raw: Optional[Mapping[str, Mapping[str, Any]]]
) -> Dict[str, Dict[str, AvailabilityStatus]]:
    """
    Принимает то, что вернул парсер (обычно Dict[color][size] -> bool),
    и возвращает Dict[color][size] -> AvailabilityStatus.
    Пустые/некорректные ключи отбрасываются.
    """
    out: Dict[str, Dict[str, AvailabilityStatus]] = {}
    if not raw:
        return out

    for color, sizes in raw.items():
        if not color or not sizes:
            continue
        color_key = str(color).strip()
        if not color_key:
            continue

        dst = out.setdefault(color_key, {})
        for size, flag in sizes.items():
            size_key = str(size).strip()
            if not size_key:
                continue
            dst[size_key] = _to_status(flag)
    return out


# ================================
# 🧠 КЛАСС УПРАВЛЕНИЯ НАЛИЧИЕМ
# ================================
class AvailabilityManager:
    """
    🧠 Координирует сбор данных о наличии по регионам и формирует DTO‑отчёты.
    """

    def __init__(
        self,
        availability_service: IAvailabilityService,
        parser_factory: ParserFactory,
        cache_service: AvailabilityCacheService,
        report_builder: AvailabilityReportBuilder,
        config_service: ConfigService,
        url_parser_service: UrlParserService,
    ) -> None:
        self.availability_service = availability_service
        self.parser_factory = parser_factory
        self.cache = cache_service
        self.report_builder = report_builder
        self.config = config_service
        self.url_parser = url_parser_service

        # ⚠️ ConfigService.get может вернуть None — страхуемся default+cast
        self.cache_ttl: int = int(self.config.get("availability.cache_ttl_sec", 300, int) or 300)

        # Список регионов из конфига (dict с ключами‑кодами)
        regions_obj = self.config.get("regions", {}, dict) or {}
        self.regions: Dict[str, dict] = dict(regions_obj)

    # ================================
    # 📣 Публичный метод
    # ================================
    async def get_availability_report(self, product_path: str) -> AvailabilityReports:
        """
        🗃️ Формирует полный отчёт о наличии по регионам.
        Ведёт метрики кэша и времени сборки.
        """
        # 1) Попытка отдать из кэша
        cached_report = self.cache.get(product_path, self.cache_ttl)
        if isinstance(cached_report, AvailabilityReports):
            AV_CACHE_HITS.inc()
            logger.info("availability.cache hit product_path=%s", product_path)
            return cached_report

        # 2) Кэша нет — собираем и меряем время
        AV_CACHE_MISSES.inc()
        with AV_REPORT_LATENCY.time():
            regional_stocks = await self._fetch_all_regions(product_path)
            domain_report_dto = self.availability_service.create_report(regional_stocks)
            final_reports_dto = self.report_builder.build(
                region_results=regional_stocks,
                report_dto=domain_report_dto,
            )
            # 3) Кэшируем и отдаём
            self.cache.set(product_path, final_reports_dto)
            return final_reports_dto

    # ================================
    # 🔒 Внутренние методы
    # ================================
    async def _fetch_all_regions(self, product_path: str) -> List[RegionStock]:
        """
        🔄 Параллельно собирает RegionStock для всех регионов.
        """
        tasks = [self._fetch_region_data(code, product_path) for code in self.regions.keys()]
        return await asyncio.gather(*tasks)

    async def _fetch_region_data(self, region_code: str, product_path: str) -> RegionStock:
        """
        📥 Загружает данные о товаре для конкретного региона.
        """
        url = self.url_parser.build_product_url(region_code, product_path)
        if not url:
            logger.error("❌ Не удалось построить URL для региона %s", region_code)
            # Пустая карта → в «легенде» регион будет помечен как ❔
            return RegionStock(region_code=region_code, stock_data={})

        try:
            parser = self.parser_factory.create_product_parser(url, enable_progress=False)
            product_info = await parser.get_product_info()

            # Если парсер ничего не вернул / вернул ошибку — считаем «неизвестно»
            if not product_info or getattr(product_info, "title", None) == "Помилка":
                return RegionStock(region_code=region_code, stock_data={})

            # Адаптируем bool → Enum (и чистим ключи)
            status_stock = _adapt_stock_data(getattr(product_info, "stock_data", None))
            return RegionStock(region_code=region_code, stock_data=status_stock)

        except asyncio.CancelledError:
            # Важно пробросить отмену выше
            logger.info("Задача получения данных для региона %s была отменена", region_code)
            raise
        except Exception as e:
            logger.error("❌ Ошибка получения данных для региона %s: %s", region_code, e)
            # Пустая карта — в отчёте регион будет «❔»
            return RegionStock(region_code=region_code, stock_data={})