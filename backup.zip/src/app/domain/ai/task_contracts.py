# app/domain/ai/task_contracts.py
from __future__ import annotations

"""
Доменні контракти для AI-завдань (вага / переклад секцій / слоган).

❗ Важливо:
- Це чистий домен: лише інтерфейси (Protocol) без залежностей від інфраструктури.
- Протоколи позначені як @runtime_checkable — можна безпечно перевіряти isinstance/issubclass.
"""

from typing import Dict, Protocol, runtime_checkable


@runtime_checkable
class IWeightEstimator(Protocol):
    """Оцінка ваги товару. Результат — грами (ціле число)."""
    async def estimate_weight_g(self, *, title: str, description: str, image_url: str) -> int: ...


@runtime_checkable
class ITranslator(Protocol):
    """
    Переклад і структурування опису в секції
    (наприклад: МАТЕРІАЛ, ПОСАДКА, ОПИС, МОДЕЛЬ).
    """
    async def translate_sections(self, *, text: str) -> Dict[str, str]: ...


@runtime_checkable
class ISloganGenerator(Protocol):
    """Генерація короткого слогану українською у стилі бренду."""
    async def generate_slogan(self, *, title: str, description: str) -> str: ...


@runtime_checkable
class ITextAI(ITranslator, ISloganGenerator, Protocol):
    """
    Комбо-протокол: сервіс уміє і переклад секцій, і генерацію слогану.
    Зручно інʼєктувати один об’єкт замість двох окремих контрактів.
    """
    ...


__all__ = [
    "IWeightEstimator",
    "ITranslator",
    "ISloganGenerator",
    "ITextAI",
]