# 🧩 app/domain/delivery/__init__.py
"""
🚚 delivery — доменно‑орієнтовані контракти для сервісів доставки.

Публічний API пакета:
• DTO: DeliveryQuote
• Контракти: IDeliveryService
"""

from .interfaces import DeliveryQuote, IDeliveryService

__all__ = [
    "DeliveryQuote",
    "IDeliveryService",
]
