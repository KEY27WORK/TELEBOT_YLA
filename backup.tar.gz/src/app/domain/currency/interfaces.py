# 💱 app/domain/currency/interfaces.py
"""
Доменні контракти/DTO для валюти.

✔ IMoneyConverter — НОВИЙ основний API на Decimal + Money DTO.
✔ ICurrencyConverter — ЛЕГАСІ float‑API, помічений як @deprecated (лише для сумісності).
✔ ICurrencyRatesProvider — контракт провайдера курсів (асинхронний менеджер/сервіс).

Мета staged‑rollout:
1) Новий код пишемо під IMoneyConverter (Decimal).
2) Поступово мігруємо зі старого ICurrencyConverter.
3) Після міграції видаляємо ICurrencyConverter (за потреби перейменовуємо IMoneyConverter → ICurrencyConverter).
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Dict, NewType, Protocol, Union
from typing_extensions import deprecated

# ──────────────────────────────────────────────────────────────────────────────
# Типи та DTO
# ──────────────────────────────────────────────────────────────────────────────

# ISO‑4217 код валюти (наприклад, "USD", "EUR", "UAH")
CurrencyCode = NewType("CurrencyCode", str)


@dataclass(frozen=True, slots=True)
class Money:
    """
    Невід’ємний грошовий DTO:
    - amount: Decimal (точні розрахунки без помилок float)
    - currency: CurrencyCode ("USD"/"EUR"/"UAH"/...)
    """
    amount: Decimal
    currency: CurrencyCode


class CurrencyRateNotFoundError(ValueError):
    """
    Доменно-специфічне виключення для відсутнього курсу конвертації.
    """
    def __init__(
        self,
        from_currency: Union[str, CurrencyCode],
        to_currency: Union[str, CurrencyCode],
    ) -> None:
        self.from_currency = str(from_currency)
        self.to_currency = str(to_currency)
        super().__init__(
            f"Exchange rate from {self.from_currency} to {self.to_currency} not found."
        )


# ──────────────────────────────────────────────────────────────────────────────
# Інтерфейси конвертації
# ──────────────────────────────────────────────────────────────────────────────

@deprecated("Легасі float‑API. Використовуйте IMoneyConverter з Decimal та Money DTO.")
class ICurrencyConverter(Protocol):
    """
    @deprecated
    Старий синхронний інтерфейс конвертації на базі float.
    Залишений лише для зворотної сумісності під час staged‑міграції.
    Новий код НЕ повинен його використовувати.
    """
    def convert(self, amount: float, from_currency: str, to_currency: str) -> float: ...
    # noqa: D401


class IMoneyConverter(Protocol):
    """
    Новий точний інтерфейс конвертації на базі Decimal та Money DTO.

    Конкретні реалізації можуть підтримувати різні стратегії округлення
    (за замовчуванням рекомендуємо «банківське»: ROUND_HALF_EVEN).
    """
    def convert_money(self, money: Money, to_currency: CurrencyCode) -> Money: ...
    # noqa: D401


# ──────────────────────────────────────────────────────────────────────────────
# Контракт провайдера курсів (менеджер курсів)
# ──────────────────────────────────────────────────────────────────────────────

class ICurrencyRatesProvider(Protocol):
    """
    Асинхронний провайдер/менеджер курсів, який віддає snapshot‑конвертери.
    Зобов’язує до Decimal‑першого зберігання курсів.
    """

    # Життєвий цикл
    async def initialize(self) -> None: ...
    async def close(self) -> None: ...

    # Оновлення курсів
    async def update_all_rates_if_needed(self) -> None: ...
    async def update_all_rates(self) -> None: ...
    async def set_rate_manually(
        self,
        currency: str,
        rate: Union[Decimal, float, int, str],
    ) -> None: ...

    # Отримання конвертерів (snapshot на момент виклику)
    def get_money_converter(self) -> IMoneyConverter: ...
    def get_converter(self) -> ICurrencyConverter: ...  # легасі для зворотної сумісності

    # Доступ до даних курсів/стану
    def get_all_rates(self) -> Dict[str, Decimal]: ...
    @property
    def last_update_ts(self) -> float: ...
    def is_cache_fresh(self) -> bool: ...


__all__ = [
    "CurrencyCode",
    "Money",
    "CurrencyRateNotFoundError",
    "ICurrencyConverter",
    "IMoneyConverter",
    "ICurrencyRatesProvider",
]