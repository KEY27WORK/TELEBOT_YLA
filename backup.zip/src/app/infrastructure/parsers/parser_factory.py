# 🏭 app/infrastructure/parsers/parser_factory.py
"""
🏭 ParserFactory — фабрика конкретных парсеров (infrastructure-уровень).

Задачи:
  • Создаёт экземпляры парсеров: товара, коллекций, (опционально) поиска.
  • Инъектирует общие сервисы (WebDriverService, TranslatorService, WeightResolver,
    UrlParserService, ConfigService).
  • Использует ЕДИНЫЙ класс опций из _infra_options.ParserInfraOptions.
  • Поддерживает точечные override’ы при создании парсера товара.
  • Без рефлексии/инспекции сигнатур: таймауты передаются явно.

Важно:
  • Для верхних слоёв используйте адаптер (ParserFactoryAdapter), чтобы зависеть от доменных интерфейсов.
"""

from __future__ import annotations

from typing import Any, Final, Optional, final
import logging

from app.config.config_service import ConfigService
from app.domain.products.services.weight_resolver import WeightResolver
from app.infrastructure.ai.ai_task_service import AITaskService as TranslatorService
from app.infrastructure.web.webdriver_service import WebDriverService
from app.shared.utils.url_parser_service import UrlParserService
from app.shared.utils.logger import LOG_NAME

from .base_parser import BaseParser
from .collections.universal_collection_parser import UniversalCollectionParser
from .product_search.search_resolver import ProductSearchResolver
from ._infra_options import ParserInfraOptions as _InfraOptions

__all__: Final = ["ParserFactory", "ParserInfraOptions"]
ParserInfraOptions = _InfraOptions

_ALLOWED_HTML_PARSERS: tuple[str, ...] = ("lxml", "html.parser", "html5lib")


@final
class ParserFactory:
    __slots__ = (
        "_webdriver_service",
        "_translator_service",
        "_weight_resolver",
        "_config_service",
        "_url_parser_service",
        "_default_options",
        "_log",
    )

    def __init__(
        self,
        webdriver_service: WebDriverService,
        translator_service: TranslatorService,
        weight_resolver: WeightResolver,
        config_service: ConfigService,
        url_parser_service: UrlParserService,
        default_options: _InfraOptions | None = None,
    ) -> None:
        self._webdriver_service = webdriver_service
        self._translator_service = translator_service
        self._weight_resolver = weight_resolver
        self._config_service = config_service
        self._url_parser_service = url_parser_service
        self._default_options = default_options or _InfraOptions.default()
        self._log = logging.getLogger(__name__)

        # ✅ Выставляем уровень логирования из опций (если задан)
        try:
            level = self._default_options.effective_log_level()
            logging.getLogger(LOG_NAME).setLevel(level)
            logging.getLogger(__name__).setLevel(level)
        except Exception:
            pass

    @staticmethod
    def _normalize_url(url: str) -> str:
        u = (url or "").strip()
        if not u:
            return u
        if u.startswith("//"):
            return "https:" + u
        if u.startswith(("http://", "https://")):
            return u
        return u

    def _pick_html_parser(self, name: Optional[str]) -> str:
        if name in _ALLOWED_HTML_PARSERS:
            return name  # type: ignore[return-value]
        if name is not None:
            logging.getLogger(__name__).warning(
                "Unknown HTML parser '%s' → fallback to 'lxml'", name
            )
        return "lxml"

    @staticmethod
    def _ensure_non_empty_url(url: str, who: str) -> None:
        if not isinstance(url, str) or not url.strip():
            raise ValueError(f"{who}: 'url' must be a non-empty string")

    # ──────────────────────────────────────────────────────────────────────
    # ТОВАР
    # ──────────────────────────────────────────────────────────────────────
    def create_product_parser(self, url: str, **overrides: Any) -> BaseParser:
        self._ensure_non_empty_url(url, "ParserFactory.create_product_parser")
        norm_url = self._normalize_url(url)

        opts = self._default_options
        html_parser = self._pick_html_parser(overrides.get("html_parser", opts.html_parser))
        enable_progress = bool(overrides.get("enable_progress", opts.enable_progress))
        request_timeout_sec = float(overrides.get("request_timeout_sec", opts.request_timeout_sec))
        # NEW: единый лимит картинок прокидываем в BaseParser
        images_limit = int(overrides.get("images_limit", opts.images_limit))
        # Примечание: filter_small_images будет использован в HtmlDataExtractor,
        # его прокинем после расширения BaseParser/Extractor.

        kwargs: dict[str, Any] = dict(
            url=norm_url,
            webdriver_service=self._webdriver_service,
            translator_service=self._translator_service,
            config_service=self._config_service,
            weight_resolver=self._weight_resolver,
            url_parser_service=self._url_parser_service,
            html_parser=html_parser,
            enable_progress=enable_progress,
            # 👇 без рефлексии — передаём явно
            request_timeout_sec=int(request_timeout_sec),
            images_limit=images_limit,
        )
        return BaseParser(**kwargs)

    # ──────────────────────────────────────────────────────────────────────
    # КОЛЛЕКЦИЯ
    # ──────────────────────────────────────────────────────────────────────
    def create_collection_parser(self, url: str) -> UniversalCollectionParser:
        self._ensure_non_empty_url(url, "ParserFactory.create_collection_parser")
        norm_url = self._normalize_url(url)
        return UniversalCollectionParser(
            url=norm_url,
            webdriver_service=self._webdriver_service,
            config_service=self._config_service,
            url_parser_service=self._url_parser_service,
            # единый выбор парсера из опций
            html_parser=self._pick_html_parser(self._default_options.html_parser),
        )

    # ──────────────────────────────────────────────────────────────────────
    # ПОИСК
    # ──────────────────────────────────────────────────────────────────────
    def create_search_provider(self) -> ProductSearchResolver:
        """
        Строго типизированный провайдер поиска (без двойного пути class/instance).
        """
        return ProductSearchResolver(
            webdriver_service=self._webdriver_service,
            url_parser_service=self._url_parser_service,
            config_service=self._config_service,
        )