# app/domain/size_chart/interfaces.py
from __future__ import annotations
from typing import List, Tuple, Protocol, runtime_checkable, Optional
from app.shared.utils.prompts import ChartType

Url = str  # простая алиас-типизация

@runtime_checkable
class ISizeChartFinder(Protocol):
    """Контракт: как мы находим ссылки на таблицы размеров в HTML."""
    def find_images(self, page_source: str) -> List[Tuple[Url, ChartType]]: ...

@runtime_checkable
class ISizeChartService(Protocol):
    """Контракт: оркестратор полного цикла обработки таблиц размеров."""
    async def process_all_size_charts(self, page_source: str) -> List[str]: ...