# 🛡️ app/errors/exception_handler_service.py
"""
Центральный сервис обработки ошибок. Ничего не знает про конкретные библиотеки —
получает список стратегий через DI и применяет их по очереди.
"""

from __future__ import annotations

import asyncio
import logging
from typing import List, Optional

from telegram import Update

from .custom_errors import AppError, UserVisibleError
from .strategies import IErrorHandlingStrategy
from app.bot.ui import static_messages as msg
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


class ExceptionHandlerService:
    """Глобальный диспетчер ошибок для асинхронных Telegram-хендлеров."""

    def __init__(self, strategies: List[IErrorHandlingStrategy]) -> None:
        self._strategies = list(strategies)

    async def handle(self, error: Exception, update: Optional[Update]) -> None:
        if isinstance(error, asyncio.CancelledError):
            # Нельзя «проглатывать» отмену — это управляющий сигнал
            raise

        # 1) Пытаемся конвертировать в наш AppError
        domain_error: Optional[AppError] = None
        for strategy in self._strategies:
            try:
                converted = strategy.handle(error)
            except Exception:  # стратегия не должна валить общий обработчик
                logger.exception("Ошибка внутри стратегии обработки исключений: %r", strategy)
                continue
            if converted:
                domain_error = converted
                break

        # 2) Если и так наш AppError — используем его
        if not domain_error and isinstance(error, AppError):
            domain_error = error

        user_id = "N/A"
        try:
            if update and update.effective_user:
                user_id = str(update.effective_user.id)
        except Exception:
            pass

        # 3) Решаем, что показывать пользователю и что писать в логи
        if isinstance(domain_error, UserVisibleError):
            extra = {}  # аккуратный контекст для логов
            try:
                extra = domain_error.to_log_extra()
            except Exception:
                pass

            logger.warning(
                "Обработанное предупреждение для user=%s: %s",
                user_id,
                domain_error,
                extra=extra,
            )
            await self._safe_reply(update, domain_error.message)
            return

        # 4) Критическая необработанная ошибка
        logger.exception("🔥 Необработанная ошибка для user=%s: %s", user_id, error)
        await self._safe_reply(update, msg.ERROR_CRITICAL)

    async def _safe_reply(self, update: Optional[Update], text: str) -> None:
        """Тихо пытается отправить сообщение пользователю и никогда не валит обработчик."""
        if not update:
            return

        # Пытаемся найти message (в update.message или update.effective_message)
        message = getattr(update, "message", None) or getattr(update, "effective_message", None)
        if not message:
            return

        try:
            await message.reply_text(text)
        except Exception as send_err:
            logger.warning("Не удалось отправить сообщение про ошибку: %s", send_err)