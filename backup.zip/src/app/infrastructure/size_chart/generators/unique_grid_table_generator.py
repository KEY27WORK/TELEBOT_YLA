from __future__ import annotations

import logging
from typing import Dict

from app.shared.utils.logger import LOG_NAME
from app.infrastructure.image_generation.font_service import FontService
from app.domain.image_generation.interfaces import FontType, FontLike
from .base_generator import BaseTableGenerator

logger = logging.getLogger(LOG_NAME)


class UniqueGridTableGenerator(BaseTableGenerator):
    """
    Сіткова таблиця (height × weight → size).

    Ожидаемые данные:
    {
        "Title": "...",
        "170": {"60": "S", "70": "M", ...},
        "175": {"60": "M", "70": "L", ...},
        ...
    }
    """

    # базовые значения (масштабируются от канвы)
    _TITLE_PT = 50
    _HEADER_PT = 40
    _CELL_PT = 30
    _ROW_HEIGHT = 80
    _TITLE_GAP = 20
    _LINE_GAP = 20
    _BORDER = 2

    def __init__(self, size_chart: dict, output_path: str, font_service: FontService, **kwargs) -> None:
        super().__init__(size_chart, output_path, font_service, **kwargs)

        # Оси: всё кроме Title/Розмір берём как «рост → {вес: размер}»
        self.grid: Dict[str, Dict[str, str]] = {
            k: v for k, v in self.size_chart.items() if isinstance(v, dict)
        }
        self.heights = list(self.grid.keys())
        self.weights = list(next(iter(self.grid.values())).keys()) if self.grid else []

        # масштаб шрифтов от канвы
        scale = max(min(self.IMG_WIDTH / 1600, self.IMG_HEIGHT / 1200), 0.7)

        self.title_font: FontLike = self.font_service.get_font(FontType.BOLD, int(self._TITLE_PT * scale))
        self.header_font: FontLike = self.font_service.get_font(FontType.BOLD, int(self._HEADER_PT * scale))
        self.cell_font: FontLike = self.font_service.get_font(FontType.MONO, int(self._CELL_PT * scale))

        self.row_h = int(self._ROW_HEIGHT * scale)
        self.title_gap = int(self._TITLE_GAP * scale)
        self.line_gap = int(self._LINE_GAP * scale)
        self.border = max(int(self._BORDER * scale), 1)

        # геометрия
        self._calc_geometry()

    def _calc_geometry(self) -> None:
        total_w = int(self.IMG_WIDTH - 2 * self.PADDING)
        total_h = int(self.IMG_HEIGHT - 2 * self.PADDING)

        title_pt = int(getattr(self.title_font, "size", self._TITLE_PT))
        title_block_h = int(title_pt + self.title_gap + self.line_gap)
        table_h_avail = max(total_h - title_block_h, self.row_h * 2)

        rows = max(len(self.heights) + 1, 2)  # +1 строка под заголовки веса
        self.cell_h = min(self.row_h, table_h_avail // rows)

        cols = max(len(self.weights) + 1, 2)  # +1 левый столбец под рост
        self.cell_w = max(60, total_w // cols)

        self.title_center_y = int(self.PADDING + title_pt // 2)
        self.line_y = int(self.PADDING + title_block_h)
        self.table_x0 = int(self.PADDING)
        self.table_y0 = int(self.line_y + self.line_gap)

    def _draw_title_and_line(self) -> None:
        self.draw_text_centered(self.title, int(self.IMG_WIDTH // 2), int(self.title_center_y), self.title_font)
        self.draw.line(
            [(int(self.PADDING), int(self.line_y)), (int(self.IMG_WIDTH - self.PADDING), int(self.line_y))],
            fill="black",
            width=max(self.border, 2),
        )

    def _draw_headers(self) -> None:
        y = int(self.table_y0)
        x = int(self.table_x0)

        # пустая верхняя-левая ячейка
        self._cell_border(x, y, self.cell_w, self.cell_h)
        x += self.cell_w

        for w in self.weights:
            self._cell_border(x, y, self.cell_w, self.cell_h)
            self.draw_text_centered(w, int(x + self.cell_w // 2), int(y + self.cell_h // 2), self.header_font)
            x += self.cell_w

    def _draw_rows(self) -> None:
        y = int(self.table_y0 + self.cell_h)
        for h in self.heights:
            x = int(self.table_x0)
            # заголовок строки — рост
            self._cell_border(x, y, self.cell_w, self.cell_h)
            self.draw_text_centered(h, int(x + self.cell_w // 2), int(y + self.cell_h // 2), self.header_font)
            x += self.cell_w

            for w in self.weights:
                self._cell_border(x, y, self.cell_w, self.cell_h)
                val = self.grid.get(h, {}).get(w, "")
                self._draw_cell_value(val, x, y)
                x += self.cell_w

            y += self.cell_h

    def _draw_cell_value(self, val: str, x_left: int, y_top: int) -> None:
        text = str(val)
        font: FontLike = self.cell_font

        # Если текст не влазит — поджимаем в разумных пределах
        while self.draw.textlength(text, font=font) > self.cell_w - 10 and int(getattr(font, "size", 0)) > 10:
            new_size = max(10, int(getattr(font, "size", 16)) - 2)
            font = self.font_service.get_font(FontType.MONO, new_size)

        self.draw_text_centered(text, int(x_left + self.cell_w // 2), int(y_top + self.cell_h // 2), font)

    def _cell_border(self, x: int, y: int, w: int, h: int) -> None:
        self.draw.rectangle([(int(x), int(y)), (int(x + w), int(y + h))], outline="black", width=int(self.border))

    async def generate(self) -> str:
        logger.info("🚀 Генерація сіткової таблиці...")
        self._draw_title_and_line()
        self._draw_headers()
        self._draw_rows()
        logger.info("✅ Таблиця успішно збережена: %s", self.output_path)
        return self.save_png()