# 📖 constants.py
"""
📖 Єдиний типобезпечний контракт для всіх констант проєкту.

🔹 Структуровано через імутабельні dataclass-и з `slots=True`.
🔹 Групи: UI (тексти/емодзі) та LOGIC (режими/команди/ключі/валюти/мапи).
🔹 Синхронізовано з новою структурою YAML-конфігів:
    - app/config/config.yaml
        • regions: {us, eu, uk}
        • pricing.regional_costs: {us, eu, uk, pl} з country_code: {"us","germany","uk","poland"}
        • telegram.http.* (рекомендовано)
    - app/config/delivery.yaml
        • delivery.meest.tariffs: {us, uk, germany, poland}
🔹 Є legacy-враппер generate_menu_pattern() для сумісності.
"""

# 🔠 Системні імпорти
import re
from dataclasses import dataclass, fields
from types import MappingProxyType
from typing import Final, List, Mapping

# 🧩 Внутрішні модулі проєкту
from app.bot.services.callback_data_factory import CallbackData


# ==================================
# 🏛️ СТРУКТУРА КОНСТАНТ (UI)
# ==================================

@dataclass(frozen=True, slots=True)
class _ReplyButtons:
    """Кнопки для ReplyKeyboardMarkup (головне меню)."""
    INSERT_LINKS: Final[str] = "🔗 Вставляти посилання товарів"
    MY_ORDERS: Final[str] = "📦 Мої замовлення"
    COLLECTION_MODE: Final[str] = "📚 Режим колекцій"
    SIZE_CHART_MODE: Final[str] = "📏 Таблиця розмірів"
    CURRENCY: Final[str] = "💱 Курс валют"
    HELP: Final[str] = "❓ Допомога"
    PRICE_CALC_MODE: Final[str] = "🧮 Режим розрахунку товару"
    REGION_AVAILABILITY: Final[str] = "🌍 Перевірити розміри в регіонах"
    DISABLE_MODE: Final[str] = "⏹️ Вимкнути режим"


@dataclass(frozen=True, slots=True)
class _InlineButtons:
    """Тексти для InlineKeyboardButton."""
    SHOW_RATE: Final[str] = "📊 Показати курс"
    SET_RATE: Final[str] = "✏️ Встановити курс"
    HELP_FAQ: Final[str] = "📝 FAQ"
    HELP_USAGE: Final[str] = "📖 Як користуватись ботом?"
    HELP_SUPPORT: Final[str] = "📞 Зв'язатися з підтримкою"


@dataclass(frozen=True, slots=True)
class _Callbacks:
    """Ключі для callback‑запитів (типізовані через CallbackData)."""
    CURRENCY_SHOW_RATE: Final[CallbackData] = CallbackData(ns="currency", name="show_rate")
    CURRENCY_SET_RATE: Final[CallbackData] = CallbackData(ns="currency", name="set_rate")
    HELP_SHOW_FAQ:     Final[CallbackData] = CallbackData(ns="help",     name="faq")
    HELP_SHOW_USAGE:   Final[CallbackData] = CallbackData(ns="help",     name="usage")
    HELP_SHOW_SUPPORT: Final[CallbackData] = CallbackData(ns="help",     name="support")


@dataclass(frozen=True, slots=True)
class _UIConstants:
    """Константи UI (тексти, емодзі)."""
    DEFAULT_PARSE_MODE: Final[str] = "HTML"
    REPLY_BUTTONS: Final[_ReplyButtons]   = _ReplyButtons()
    INLINE_BUTTONS: Final[_InlineButtons] = _InlineButtons()


# ==================================
# ⚙️ СТРУКТУРА КОНСТАНТ (LOGIC)
# ==================================

@dataclass(frozen=True, slots=True)
class _Modes:
    """Ідентифікатори режимів роботи бота."""
    PRODUCT:             Final[str] = "product"
    COLLECTION:          Final[str] = "collection"
    SIZE_CHART:          Final[str] = "size_chart"
    REGION_AVAILABILITY: Final[str] = "region_availability"
    PRICE_CALCULATION:   Final[str] = "price_calculation"


@dataclass(frozen=True, slots=True)
class _Commands:
    """Ідентифікатори команд Telegram‑бота (без префікса '/')."""
    START:    Final[str] = "start"
    HELP:     Final[str] = "help"
    RATE:     Final[str] = "rate"
    SET_RATE: Final[str] = "set_rate"


@dataclass(frozen=True, slots=True)
class _UserData:
    """Ключі для словника user_data (дані сеансу користувача)."""
    MODE: Final[str] = "mode"
    URL:  Final[str] = "url"


@dataclass(frozen=True, slots=True)
class _Limits:
    """Ліміти для обробки."""
    MAX_PRODUCTS_PER_COLLECTION: Final[int] = 120
    COLLECTION_PROGRESS_EVERY:   Final[int] = 5


@dataclass(frozen=True, slots=True)
class _Timeouts:
    """Тайм‑аути для операцій."""
    PRODUCT_PROCESS_SEC: Final[int] = 60


@dataclass(frozen=True, slots=True)
class _Conversions:
    """Коефіцієнти для конвертації одиниць."""
    LBS_PER_KG: Final[float] = 2.20462


@fdghxdataclass(frozen=True, slots=True)
class _LogicConstants:
    """
    Константи, що визначають логіку (режими, команди, ключі user_data, валюти, мапи).
    Синхронізовано з YAML-конфігами.
    """
    # ✅ Префікс ENV для config_service (_load_from_env)
    ENV_PREFIX: Final[str] = "APP_"

    # ====== Режими / Команди / Ключі / Ліміти / Тайм-аути / Конверсії ======
    MODES:       Final[_Modes]       = _Modes()
    COMMANDS:    Final[_Commands]    = _Commands()
    USER_DATA:   Final[_UserData]    = _UserData()
    LIMITS:      Final[_Limits]      = _Limits()
    TIMEOUTS:    Final[_Timeouts]    = _Timeouts()
    CONVERSIONS: Final[_Conversions] = _Conversions()

    # ====== Валюти та відображення ======
    # Символи валют для зручного форматування
    CURRENCY_SYMBOLS: Final[Mapping[str, str]] = MappingProxyType({
        "USD": "$",
        "EUR": "€",
        "GBP": "£",
        "PLN": "zł ",
        "UAH": "₴",
    })

    # Порядок відображення валют у звітах (відносно базової валюти товару)
    PRICE_ORDER: Final[Mapping[str, List[str]]] = MappingProxyType({
        "USD": ["USD", "UAH", "EUR", "GBP", "PLN"],
        "EUR": ["EUR", "UAH", "USD", "GBP", "PLN"],
        "GBP": ["GBP", "UAH", "USD", "EUR", "PLN"],
        "PLN": ["PLN", "UAH", "USD", "EUR", "GBP"],
        "UAH": ["UAH", "USD", "EUR", "GBP", "PLN"],
    })

    # ====== Мапи, узгоджені з YAML ======
    # 🔗 Зв’язок валют із ключами REGIONS у config.yaml -> regions:{us, eu, uk}
    #    Використовується для UI/логіки, де потрібен регіональний контекст.
    CURRENCY_TO_REGION: Final[Mapping[str, str]] = MappingProxyType({
        "USD": "us",
        "EUR": "eu",
        "GBP": "uk",
        # PLN не має окремого 'pl' у `regions`, тому тут не вказуємо.
    })

    # ✅ Алиас для обратной совместимости со старым кодом
    CURRENCY_MAP: Final[Mapping[str, str]] = CURRENCY_TO_REGION

    # 🔗 Зв’язок валют із ключами тарифів у delivery.yaml -> {us, uk, germany, poland}
    #    Використовується в розрахунку Meest-доставки. EUR → germany, PLN → poland.
    CURRENCY_TO_DELIVERY_COUNTRY: Final[Mapping[str, str]] = MappingProxyType({
        "USD": "us",
        "GBP": "uk",
        "EUR": "germany",
        "PLN": "poland",
    })

    # 🔗 Зв’язок валют із pricing.regional_costs.*.country_code у config.yaml
    #    (country_code: "us" | "germany" | "uk" | "poland")
    CURRENCY_TO_PRICING_COUNTRY_CODE: Final[Mapping[str, str]] = MappingProxyType({
        "USD": "us",
        "EUR": "germany",
        "GBP": "uk",
        "PLN": "poland",
    })


# ==================================
# 🌍 ГОЛОВНИЙ ОБʼЄКТ КОНСТАНТ
# ==================================

@dataclass(frozen=True, slots=True)
class AppConstants:
    """Єдина точка доступу до всіх констант проєкту (UI, LOGIC, CALLBACKS)."""
    UI:        Final[_UIConstants]    = _UIConstants()
    LOGIC:     Final[_LogicConstants] = _LogicConstants()
    CALLBACKS: Final[_Callbacks]      = _Callbacks()

    def get_all_reply_buttons(self) -> List[str]:
        """Повертає тексти всіх кнопок головного меню (Reply)."""
        return [getattr(self.UI.REPLY_BUTTONS, f.name) for f in fields(self.UI.REPLY_BUTTONS)]

    def generate_menu_pattern(self) -> str:
        """Генерує regex‑патерн для кнопок головного меню (Reply)."""
        buttons = self.get_all_reply_buttons()
        escaped = (re.escape(btn) for btn in buttons)
        return f"^({'|'.join(escaped)})$"


# ==================================
# 🏁 ІНСТАНЦІЯ ТА ПУБЛІЧНИЙ API
# ==================================

CONST = AppConstants()

# ✅ Legacy‑враппер, щоб не ламати існуючі виклики
def generate_menu_pattern() -> str:
    return CONST.generate_menu_pattern()

__all__ = ["AppConstants", "CONST", "generate_menu_pattern"]