# 🧠 app/infrastructure/availability/availability_processing_service.py
"""
📦 availability_handler.py — Обробник перевірки наявності товару у Telegram.

🔹 Клас `AvailabilityHandler`:
    • Приймає URL товару та повідомлення Telegram
    • Делегує обробку та перевірку наявності `AvailabilityProcessingService`
    • Відправляє результат через `AvailabilityMessenger`
"""

from __future__ import annotations

# 🔠 Системні імпорти
import logging
from typing import Optional

# 🌐 Telegram
from telegram import Update
from telegram.ext import CallbackContext
try:  # PTB v20+
    from telegram.constants import ChatAction
    _TYPING_ACTION: Optional[str] = ChatAction.TYPING  # type: ignore[assignment]
except Exception:  # PTB < v20
    _TYPING_ACTION = "typing"

# 🧩 Внутрішні модулі проєкту
from .availability_processing_service import AvailabilityProcessingService
from .i18n import t, normalize_lang
from app.bot.ui.messengers.availability_messenger import AvailabilityMessenger
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


# ================================
# 🎯 ОБРОБНИК ПЕРЕВІРКИ НАЯВНОСТІ
# ================================
class AvailabilityHandler:
    """
    🎯 Делегує збір даних та відправку повідомлень відповідним сервісам.
    """

    def __init__(
        self,
        processing_service: AvailabilityProcessingService,
        messenger: AvailabilityMessenger,
        *,
        default_lang: str = "uk",
        auto_detect_language: bool = True,
    ) -> None:
        self.processing_service = processing_service
        self.messenger = messenger
        self.lang = default_lang
        self.auto_detect_language = auto_detect_language

    async def handle_availability(self, update: Update, context: CallbackContext, url: str) -> None:
        """
        📬 Обробляє посилання на товар, запускаючи процес перевірки та відправки.
        """
        message = update.effective_message
        chat = update.effective_chat
        if not message or not chat:
            logger.warning(
                "availability.handler.empty_context",
                extra={"update_id": getattr(update, "update_id", None)},
            )
            return

        # авто‑язык из Telegram (если включено)
        lang = self.lang
        if self.auto_detect_language:
            lang = normalize_lang(getattr(getattr(update, "effective_user", None), "language_code", None), default=self.lang)

        if not url:
            await message.reply_text(t("empty_url", lang))
            logger.warning("availability.url_empty", extra={"chat_id": chat.id})
            return

        # Показуємо «друкуємо», щоб UX не був порожнім під час парсингу
        try:
            if _TYPING_ACTION:
                await context.bot.send_chat_action(chat_id=chat.id, action=_TYPING_ACTION)  # type: ignore[arg-type]
        except Exception as e:
            logger.debug("availability.typing_failed: %s", e, extra={"chat_id": chat.id})

        try:
            processed = await self.processing_service.process(url)
            if not processed:
                await message.reply_text(t("process_failed", lang))
                logger.info(
                    "availability.process_failed",
                    extra={"chat_id": chat.id, "url": url},
                )
                return

            await self.messenger.send(update, processed)
            logger.info(
                "availability.sent",
                extra={"chat_id": chat.id, "url": url},
            )
        except Exception:
            logger.exception(
                "availability.send_error",
                extra={"chat_id": chat.id, "url": url},
            )
            await message.reply_text(t("send_failed", lang))


__all__ = ["AvailabilityHandler"]