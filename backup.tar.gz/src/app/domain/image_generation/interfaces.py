# 🖋️ app/domain/image_generation/interfaces.py
"""
🖋️ Доменные контракты для модуля генерации зображень (шрифти).
"""

from __future__ import annotations

from enum import Enum
from typing import Protocol, TypeAlias
from PIL import ImageFont

class FontType(str, Enum):
    """🎨 Типи шрифтів, які використовуються в застосунку."""
    BOLD = "bold"
    MONO = "mono"

# ☝️ Единый алиас: что угодно, что возвращает Pillow для шрифтов
FontLike: TypeAlias = ImageFont.ImageFont | ImageFont.FreeTypeFont

class IFontService(Protocol):
    """
    📐 Контракт для сервісу роботи зі шрифтами.
    Інфраструктурні реалізації повинні забезпечити:
      - завантаження шрифтів потрібного типу/розміру
      - вимірювання ширини тексту у пікселях
    """
    def get_font(self, font_type: FontType, size: int) -> FontLike: ...
    def get_text_width(self, text: str, font: FontLike) -> int: ...

__all__ = ["FontType", "FontLike", "IFontService"]