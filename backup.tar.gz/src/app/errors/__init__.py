# 📄 errors/__init__.py
"""
🛡️ Пакет `errors` — централізована система обробки помилок у Telegram-боті.

🔹 Призначення:
    • Оголошує публічний API для помилок і сервісів їх обробки
    • Інкапсулює конкретні класи винятків і фабрику/обробник
    • Забезпечує єдину точку імпорту для решти застосунку
"""

# 🧩 Внутрішні модулі проєкту

from .custom_errors import (
    ErrorCode,
    AppError,
    UserVisibleError,
    AIError,
    ParsingError,
    NetworkRequestError,
)
from .exception_handler_service import ExceptionHandlerService  # noqa: F401		# 🛠️ Сервіс централізованої обробки винятків
from .error_handler import make_error_handler  # noqa: F401						# 🧯 Фабрика/утиліта для інтеграції з Telegram-ботом


# ================================
# 📤 ПУБЛІЧНИЙ API ПАКЕТА
# ================================
__all__ = [
    # Ошибки
    "ErrorCode",
    "AppError",
    "UserVisibleError",
    "AIError",
    "ParsingError",
    "NetworkRequestError",
    # Сервис/фабрика
    "ExceptionHandlerService",
    "make_error_handler",
]