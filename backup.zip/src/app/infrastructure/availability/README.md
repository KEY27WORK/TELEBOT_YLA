# 🌍 Availability Infrastructure

Інфраструктурний шар для перевірки наявності товарів у різних регіонах.  
Відповідає за **оркестрацію**, **кешування**, **метрики** та **форматування звітів** для Telegram.

---

## 📌 Основні компоненти

- **availability_handler.py** — точка входу для бота. Приймає URL товару → віддає повідомлення користувачу.
- **availability_processing_service.py** — оркестратор: URL → slug → заголовок + звіт.
- **availability_manager.py** — координує перевірку по регіонах, кешує, рахує метрики.
- **report_builder.py** — формує публічний та адмінський тексти зі звітів.
- **formatter.py** — конвертує карти кольорів/розмірів у зручний для Telegram вигляд.
- **cache_service.py** — in-memory кеш з TTL, потокобезпечний, зі статистикою та евікціями.
- **dto.py** — DTO для готових текстових звітів (`AvailabilityReports`).
- **metrics.py** — Prometheus-метрики (кеш-хіти/промахи, latency).
- **i18n.py** — міні-словник повідомлень (uk/ru/en).

---

## 🔄 Потік роботи

1. `AvailabilityHandler` приймає посилання від користувача.
2. `AvailabilityProcessingService` дістає slug, будує header та звіт.
3. `AvailabilityManager` паралельно перевіряє регіони → збирає доменний звіт.
4. `ReportBuilder` + `ColorSizeFormatter` перетворюють дані у тексти.
5. `AvailabilityReports` віддається у бот через `AvailabilityMessenger`.

---

## 📊 Метрики

- `availability_cache_hits_total` — попадання у кеш.
- `availability_cache_misses_total` — промахи.
- `availability_report_seconds` — час формування звіту.

---

## 📦 Публічне API

Через `__init__.py` доступні:

```python
from app.infrastructure.availability import (
    AvailabilityHandler,
    AvailabilityProcessingService,
    AvailabilityManager,
    AvailabilityCacheService,
    AvailabilityReportBuilder,
    ColorSizeFormatter,
    AvailabilityReports,
    t, normalize_lang,
)

