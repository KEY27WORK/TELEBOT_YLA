# 📦 app/infrastructure/url/__init__.py
"""
📦 Пакет `infrastructure.url`

Бренд-специфічні стратегії парсингу/нормалізації URL.
Тут зберігаються **конкретні реалізації** контракту
`IUrlParsingStrategy`, які підключаються у фасад
`UrlParserService` (app.shared.utils.url_parser_service).

Наразі доступна:
- YoungLAUrlStrategy — логіка для доменів YoungLA.
"""

from .youngla_strategy import YoungLAUrlStrategy

__all__ = [
    "YoungLAUrlStrategy",
]