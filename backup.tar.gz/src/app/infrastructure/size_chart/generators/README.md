# Текст для README.md
readme_text = """# 🧱 Генератори таблиць розмірів

Цей модуль містить усі класи для **генерації зображень таблиць розмірів** у Telegram-боті YoungLA Ukraine.  
Кожен генератор відповідає за різну логіку відображення: класичну, адаптивну або сіткову.

---

## 📂 Структура

```bash
generators/
├── __init__.py
├── base_generator.py
├── general_table_generator.py
├── unique_table_generator.py
└── unique_grid_table_generator.py
```

| 📄 Файл                           | 🧩 Клас                     | 📌 Призначення                                      |
|----------------------------------|-----------------------------|-----------------------------------------------------|
| `base_generator.py`              | `BaseTableGenerator`        | Абстрактний клас із базовими методами (канва, текст, збереження PNG) |
| `general_table_generator.py`     | `GeneralTableGenerator`     | Класична таблиця: **розмір → параметри**            |
| `unique_table_generator.py`      | `UniqueTableGenerator`      | Адаптивна таблиця: **параметри → розміри**, масштабує шрифти під вміст |
| `unique_grid_table_generator.py` | `UniqueGridTableGenerator`  | Сіткова таблиця: **зріст × вага → розмір**          |

---

## 🧩 Залежності

- [`FontService`](../image_generation/font_service.py) — надає шрифти для тексту.
- [`TableGeometryService`](../size_chart/services/table_geometry_service.py) — використовується `UniqueTableGenerator` для адаптивного масштабування.

---

## ⚙️ Приклад використання

```python
from app.infrastructure.size_chart.generators import GeneralTableGenerator
from app.infrastructure.image_generation.font_service import FontService

font_service = FontService()
size_chart = {
    "Title": "Men's T-Shirts",
    "Розмір": ["S", "M", "L", "XL"],
    "Chest (cm)": [90, 100, 110, 120],
    "Length (cm)": [65, 68, 71, 74],
}

gen = GeneralTableGenerator(size_chart, "table.png", font_service)
await gen.generate()
print("✅ Таблиця збережена у table.png")
```

---

## 🏭 Де створюються

Усі генератори створюються через фабрику `TableGeneratorFactory`, яка підключає `FontService`  
та обирає відповідний клас за типом `ChartType`.

```python
from app.infrastructure.image_generation.table_generator_factory import TableGeneratorFactory
from app.domain.size_chart.enums import ChartType

generator = table_generator_factory.create_generator(
    chart_type=ChartType.UNIQUE,
    data=ocr_result,
    output_path="table.png"
)
await generator.generate()
```

---

## 👤 Автор

**Кирилл / @key27**  
📬 Telegram: [t.me/key27](https://t.me/key27)
"""