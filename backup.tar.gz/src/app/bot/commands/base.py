# 📦 app/bot/commands/base.py
"""
🧩 base.py — Базовий клас та протоколи для всіх «фіч» бота.

🔹 Призначення модуля:
    • Описує абстракцію `BaseFeature` для єдиної точки входу фіч
    • Визначає контракт реєстрації Telegram‑обробників
    • Надає контракт для колбек‑обробників (callback query)
"""

# 🔠 Системні імпорти
from abc import ABC                                              # 🧱 Абстрактні базові класи
from typing import Dict                                          # 🧰 Типізація словників

# 🌐 Зовнішні бібліотеки
from telegram.ext import Application                             # 🤖 Telegram Application (dispatcher)

# 🧩 Внутрішні модулі проєкту
from app.bot.services.types import Registrable, CallbackHandlerType  # 🧾 Протоколи/тайпінги для реєстрації
from app.bot.services.callback_data_factory import CallbackData      # 🏷️ Тип для callback‑ключів


# ================================
# 🏛️ БАЗОВИЙ КЛАС ФІЧІ
# ================================
class BaseFeature(ABC, Registrable):
    """
    🧩 Абстрактний базовий клас для будь‑якої «фічі» Telegram‑бота.

    Конвенція використання:
      • Фіча САМА реєструє свої обробники у `register_handlers`,
      • або навмисно лишає метод порожнім (наприклад, якщо вся робота — тільки через callback‑и).
    """

    def register_handlers(self, application: Application) -> None:
        """
        Реєстрація Telegram‑обробників: команди, повідомлення, inline‑кнопки тощо.
        За умовчанням — нічого не реєструє (зручно для «чистих» callback‑фіч).

        Args:
            application (Application): Головний застосунок `python-telegram-bot` для реєстрації handler‑ів.
        """
        # Якщо потрібна обов'язкова реалізація — розкоментуй наступний рядок:
        # raise NotImplementedError(f"{self.__class__.__name__}.register_handlers() is not implemented")
        return							# 🔕 За умовчанням фіча може не реєструвати handler‑и (тільки callback‑и)

    def get_callback_handlers(self) -> Dict[CallbackData, CallbackHandlerType]:
        """
        Повертає мапу {CallbackData: async‑обробник}, яку зчитує центральний реєстр callback‑ів.
        Це дозволяє тримати маршрутизацію callback‑ів у єдиному місці.

        Returns:
            Dict[CallbackData, CallbackHandlerType]: Словник «ключ callback‑даних → корутина‑обробник».
        """
        return {}							# 📭 За замовчуванням — порожньо; фіча може переозначити й повернути власні колбеки
