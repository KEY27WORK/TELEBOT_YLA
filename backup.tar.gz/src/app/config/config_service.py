# ⚙️ app/config/config_service.py
"""
⚙️ Сервіс доступу до статичної конфігурації.

🔹 Клас `ConfigService`:
    • Завантажує змінні з `.env` (за префіксом CONST.LOGIC.ENV_PREFIX) і всі `.yaml` файли з папки `yamls/` (рекурсивно).
    • Обʼєднує всі джерела в один словник конфігурації (глибоке злиття).
    • Інтерполює посилання на змінні середовища у YAML: ${VAR} або ${VAR:-default}.
    • Надає метод `.get()` з опціональним приведенням типу (cast).
    • Має `.reload()` для перечитування (зручно у тестах).

Особливості:
- Singleton — конфігурація зчитується один раз за життєвий цикл процесу.
- Безпечна обробка відсутніх файлів/ключів; повертає `default`, якщо ключ не знайдено.
"""

# 🌐 Зовнішні бібліотеки
import yaml
from dotenv import load_dotenv

# 🔠 Системні імпорти
import logging
import os
import re
from pathlib import Path
from typing import Any, Callable, Dict, Optional, TypeVar

# 🧩 Внутрішні модулі проєкту
from app.config.setup.constants import CONST
from app.shared.utils.logger import LOG_NAME

T = TypeVar("T")

# Патерн для ${VAR} та ${VAR:-default}
_ENV_REF_RE = re.compile(r"\$\{([A-Z0-9_]+)(?::-(.*?))?\}")

# ================================
# 🏛️ СЕРВІС ДОСТУПУ ДО КОНФІГІВ
# ================================
class ConfigService:
    """
    ⚙️ Єдина точка доступу до статичної конфігурації застосунку (Singleton).
    """

    _instance: Optional["ConfigService"] = None
    _config: Dict[str, Any] = {}

    logger: logging.Logger  # ініціалізується в __new__

    def __new__(cls) -> "ConfigService":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.logger = logging.getLogger(LOG_NAME)
            cls._instance.reload()  # первинне завантаження
        return cls._instance

    # ================================
    # 🔄 КЕРУВАННЯ СТАНОМ
    # ================================
    def reload(self) -> None:
        """Перечитує .env та всі YAML файли (для тестів чи hot-reload)."""
        self.logger.info("🔄 Перезавантаження конфігурації…")
        self._load_all_configs()

    # ================================
    # 📥 ЗАВАНТАЖЕННЯ КОНФІГУРАЦІЇ
    # ================================
    def _load_all_configs(self) -> None:
        """Оркеструє завантаження всіх джерел конфігурації у правильному порядку."""
        self._config = {}
        self._load_from_env()         # 1) .env → os.environ (+ префіксовані APP_* у конфіг)
        self._load_from_yaml_files()  # 2) YAML (з інтерполяцією ${VAR})
        self.logger.info("✅ Конфігурацію успішно завантажено з .env та YAML.")

    def _load_from_env(self) -> None:
        """Завантажує змінні з .env та ENV, що мають префікс, у вкладений словник."""
        load_dotenv()
        env_vars: Dict[str, Any] = {}
        prefix: str = getattr(CONST.LOGIC, "ENV_PREFIX", "APP_")

        for key, value in os.environ.items():
            if not key.startswith(prefix):
                continue
            # "APP_TELEGRAM_BOT_TOKEN" -> "telegram.bot.token"
            normalized = key[len(prefix):].lower().replace("_", ".")
            env_vars[normalized] = value

        self._deep_update(self._config, self._unflatten_dict(env_vars))

    def _load_from_yaml_files(self) -> None:
        """
        Рекурсивно завантажує всі .yaml з config/yamls/**.
        Порядок стабільний: сортування за шляхом.
        Виконує інтерполяцію ${VAR} з os.environ.
        """
        base_dir = Path(__file__).parent / "yamls"
        yaml_files = sorted(base_dir.rglob("*.yaml"))  # рекурсивний пошук

        for yaml_path in yaml_files:
            try:
                self.logger.debug("📘 Завантаження YAML: %s", yaml_path.relative_to(base_dir))
                with open(yaml_path, "r", encoding="utf-8") as f:
                    raw = yaml.safe_load(f) or {}
                # 🔁 Інтерполяція посилань на env у всьому дереві
                data = self._interpolate_env(raw)
                self._deep_update(self._config, data)
            except (FileNotFoundError, yaml.YAMLError) as e:
                self.logger.warning("⚠️ Не вдалося завантажити %s: %s", yaml_path.name, e)

    # ================================
    # 🔑 ДОСТУП ДО ЗНАЧЕНЬ
    # ================================
    def get(
        self,
        key: str,
        default: Optional[T] = None,
        cast: Optional[Callable[[Any], T]] = None,
    ) -> Optional[T]:
        """
        Повертає значення за ключем з крапками (напр., `telegram.http.connect_timeout_sec`).
        Може виконати приведення типу через `cast`.
        """
        node: Any = self._config
        for part in key.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                return default

        if cast is not None and node is not None:
            try:
                return cast(node)
            except (TypeError, ValueError):
                self.logger.warning(
                    "⚠️ Неможливо привести значення '%s' ключа '%s' до типу %s. Повертаю default.",
                    node,
                    key,
                    getattr(cast, "__name__", str(cast)),
                )
                return default
        return node  # type: ignore[return-value]

    # ================================
    # 🧰 ДОПОМІЖНІ МЕТОДИ
    # ================================
    def _unflatten_dict(self, flat: Dict[str, Any]) -> Dict[str, Any]:
        """Перетворює ключі виду 'a.b.c' у вкладену структуру: {'a': {'b': {'c': value}}}"""
        result: Dict[str, Any] = {}
        for dotted_key, value in flat.items():
            if value is None:
                continue
            parts = dotted_key.split(".")
            cursor = result
            for p in parts[:-1]:
                cursor = cursor.setdefault(p, {})
            cursor[parts[-1]] = value
        return result

    def _deep_update(self, target: Dict[str, Any], source: Dict[str, Any]) -> None:
        """Глибоке (рекурсивне) злиття словників `source` у `target`."""
        for k, v in source.items():
            if isinstance(v, dict) and isinstance(target.get(k), dict):
                self._deep_update(target[k], v)  # type: ignore[index]
            else:
                target[k] = v

    # ── Інтерполяція ${VAR} у YAML ─────────────────────────────────────────
    def _interpolate_env(self, node: Any) -> Any:
        """
        Рекурсивно обходить dict/list/scalar і підставляє значення змінних середовища
        у рядках по шаблону: ${VAR} або ${VAR:-default}.
        """
        if isinstance(node, dict):
            return {k: self._interpolate_env(v) for k, v in node.items()}
        if isinstance(node, list):
            return [self._interpolate_env(v) for v in node]
        if isinstance(node, str):
            return _ENV_REF_RE.sub(self._env_replace, node)
        return node

    @staticmethod
    def _env_replace(match: re.Match) -> str:
        var = match.group(1)
        default = match.group(2)
        return os.environ.get(var, default or "")


# ================================
# 📦 ПУБЛІЧНИЙ API МОДУЛЯ
# ================================
__all__ = ["ConfigService"]