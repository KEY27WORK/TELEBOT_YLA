# 🤖 Handlers (Telegram UI layer)

Пакет **`app/bot/handlers`** содержит тонкий презентационный слой:
маршрутизация входящих апдейтов, делегирование в сервисы домена/инфраструктуры,
форматирование сообщений и централизованная обработка ошибок.

## 📦 Состав

- `callback_handler.py` — централизованный обработчик **inline‑кнопок** (`callback_query`).
- `link_handler.py` — главный **маршрутизатор текста/URL** и режимов (price, size chart, availability).
- `price_calculator_handler.py` — координация **расчёта цены**: парсер → pricing → форматтер → reply.
- `size_chart_handler_bot.py` — **таблицы размеров**: загрузка HTML, OCR/генерация, отправка изображений.
- `product/` — под‑пакет UI для товара/коллекций:
  - `product_handler.py` — обработка **страницы товара**.
  - `collection_handler.py` — обработка **коллекций** с прогрессом.
  - `collection_runner.py` — параллельная обработка ссылок, ретраи, троттлинг прогресса.
  - `image_sender.py` — отправка фото (single/media group) с backoff и fail‑open.

Публичные экпортируемые классы объявлены в `__init__.py`.

## 🧭 Потоки

- **Callback flow:** Telegram → `CallbackHandler` → `CallbackData.parse()` → `CallbackRegistry.get_handler()` → вызов фичи.  
  Параметры кладутся в `context.callback_params`.

- **Link flow:** Telegram → `LinkHandler`
  1) текст → поиск URL (если это не ссылка);  
  2) активный режим → делегирование нужному методу;  
  3) иначе — auto‑detector: товар/коллекция → соответствующий handler.

## 🛡️ Принципы

- **SRP:** только оркестрация и UI; бизнес‑логики здесь нет.  
- **DI:** все зависимости передаются через конструктор.  
- **Надёжность:** везде проверки `update.message`, best‑effort `send_action`, централизованный `ExceptionHandlerService`.  
- **Без магии:** текстовые сообщения хранятся в `app/bot/ui/static_messages.py`.

## ➕ Как добавить новый режим (пример)

1. Добавить константу в `AppConstants.LOGIC.MODES`.
2. Реализовать метод‑обработчик внутри `LinkHandler` с сигнатурой
   `(update: Update, context: CustomContext, url: str) -> None`.
3. Повесить декоратор‑гейт `@product_url_required`, если нужен именно URL товара.
4. Зарегистрировать метод в `self.mode_handlers` в конструкторе `LinkHandler`.

## ⚠️ Ошибки и таймауты

- Все нештатные ситуации отдаём в `ExceptionHandlerService`.
- Длительные операции обёрнуты в `asyncio.wait_for`:
  - парсер товара: см. `_PARSER_TIMEOUT_SEC` (size chart)
  - генерация size chart: `_SIZECHART_TIMEOUT_SEC`
  - CPU‑расчёт цены: `AppConstants.LOGIC.TIMEOUTS.PRODUCT_PROCESS_SEC`.

## 🧪 Тесты

Рекомендуется мокать `python-telegram-bot` и инфраструктурные сервисы.  
Юнит‑тесты должны проверять, что:
- корректный роутинг по режимам и типам URL,
- безопасное поведение при отсутствии `update.message`,
- отсутствие «магических строк» в хендлерах (используем `static_messages`).
