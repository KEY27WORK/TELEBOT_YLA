# 🖋️ Formatters (Telegram UI formatting layer)

Пакет **`app/bot/ui/formatters`** содержит тонкий слой форматирования UI:
преобразует DTO/структуры домена в готовый **HTML‑текст** для Telegram (`parse_mode="HTML"`).
Бизнес‑логики здесь нет — только безопасная сборка строк и разметки.

---

## 📦 Состав

- `message_formatter.py` — форматирование **описания товара** (заголовок, блоки «Материал/Посадка/Описание/Модель»,
  список цветов/наличия, «SOLD OUT» бейдж). Экранирует HTML, контролирует длины.
- `price_report_formatter.py` — **ценовой отчёт** из тематических блоков:
  _шапка_ → _цена_ → _доставка_ → _себестоимость_ → _наценка_ → _прибыль_.
  Поддерживает мультивалютный вывод и порядок валют. Имеет мягкие фолбэки при конвертации.
- `__init__.py` — публичные экспортируемые классы:
  `MessageFormatter`, `PriceReportFormatter`.

---

## 🧭 Потоки

- **Description flow:**
  `ProductContentDTO` → `MessageFormatter.format_description(dto)` → HTML‑строка → `reply_text(..., parse_mode=HTML)`.

- **Price report flow:**
  `ProductInfo` + `FullPriceDetails` + `PricingContext` + `ICurrencyConverter`
  → `PriceReportFormatter.format_message(info, details, context, converter)`
  → HTML‑строка → `reply_text(..., parse_mode=HTML)`.

---

## 🛡️ Принципы

- **SRP:** каждый файл отвечает за свой тип форматирования (никакой бизнес‑логики).
- **Безопасный HTML:** все потенциально опасные значения экранируются (`html.escape` / `escape`),
  используются только простые, валидные теги (`<b>`, `<u>`, `<a href>`). Вывод рассчитан на `parse_mode="HTML"`.
- **DI:** форматтеры получают уже подготовленные данные (DTO/сущности) и, при необходимости, внешние зависимости
  (например, конвертер валют) через параметры.
- **Надёжность:** ошибки конвертации валют не прерывают отчёт — значения помечаются как `N/A`,
  а детали пишутся в лог (warning). Для карт валют/порядков предусмотрены дефолтные фолбэки.
- **Без «магии»:** лейблы и эмодзи — локальные константы форматтера или берутся из `CONST`.
  Статические пользовательские тексты — в `app/bot/ui/static_messages.py`.

---

## ➕ Как добавить новый форматтер

1. Создать файл в `app/bot/ui/formatters/`, например `availability_report_formatter.py`.
2. Реализовать класс, например `AvailabilityReportFormatter` с публичным методом
   `format_message(dto_or_view_model, *deps) -> str`.
3. Вынести подписи/лейблы в локальные константы или в `AppConstants`, чтобы не плодить «магические строки».
4. Экспортировать класс в `formatters/__init__.py`.
5. Использовать форматтер из слоя messenger/handler и отправлять как `reply_text(..., parse_mode=HTML)`.

---

## ⚠️ Ошибки и особенности

- Форматтеры **не** должны ходить в сеть или базу, не должны выполнять длительные операции.
- Любые исключения преобразования (например, валют) ловятся и логируются как предупреждения,
  пользователю показывается безопасное значение (`N/A`).
- Таймауты не применяются (форматирование — быстрая операция). Длительность должна оставаться O(длина текста).

---

## 🧪 Тесты

Рекомендуется покрыть юнит‑тестами без Telegram SDK:
- экранирование HTML‑символов и корректное закрытие тегов;
- корректный порядок и формат мультивалютных значений;
- фолбэки `N/A` при сбоях конвертера (моки/стабы);
- алгоритм «SOLD OUT»: `is_fully_sold_out()` для набора строк наличия;
- снапшот‑тесты финальной HTML‑строки на регрессию разметки.

---

## 🔌 Внешние контракты

- `ProductContentDTO` — данные товара для описания.
- `ProductInfo`, `FullPriceDetails`, `PricingContext` — сущности для отчёта по цене.
- `ICurrencyConverter` — интерфейс конвертера валют (`convert(value, src, dst) -> float`).
- `AppConstants` / `CONST` — централизованные константы UI и (опционально) карты валют/порядков:
  `CURRENCY_SYMBOLS`, `PRICE_ORDER`, `CURRENCY_DISPLAY` (при их отсутствии используются дефолты внутри форматтера).

---

## 🧩 Примеры использования

```python
# Описание товара
from app.bot.ui.formatters import MessageFormatter
html_text = MessageFormatter.format_description(product_content_dto)
await update.message.reply_text(html_text, parse_mode=CONST.UI.DEFAULT_PARSE_MODE)
```

```python
# Ценовой отчёт
from app.bot.ui.formatters import PriceReportFormatter
formatter = PriceReportFormatter()
html_report = formatter.format_message(info, details, context, converter)
await update.message.reply_text(html_report, parse_mode=CONST.UI.DEFAULT_PARSE_MODE)
```