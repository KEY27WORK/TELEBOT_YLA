# ⚖️ Product Services

Ця директорія містить **доменні сервіси** для роботи з продуктами.

---

## 📂 Вміст

- **`weight_resolver.py`**  
  Сервіс для визначення ваги товарів.  
  Алгоритм:
  1. Пошук ваги в локальному кеші (`IWeightDataProvider`).
  2. Якщо не знайдено — запит до AI-сервісу (`IWeightEstimator`).
  3. Оновлення кешу для уникнення повторних викликів.

---

## 🧭 Призначення

- Всі сервіси тут працюють лише з **доменними контрактами** (`interfaces.py`),  
  а не з конкретними реалізаціями інфраструктури.
- Повертають чисті значення (`int` у грамах, `Decimal` для грошей).
- Не мають побічних ефектів у конструкторі.

---

## 🚀 Приклад використання

```python
from app.domain.products.services import WeightResolver
from app.domain.products.interfaces import IWeightDataProvider, IWeightEstimator

resolver = WeightResolver(weight_data_provider, weight_estimator)
weight_g = await resolver.resolve_g(
    title="YoungLA 6022 Carpenter Jeans",
    description="Джинси карго з товстого деніму",
    image_url="https://..."
)
print(f"Вага товару: {weight_g} г")
