# ✨ Пакет `commands`

Цей пакет реалізує **"фічі" Telegram-бота** — самодостатні модулі, які інкапсулюють певну логіку (меню, команди, валюта тощо).  
Кожна фіча:
- Має власний клас, що наслідує `BaseFeature`.
- Реєструє свої обробники команд та callback'ів через загальний `CallbackRegistry`.
- Інкапсулює тільки одну область відповідальності (SRP).

---

## 📂 Структура

commands/
┣ 📜 init.py # Публічний API пакету (BaseFeature + готові фічі)
┣ 📜 base.py # Абстрактний контракт для всіх фіч
┣ 📜 core_commands_feature.py # /start, /help + inline-кнопки довідки
┣ 📜 currency_feature.py # /rate, /set_rate + управління курсами валют
┗ 📜 main_menu_feature.py # Обробка кнопок головного меню (режими, дії)

---

## 🔑 Ключові принципи

- **Інкапсуляція**: кожна фіча відповідає тільки за свою область.
- **DI (Dependency Injection)**: усі залежності передаються через конструктор.
- **Єдиний контракт**: всі фічі наслідують `BaseFeature`.
- **Реєстрація через `CallbackRegistry`**: немає "розкиданих" handler'ів.
- **UI ≠ Логіка**: тут немає бізнес-логіки, лише маршрутизація команд/меню.

---

## 📬 Доступні фічі

- `CoreCommandsFeature` — `/start`, `/help`, довідкове меню.  
- `CurrencyFeature` — відображення та встановлення курсу валют.  
- `MainMenuFeature` — головне меню (режими, замовлення, допомога).

---

## 🚀 Приклад використання

```python
from app.bot.commands import CoreCommandsFeature, CurrencyFeature, MainMenuFeature

# Реєстрація у BotRegistrar або DI-контейнері:
features = [
    CoreCommandsFeature(registry, CONST),
    CurrencyFeature(currency_manager, registry, CONST, exception_handler),
    MainMenuFeature(CONST),
]