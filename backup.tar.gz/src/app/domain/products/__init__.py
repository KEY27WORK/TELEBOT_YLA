# app/domain/products/__init__.py
"""
📦 products — домен продуктів

Публічний API пакета:
    • Сутності: ProductInfo, Currency, Url
    • Контракти: SearchResult, IProductDataProvider, ICollectionDataProvider,
                 IProductSearchProvider, IWeightDataProvider, IWeightEstimator,
                 ICollectionProcessingService, ICollectionLinksProvider
    • Сервіси: WeightResolver
"""

# ── Entities ────────────────────────────────────────────────────────────────
from .entities import ProductInfo, Currency, Url

# ── Interfaces / Contracts ─────────────────────────────────────────────────
from .interfaces import (
    SEARCH_DEFAULT_LIMIT,
    SEARCH_MAX_LIMIT,
    SearchResult,
    IProductDataProvider,
    ICollectionDataProvider,
    IProductSearchProvider,
    IWeightDataProvider,
    IWeightEstimator,
    ICollectionProcessingService,
    ICollectionLinksProvider,
)

# ── Services ───────────────────────────────────────────────────────────────
from .services import WeightResolver

from .dto import ProductHeaderDTO

__all__ = [
    # entities
    "ProductInfo",
    "Currency",
    "Url",
    # interfaces
    "SEARCH_DEFAULT_LIMIT",
    "SEARCH_MAX_LIMIT",
    "SearchResult",
    "IProductDataProvider",
    "ICollectionDataProvider",
    "IProductSearchProvider",
    "IWeightDataProvider",
    "IWeightEstimator",
    "ICollectionProcessingService",
    "ICollectionLinksProvider",
    # services
    "WeightResolver",

    "ProductHeaderDTO",
]