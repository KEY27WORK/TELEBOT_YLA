# 🧩 app/domain/products/interfaces.py
"""
🧩 interfaces.py — Контракти для джерел даних про продукти.

🔹 Призначення:
    • Визначає абстрактні інтерфейси для постачальників даних (товар/колекція/пошук).
    • Дозволяє доменному шару не залежати від конкретних реалізацій інфраструктури.
    • Підтримує принципи SOLID (DIP) та чистої архітектури.

Важливо (контракт на рівні домену):
    • Усі URL у цих інтерфейсах мають бути КАНОНІЧНИМИ та HTTPS,
      тобто результатом UrlParserService.normalize(...).
    • Реалізації НЕ повинні виконувати мережеву роботу в __init__,
      лише у викликах методів (ледачі побічні ефекти).
    • Реалізації не мають «ковтати» asyncio.CancelledError.
"""
from __future__ import annotations

# 🔠 Системні імпорти
from dataclasses import dataclass
from typing import Dict, List, Optional, Protocol, runtime_checkable

# 🧩 Внутрішні модулі проєкту
from .entities import ProductInfo, Url
from .dto import ProductHeaderDTO   # 👈 правильно

# ================================
# 🔢 КОНСТАНТИ ПОШУКУ
# ================================
SEARCH_DEFAULT_LIMIT: int = 5
SEARCH_MAX_LIMIT: int = 25


@dataclass(frozen=True, slots=True)
class SearchResult:
    """📦 Результат пошуку з мета-інфо."""
    url: Url
    title: Optional[str] = None
    score: float = 1.0

    def __post_init__(self):
        if not (0.0 <= float(self.score) <= 1.0):
            raise ValueError(f"score must be within [0.0, 1.0], got: {self.score}")


# ================================
# 🏛️ ІНТЕРФЕЙСИ
# ================================
@runtime_checkable
class IProductDataProvider(Protocol):
    """
    📦 Контракт для джерела даних про товар.
    """
    url: Url

    async def get_product_info(self) -> ProductInfo: ...
    async def get_header_info(self) -> ProductHeaderDTO: ...  # 👈 новий метод


@runtime_checkable
class ICollectionDataProvider(Protocol):
    url: Url
    async def get_product_links(self) -> List[Url]: ...


@runtime_checkable
class IProductSearchProvider(Protocol):
    async def resolve_one(self, query: str) -> Optional[Url]: ...
    async def resolve_many(self, query: str, limit: int = SEARCH_DEFAULT_LIMIT) -> List[SearchResult]: ...


@runtime_checkable
class IWeightDataProvider(Protocol):
    async def get_all_weights(self) -> Dict[str, int]: ...
    async def update_weight(self, keyword: str, weight_g: int) -> None: ...


@runtime_checkable
class IWeightEstimator(Protocol):
    async def estimate_weight_g(self, title: str, description: str, image_url: str) -> int: ...


@runtime_checkable
class ICollectionLinksProvider(Protocol):
    async def get_product_links(self) -> List[Url]: ...


@runtime_checkable
class ICollectionProcessingService(Protocol):
    async def get_product_links(self, raw_url: str) -> List[Url]: ...


__all__ = [
    "Url",
    "SEARCH_DEFAULT_LIMIT",
    "SEARCH_MAX_LIMIT",
    "SearchResult",
    "IProductDataProvider",
    "ICollectionDataProvider",
    "ICollectionProcessingService",
    "ICollectionLinksProvider",
    "IProductSearchProvider",
    "IWeightDataProvider",
    "IWeightEstimator",
]