from __future__ import annotations

"""
Size Chart — інфраструктурний модуль для повного циклу роботи з таблицями розмірів:
пошук на сторінці → завантаження зображень → OCR → генерація PNG.

Публічне API пакета (реекспорти):

• Downloader:
    - ImageDownloader
    - DownloadResult
    - DownloadError
    - DownloadOutcome

• OCR:
    - OCRService
    - SizeChartOcrResult
    - SizeChartOcrStatus

• Генерація:
    - TableGeneratorFactory

• Оркестрація:
    - SizeChartService
    - Stage
    - SizeChartProgress
    - ProgressCallback

• Пошук таблиць:
    - YoungLASizeChartFinder
"""

# ── Downloader ─────────────────────────────────────────────────────────────
from .image_downloader import (
    ImageDownloader,
    DownloadResult,
    DownloadError,
    DownloadOutcome,
)

# ── OCR ───────────────────────────────────────────────────────────────────
from .ocr_service import OCRService
from .dto import SizeChartOcrResult, SizeChartOcrStatus

# ── Генерація ─────────────────────────────────────────────────────────────
from .table_generator_factory import TableGeneratorFactory

# ── Оркестрація ───────────────────────────────────────────────────────────
from .size_chart_service import (
    SizeChartService,
    Stage,
    SizeChartProgress,
    ProgressCallback,
)

# ── Пошук таблиць ─────────────────────────────────────────────────────────
from .youngla_finder import YoungLASizeChartFinder


__all__ = [
    # Downloader
    "ImageDownloader",
    "DownloadResult",
    "DownloadError",
    "DownloadOutcome",
    # OCR
    "OCRService",
    "SizeChartOcrResult",
    "SizeChartOcrStatus",
    # Генерація
    "TableGeneratorFactory",
    # Оркестрація
    "SizeChartService",
    "Stage",
    "SizeChartProgress",
    "ProgressCallback",
    # Пошук
    "YoungLASizeChartFinder",
]