# ✉️ Messengers (Telegram UI layer)

Пакет **`app/bot/ui/messengers`** отвечает за оркестрацию отправки готового контента
в Telegram: фото, альбомы, таблицы размеров, отчёты о наличии и комплексные карточки товаров.

## 📦 Состав

- `availability_messenger.py` — отправка **отчётов о наличии** (публичный / админский формат).
- `product_messenger.py` — комплексная отправка карточки **товара**:
  фото, описание, цена, музыка, size-chart.
- `size_chart_messenger.py` — отправка **таблиц размеров** как изображений.

Все публичные классы экспортируются в `__init__.py`.

## 🧭 Потоки

- **Product flow:**  
  Данные товара → `MessageFormatter` / `PriceReportFormatter` →  
  `ProductMessenger.send()` → последовательная отправка: фото → описание → музыка → size-chart.

- **Availability flow:**  
  Результат проверки размеров → `AvailabilityMessenger.format_report()` →  
  Telegram (admin/public) → caption + фото при необходимости.

- **Size chart flow:**  
  HTML-страница → OCR/генерация таблицы →  
  `SizeChartMessenger.send(update, context, image_paths)` → надёжная отправка фото.

## 🛡️ Принципы

- **SRP:** каждый messenger отвечает только за свой тип контента.  
- **DI:** все зависимости (formatter, image_sender, exception_handler) внедряются в конструктор.  
- **Надёжность:** для фото — ретраи, backoff, graceful-fallback через `ImageSender`.  
- **Без магии:** тексты и подписи берутся из `ui/static_messages.py`.  
- **Единый parse_mode:** применяется `AppConstants.UI.DEFAULT_PARSE_MODE`.

## ➕ Как добавить новый messenger

1. Создать файл `xxx_messenger.py` в пакете `messengers`.
2. Реализовать класс `XxxMessenger` с методом:
   ```python
   async def send(self, update: Update, context: CustomContext, data: Any) -> None:
       ...
3.	Использовать существующие утилиты (ImageSender, форматтеры, static_messages).
4.	Экспортировать класс в __init__.py.

## ⚠️ Ошибки
	•	Все исключения пробрасываются в ExceptionHandlerService.
	•	Для отправки медиа обязательны try/except с fallback на текстовое сообщение.

## 🧪 Тесты
Рекомендуется мокать:
	•	ImageSender.send_images — проверка ретраев и корректности caption.
	•	Форматтеры (MessageFormatter, PriceReportFormatter) — чтобы гарантировать HTML-валидность.
	•	Отправку разных комбинаций (только фото, фото + текст, альбом).