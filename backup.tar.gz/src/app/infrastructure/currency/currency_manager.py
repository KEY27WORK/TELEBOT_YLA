# 💵 app/infrastructure/currency/currency_manager.py
"""
💵 currency_manager.py — Інфраструктурний сервіс для керування валютами.

🔁 Staged rollout, Decimal-first:
- Внутрішньо всі курси зберігаються як Decimal (UAH за 1 одиницю валюти).
- Публічні геттери:
    • get_money_converter() -> IMoneyConverter (точний Decimal API)
    • get_converter()       -> ICurrencyConverter (легасі float API; зниження точності лише на межі повернення)

🎯 Призначення:
- Асинхронно отримує, кешує і оновлює курси (Monobank).
- Видає snapshot-конвертери на базі CurrencyConverter.

⚙️ Нотатки:
- Стратегія округлення за замовчуванням — ROUND_HALF_EVEN (BANKERS), задається в конструкторі CurrencyConverter.
- Квант курсів у файлі/пам’яті: 4 знаки після коми (для стабільних порівнянь і зрозумілого JSON).
"""

from __future__ import annotations

# 🌐 Зовнішні бібліотеки
import httpx
import aiofiles

# 🔠 Системні імпорти
import asyncio
import json
import logging
import time
from decimal import Decimal, ROUND_HALF_EVEN
from typing import Any, Dict, List, Optional, Union, cast, Protocol

# 🧩 Внутрішні модулі проєкту
from app.config.config_service import ConfigService
from app.domain.currency.interfaces import ICurrencyConverter, IMoneyConverter
# Fallback-протокол для сумісності з різними версіями доменних інтерфейсів
try:  # pragma: no cover
    from app.domain.currency.interfaces import ICurrencyRatesProvider  # type: ignore
except Exception:  # pragma: no cover
    class ICurrencyRatesProvider(Protocol):  # noqa: N801
        async def initialize(self) -> None: ...
        async def close(self) -> None: ...
        def get_money_converter(self) -> IMoneyConverter: ...
        def get_converter(self) -> ICurrencyConverter: ...
        def get_all_rates(self) -> Dict[str, Decimal]: ...
        @property
        def last_update_ts(self) -> float: ...
        def is_cache_fresh(self) -> bool: ...

from app.infrastructure.currency.currency_converter import CurrencyConverter
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


class CurrencyManager(ICurrencyRatesProvider):
    """
    🏦 Керує життєвим циклом курсів валют і надає конвертери (знімки стану).
    """

    _UAH_CODE = 980  # ISO-код UAH у відповіді Monobank
    _RATE_QUANTUM = Decimal("0.0001")  # квант збереження/порівняння курсів
    _ROUNDING = ROUND_HALF_EVEN        # стратегія округлення (BANKERS)

    def __init__(self, config_service: ConfigService) -> None:
        self._config = config_service
        self._lock = asyncio.Lock()

        # ── Параметри з конфігів ────────────────────────────────────────────
        _api_url = self._config.get("currency_api.url")
        _rate_file_path = self._config.get("files.currency_rates")
        if not _api_url or not isinstance(_api_url, str):
            raise ValueError("Config 'currency_api.url' is required and must be str.")
        if not _rate_file_path or not isinstance(_rate_file_path, str):
            raise ValueError("Config 'files.currency_rates' is required and must be str.")

        self._api_url: str = cast(str, _api_url)
        self._rate_file_path: str = cast(str, _rate_file_path)

        self._currency_codes: Dict[str, int] = cast(
            Dict[str, int], self._config.get("currency_api.codes", {}) or {}
        )
        self._margin_raw: Union[float, int, str] = cast(
            Union[float, int, str], self._config.get("currency_api.margin", 0.5)
        )
        self._timeout: int = cast(int, self._config.get("currency_api.timeout_sec", 5) or 5)
        self._retries: int = cast(int, self._config.get("currency_api.retry_attempts", 2) or 2)
        self._retry_delay: int = cast(int, self._config.get("currency_api.retry_delay_sec", 2) or 2)
        self._min_ttl_sec: int = cast(int, self._config.get("currency_api.ttl_sec", 600) or 600)

        # ── Стан ────────────────────────────────────────────────────────────
        self._rates: Dict[str, Decimal] = {}
        self._client: Optional[httpx.AsyncClient] = None
        self._last_update_ts: float = 0.0

    # ================================
    # 🔓 ПУБЛІЧНИЙ ІНТЕРФЕЙС
    # ================================
    def get_money_converter(self) -> IMoneyConverter:
        """Повертає точний Decimal-конвертер як знімок поточного стану курсів."""
        return CurrencyConverter(self._rates.copy(), rounding=self._ROUNDING)

    def get_converter(self) -> ICurrencyConverter:
        """
        Повертає легасі-конвертер (float API) як знімок поточного стану курсів.
        Точність усередині — Decimal; float тільки на межі повернення значення.
        """
        return CurrencyConverter(self._rates.copy(), rounding=self._ROUNDING)

    def get_all_rates(self) -> Dict[str, Decimal]:
        """Копія актуальних курсів: { "USD": Decimal("40.5000"), ... }."""
        return self._rates.copy()

    @property
    def last_update_ts(self) -> float:
        """Unix-час останнього успішного оновлення кешу курсів."""
        return self._last_update_ts

    def is_cache_fresh(self) -> bool:
        """True, якщо TTL кешу ще не минув (оновлення поки не потрібне)."""
        return (time.time() - self._last_update_ts) < max(0, int(self._min_ttl_sec or 0))

    async def initialize(self) -> None:
        """Ініціалізує кеш курсів з диску та створює HTTP-клієнт."""
        self._rates = await self._load_rates_from_file()
        self._client = httpx.AsyncClient(timeout=self._timeout)
        logger.info("🔧 CurrencyManager ініціалізовано з курсами: %s", self._rates)

    async def close(self) -> None:
        """Акуратно закриває HTTP-клієнт."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            logger.info("🔌 HTTP-клієнт менеджера валют закрито.")

    async def update_all_rates_if_needed(self) -> None:
        """🔄 Оновлює курси лише якщо минув TTL."""
        if self.is_cache_fresh():
            logger.debug("⏱️ Курси свіжі (TTL). Оновлення пропущено.")
            return
        logger.info("⏰ TTL вичерпано — запускаю оновлення курсів…")
        await self.update_all_rates()

    async def update_all_rates(self) -> None:
        """🔄 Примусово оновлює курси з API та оновлює last_update_ts."""
        api_data = await self._fetch_api_data()
        if api_data is None:
            logger.warning("⚠️ Не вдалося отримати дані від API, оновлення курсів скасовано.")
            return

        async with self._lock:
            was_updated = self._process_api_data(api_data)
            if was_updated:
                await self._save_rates_to_file()
            self._last_update_ts = time.time()

    async def set_rate_manually(self, currency: str, rate: Union[Decimal, float, int, str]) -> None:
        """
        ✍️ Ручна установка курсу конкретної валюти (UAH за 1 одиницю).
        Підтримує Decimal/float/int/str; значення безпечно нормалізується та квантовується.
        """
        safe_rate = self._to_decimal(rate)
        if safe_rate <= 0:
            logger.error("🚫 Спроба встановити невалідний курс для %s: %r", currency, rate)
            raise ValueError("Невалідний курс (повинен бути > 0).")

        ccy = (currency or "").upper().strip()
        if not ccy:
            raise ValueError("Порожній код валюти.")

        async with self._lock:
            self._rates[ccy] = self._quantize_rate(safe_rate)
            await self._save_rates_to_file()
            self._last_update_ts = time.time()
            logger.info("✍️ Курс для %s встановлено вручну: %s", ccy, self._rates[ccy])

    # ================================
    # 🔒 ВНУТРІШНЯ ЛОГІКА
    # ================================
    def _process_api_data(self, api_data: List[Dict[str, Any]]) -> bool:
        """
        Обробляє сирі дані Monobank і оновлює внутрішню мапу курсів по заданих кодах.
        Повертає True, якщо відбулося хоч одне оновлення.
        """
        was_updated = False
        margin = self._to_decimal(self._margin_raw)

        for currency_name, currency_code in self._currency_codes.items():
            entry = self._find_pair(api_data, a=currency_code, b=self._UAH_CODE)
            if not entry:
                continue

            raw_rate = entry.get("rateSell") or entry.get("rateCross") or entry.get("rateBuy")
            if raw_rate is None:
                continue

            try:
                base_rate = self._to_decimal(raw_rate)
                new_rate = self._quantize_rate(base_rate + margin)
            except (ValueError, TypeError):
                logger.warning("⚠️ Неможливо конвертувати курс: %r", raw_rate)
                continue

            old_rate = self._rates.get(currency_name, Decimal("0"))
            if new_rate > old_rate or old_rate <= 0:
                logger.info("🔺 Курс %s оновлено: %s → %s", currency_name, old_rate, new_rate)
                self._rates[currency_name] = new_rate
                was_updated = True

        return was_updated

    def _find_pair(self, api_data: List[Dict[str, Any]], a: int, b: int) -> Optional[Dict[str, Any]]:
        """Повертає перший запис з пари (currencyCodeA=a, currencyCodeB=b)."""
        for entry in api_data:
            if entry.get("currencyCodeA") == a and entry.get("currencyCodeB") == b:
                return entry
        return None

    async def _fetch_api_data(self) -> Optional[List[Dict[str, Any]]]:
        """Багатоспробне отримання даних з API валют."""
        if not self._client:
            raise RuntimeError("HTTP-клієнт не ініціалізовано (initialize() не викликано).")

        for attempt in range(max(1, int(self._retries))):
            try:
                response = await self._client.get(self._api_url)
                response.raise_for_status()
                api_response = response.json()
                if isinstance(api_response, list):
                    logger.info("✅ Дані з API валют успішно отримано.")
                    return api_response
                logger.warning("⚠️ API валют повернуло не список, а %s", type(api_response).__name__)
                return None

            except httpx.RequestError as e:
                logger.error("❌ Спроба %s/%s: помилка API валют — %s", attempt + 1, self._retries, e)
                if attempt < self._retries - 1:
                    await asyncio.sleep(max(0, int(self._retry_delay)))
        return None

    async def _load_rates_from_file(self) -> Dict[str, Decimal]:
        """
        Безпечно читає кеш курсів з файлу. Якщо не вийшло — підтягує fallback з конфіга.
        Гарантує наявність UAH=1.0.
        """
        rates: Dict[str, Decimal]
        try:
            async with aiofiles.open(self._rate_file_path, "r", encoding="utf-8") as f:
                content = await f.read()
            parsed = json.loads(content)
            if not isinstance(parsed, dict):
                raise ValueError("Очікувався об'єкт (dict) у кеш-файлі курсів.")
            rates = {k.upper(): self._quantize_rate(self._to_decimal(v)) for k, v in parsed.items()}
            logger.info("📖 Завантажено кешовані курси: %s", rates)

        except (IOError, json.JSONDecodeError, ValueError, FileNotFoundError) as e:
            logger.warning("⚠️ Не вдалося прочитати файл курсів (%s). Використовуються резервні значення.", e)
            fb = self._config.get("currency_api.fallback_rates", {}) or {}
            rates = {k.upper(): self._quantize_rate(self._to_decimal(v)) for k, v in fb.items()}

        if "UAH" not in rates or rates.get("UAH", Decimal("0")) <= 0:
            rates["UAH"] = Decimal("1.0").quantize(self._RATE_QUANTUM, rounding=self._ROUNDING)

        self._last_update_ts = time.time()
        return rates

    async def _save_rates_to_file(self) -> None:
        """Пише актуальні курси у кеш-файл (серіалізуємо Decimal як рядки)."""
        payload_obj = {k: str(v) for k, v in self._rates.items()}
        payload = json.dumps(payload_obj, indent=2, ensure_ascii=False)
        try:
            async with aiofiles.open(self._rate_file_path, "w", encoding="utf-8") as f:
                await f.write(payload)
            logger.info("💾 Кеш курсів збережено: %s", self._rates)
        except IOError as e:
            logger.error("❌ Помилка під час збереження курсів: %s", e)

    # ================================
    # 🧰 ДОПОМІЖНІ (безпечні числові операції)
    # ================================
    @staticmethod
    def _to_decimal(value: Union[Decimal, float, int, str]) -> Decimal:
        """Акуратно приводить значення до Decimal (через str/strip; коми → крапки)."""
        if isinstance(value, Decimal):
            return value
        if isinstance(value, (int, float)):
            return Decimal(str(value))
        if isinstance(value, str):
            v = value.strip().replace(",", ".")
            return Decimal(v)
        raise ValueError(f"Непідтримуваний тип числа: {type(value).__name__}")

    def _quantize_rate(self, value: Decimal) -> Decimal:
        """Квантує курс до 4 знаків після коми (стабільність JSON/порівнянь)."""
        return value.quantize(self._RATE_QUANTUM, rounding=self._ROUNDING)
