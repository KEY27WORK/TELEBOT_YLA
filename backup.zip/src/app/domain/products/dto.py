# 📦 app/domain/products/dto.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from .entities import Url

@dataclass(frozen=True, slots=True)
class ProductHeaderDTO:
    """Лёгкий DTO заголовка товара (без полного парсинга)."""
    title: str
    image_url: Optional[str]
    product_url: Url