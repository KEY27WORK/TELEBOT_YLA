# 📚 app/infrastructure/parsers/collections/__init__.py
"""
📚 Пакет `collections` — парсери для колекцій товарів YoungLA.

Що всередині:
- `UniversalCollectionParser` — надійний INFRA-рівневий парсер сторінок колекцій:
  • читає JSON-LD (ItemList / CollectionPage / SearchResultsPage),
  • робить DOM-fallback за кількома селекторами,
  • канонізує/нормалізує посилання, унікалізує результат,
  • (опційно) проходить пагінацію до кількох сторінок.

Призначення:
- Отримати список URL товарів із будь-якої `/collections/...` сторінки, щоби далі кожен товар
  розібрати окремим парсером (див. `BaseParser`) або передати у вищий рівень (handler’и бота).

Використання (скорочено):
----------------------------------------------------------------
parser = UniversalCollectionParser(url, webdriver_service, config_service, url_parser_service)
links: list[str] = await parser.get_product_links()
----------------------------------------------------------------

⚠️ Залежності INFRA (без доменних інтерфейсів):
- `WebDriverService.fetch_page_source(url: str) -> str | None`
- `UrlParserService`:
    • `get_currency(url: str) -> str | None`
    • `get_base_url(currency: str | None) -> str`
    • (опційно) `normalize(url: str) -> str`

Доменну сумісність забезпечує `ParserFactoryAdapter`, який огортає реальні парсери в інтерфейси domain-шару.
"""

from .universal_collection_parser import UniversalCollectionParser

__all__ = ["UniversalCollectionParser"]