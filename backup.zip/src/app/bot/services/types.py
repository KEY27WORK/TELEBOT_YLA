# 🧰 app/bot/services/types.py
"""
🧰 types.py — Загальні типи даних для сервісів та фіч бота.

🔹 Призначення:
- Визначає контракти (протоколи) для взаємодії між частинами бота.
- Надає уніфіковані типи колбек-обробників для inline-кнопок.
- Допомагає уникати циклічних залежностей завдяки слабкому зв'язуванню (Protocol).
"""

# 🔠 Системні імпорти
from typing import Protocol, Mapping, Callable, Awaitable, TypeAlias							# 🧰 Базові типи та протоколи

# 🌐 Зовнішні бібліотеки
from telegram import Update																			# 🤖 Тип події Telegram (оновлення)

# 🧩 Внутрішні модулі проєкту
from .callback_data_factory import CallbackData												# 🔗 Типізовані дані для callback_data
from .custom_context import CustomContext													# 🧠 Кастомний контекст бота


# ================================
# 🔧 ТИПИ ТА ПРОТОКОЛИ
# ================================
# Тип для асинхронних обробників inline-кнопок (Update + наш CustomContext)
CallbackHandlerType: TypeAlias = Callable[[Update, CustomContext], Awaitable[None]]		# ⏱️ Сигнатура: async def handler(update, context) -> None


class Registrable(Protocol):
    """
    📋 Протокол, що описує об'єкт, здатний реєструвати/надавати
    словник обробників для inline-кнопок (callback_query).

    Використання Protocol дозволяє уникати жорстких залежностей від
    конкретних класів, дотримуючись принципів SOLID (LSP, DIP).
    """

    def get_callback_handlers(self) -> Mapping[CallbackData, CallbackHandlerType]:
        """
        Повертає словник мапінгу callback-ключів на асинхронні обробники.

        Returns:
            Mapping[CallbackData, CallbackHandlerType]:
                {ключ_callback'у → async-обробник (Update, CustomContext) -> None}
        """
        ...																					# «Protocol-тіло» не реалізується (ellipsis)


# ================================
# 📦 ПУБЛІЧНИЙ API МОДУЛЯ
# ================================
__all__ = [
    "CallbackHandlerType",
    "Registrable",
    "CallbackData",
    "CustomContext",
]																				# 🪪 Обмежуємо, що експортується з модуля