# 📋 app/shared/utils/prompts.py
"""
📋 prompts.py — сумісний шар для роботи з текстовими промтами.

🔹 Це легкий **shim** над PromptService (ледаче завантаження файлів, без падіння на старті).
🔹 Збережено публічний інтерфейс (Enums + функції), щоб не ламати існуючі імпорти.
🔹 Рекомендовано мігрувати на `PromptService` напряму: 
    from app.shared.utils.prompt_service import PromptService, PromptType, ChartType
"""

from __future__ import annotations

# 🔠 Системні імпорти
from enum import Enum  # 🏷️ Публічні Enums для зворотної сумісності

# 🧩 Внутрішні модулі (новий сервіс промтів)
from .prompt_service import PromptService, PromptType as _PT, ChartType as _CT


# ================================
# 🏷️ ПУБЛІЧНІ ENUMS (COMPAT)
# ================================
class PromptType(str, Enum):
    """Типи промтів (сумісні значення зі старою версією)."""
    MUSIC = _PT.MUSIC.value
    HASHTAGS = _PT.HASHTAGS.value
    WEIGHT = _PT.WEIGHT.value
    CLOTHING_TYPE = _PT.CLOTHING_TYPE.value
    TRANSLATION = _PT.TRANSLATION.value
    SLOGAN = _PT.SLOGAN.value


class ChartType(str, Enum):
    """Типи шаблонів для OCR-таблиць розмірів (сумісні значення)."""
    GENERAL = _CT.GENERAL.value
    UNIQUE = _CT.UNIQUE.value
    UNIQUE_GRID = _CT.UNIQUE_GRID.value


# ================================
# 🧠 СИНГЛТОН СЕРВІСУ
# ================================
# Використовує дефолтні шляхи та кешування всередині PromptService.
_ps = PromptService()


# ================================
# 🏭 ПУБЛІЧНІ ФУНКЦІЇ (COMPAT)
# ================================
def get_prompt(prompt_type: PromptType, **kwargs) -> str:
    """
    🧠 Повертає відформатований текст промта.
    Зберігає сигнатуру старого API, делегує в PromptService.
    """
    return _ps.get_prompt(_PT(prompt_type.value), **kwargs)


def get_size_chart_prompt(chart_type: ChartType) -> str:
    """
    📏 Повертає OCR-промт для таблиці розмірів, зібраний із шаблону та JSON-прикладу.
    """
    return _ps.get_size_chart_prompt(_CT(chart_type.value))


# ================================
# 📦 ПУБЛІЧНИЙ API МОДУЛЯ
# ================================
__all__ = [
    "PromptType",
    "ChartType",
    "get_prompt",
    "get_size_chart_prompt",
]