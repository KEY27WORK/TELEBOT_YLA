"""
🧠 Пакет `domain.ai` — доменні контракти для AI.
Тут лише інтерфейси (Protocol/ABC) та прості DTO/Enums, без залежностей від інфраструктури.
Реалізації цих контрактів живуть у шарі `infrastructure/ai`.
"""

# Контракт на побудову промтів + доменні DTO/Enums (чисті, без OpenAI SDK)
from .interfaces.prompt_service_interface import (
    IPromptService,
    ProductPromptDTO,
    ChatPrompt,
    ChatMessage,
    TextPart,
    ImagePart,
    ContentPart,
    Tone,
    Lang,
    Role,
)

# Контракти для high-level задач (вага/переклад/слоган)
from .task_contracts import IWeightEstimator, ITranslator, ISloganGenerator

__all__ = [
    # Prompt contract + DTO/Enums
    "IPromptService",
    "ProductPromptDTO",
    "ChatPrompt",
    "ChatMessage",
    "TextPart",
    "ImagePart",
    "ContentPart",
    "Tone",
    "Lang",
    "Role",
    # High-level task contracts
    "IWeightEstimator",
    "ITranslator",
    "ISloganGenerator",
]