# 🔗 app/infrastructure/url/youngla_strategy.py
"""
🔗 YoungLAUrlStrategy — бренд-специфічна стратегія парсингу URL для YoungLA.

Ключові акценти:
- Працюємо тільки з дозволеними доменами із конфіга (строго), без substring-перевірок.
- Підтримуються сабдомени дозволених root-доменів (напр., `uk.youngla.eu`).
- Сумісність із протоколом IUrlParsingStrategy (supports(self, domain: str)).

Очікуваний фрагмент конфіга:
regions:
  usd:
    base_url: "https://youngla.com"
    currency: "USD"
  eur:
    base_url: "https://youngla.eu"
    currency: "EUR"
  gbp:
    base_url: "https://youngla.co.uk"
    currency: "GBP"
  pln:
    base_url: "https://youngla.pl"
    currency: "PLN"
"""

from __future__ import annotations

import re
from typing import Optional, Dict, Any, Iterable
from urllib.parse import urlparse

from app.shared.utils.interfaces import IUrlParsingStrategy
from app.config.config_service import ConfigService


class YoungLAUrlStrategy(IUrlParsingStrategy):
    """
    Конкретна стратегія роботи з URL YoungLA.
    — Працює **виключно** з доменами, оголошеними у конфігу.
    — Вміє розпізнавати відповідний регіон/валюту за доменом.
    """

    _REGION_LABELS: Dict[str, str] = {
        "USD": "US 🇺🇸",
        "EUR": "EU 🇪🇺",
        "GBP": "UK 🇬🇧",
        "PLN": "PL 🇵🇱",
    }

    def __init__(self, config: ConfigService) -> None:
        self._cfg: ConfigService = config
        self._regions: Dict[str, Any] = self._cfg.get("regions") or {}

        # Нормалізовані дозволені «root» домени (без www, без порту)
        self._allowed_roots: set[str] = {
            self._norm_domain(v.get("base_url", ""))
            for v in self._regions.values()
            if v.get("base_url")
        }

        # Мапа root-домен -> вузол регіону (для швидкого пошуку)
        self._root_to_region: Dict[str, Dict[str, Any]] = {}
        for data in self._regions.values():
            root = self._norm_domain(data.get("base_url", ""))
            if root:
                self._root_to_region[root] = data

    # ──────────────────────────────────────────────────────────────────────
    # IUrlParsingStrategy
    # ──────────────────────────────────────────────────────────────────────
    def supports(self, domain: str) -> bool:
        """
        Чи належить домен до YoungLA?
        Аргумент тут — саме домен (не повний URL), згідно з контрактом Protocol.
        ✅ Повертає True, якщо це один із дозволених root-доменів або його сабдомен.
        """
        dom = self._norm_domain(domain)
        if not dom or not self._allowed_roots:
            return False
        return self._is_same_or_subdomain(dom, self._allowed_roots)

    def get_currency(self, url: str) -> Optional[str]:
        """Визначає валюту (USD/EUR/GBP/PLN) за доменом URL."""
        dom = self._norm_domain(url)
        if not dom:
            return None
        root = self._match_root(dom, self._allowed_roots)
        if not root:
            return None
        node = self._root_to_region.get(root) or {}
        return node.get("currency")

    def get_region_label(self, url: str) -> str:
        """Назва регіону з прапорцем (напр., 'US 🇺🇸')."""
        ccy = self.get_currency(url)
        return self._REGION_LABELS.get(ccy or "", "Unknown")

    def get_base_url(self, currency: str) -> Optional[str]:
        """Базовий URL для вказаної валюти (якщо є у конфігу)."""
        if not currency:
            return None
        node = self._regions.get(currency.lower())
        return (node or {}).get("base_url")

    def build_product_url(self, region_code: str, product_path: str) -> Optional[str]:
        """Побудувати повний URL товару для заданого регіону."""
        if not region_code or not product_path:
            return None
        node = self._regions.get(region_code.lower())
        base = (node or {}).get("base_url")
        if not base:
            return None
        return f"{base.rstrip('/')}/products/{product_path.lstrip('/')}"

    def is_product_url(self, url: str) -> bool:
        """Чи є посиланням на товар YoungLA?"""
        return self._belongs_to_brand(url) and "/products/" in (urlparse(url).path or "")

    def is_collection_url(self, url: str) -> bool:
        """Чи є посиланням на колекцію YoungLA?"""
        return self._belongs_to_brand(url) and "/collections/" in (urlparse(url).path or "")

    def extract_product_slug(self, url: str) -> Optional[str]:
        """Витягти slug товару з шляху `/products/...`."""
        path = urlparse(url).path or ""
        m = re.search(r"/products/([^/?#]+)", path)
        return m.group(1) if m else None

    # ──────────────────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────────────────
    def _belongs_to_brand(self, url_or_domain: str) -> bool:
        """True, якщо URL/домен належить до дозволених root-доменів YoungLA."""
        dom = self._norm_domain(url_or_domain)
        if not dom:
            return False
        return self._is_same_or_subdomain(dom, self._allowed_roots)

    @staticmethod
    def _norm_domain(url_or_domain: str) -> str:
        """
        Приводить домен до канонічного вигляду:
        - якщо передали URL — витягує netloc
        - lower()
        - прибирає префікс 'www.' та порт (':443' тощо)
        """
        if not url_or_domain:
            return ""
        dom = urlparse(url_or_domain).netloc if "://" in url_or_domain else url_or_domain
        dom = (dom or "").strip().lower()
        if dom.startswith("www."):
            dom = dom[4:]
        if ":" in dom:
            dom = dom.split(":", 1)[0]
        return dom

    @staticmethod
    def _is_same_or_subdomain(domain: str, roots: Iterable[str]) -> bool:
        """True, якщо `domain` == root або є його сабдоменом."""
        for root in roots:
            if domain == root or domain.endswith("." + root):
                return True
        return False

    @staticmethod
    def _match_root(domain: str, roots: Iterable[str]) -> Optional[str]:
        """Повертає root-домен, якому належить `domain` (повний збіг або сабдомен)."""
        for root in roots:
            if domain == root or domain.endswith("." + root):
                return root
        return None