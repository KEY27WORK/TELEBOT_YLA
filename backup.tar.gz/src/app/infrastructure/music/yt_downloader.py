# 📥 app/infrastructure/music/yt_downloader.py
"""
Загрузка музыки с YouTube через yt-dlp (конвертация в MP3).
Совместимо с доменным DTO RecommendedTrack.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import time

import yt_dlp
from yt_dlp.utils import DownloadError

from app.config.config_service import ConfigService
from app.domain.music.interfaces import (
    IMusicDownloader,
    TrackInfo,
    RecommendedTrack,   # 👈 ВАЖНО: импортируем DTO
)
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


class YtDownloader(IMusicDownloader):
    """
    Публичный API: download(track: RecommendedTrack) -> TrackInfo
    """

    def __init__(self, config: ConfigService) -> None:
        self._config = config
        self._cache_dir: str = str(config.get("files.music_cache", "music_cache"))
        os.makedirs(self._cache_dir, exist_ok=True)

        self._socket_timeout = int(config.get("music.download.socket_timeout", 15) or 15)
        self._retries = int(config.get("music.download.retries", 3) or 3)
        self._fragment_retries = int(config.get("music.download.fragment_retries", 3) or 3)
        self._concurrent_fragments = int(config.get("music.download.concurrent_fragments", 4) or 4)
        self._preferred_bitrate = str(config.get("music.download.mp3_bitrate_kbps", "192") or "192")

    # ── Публичный API ──────────────────────────────────────────────────────
    async def download(self, track: RecommendedTrack) -> TrackInfo:
        """Асинхронная обёртка над блокирующей загрузкой."""
        return await asyncio.to_thread(self._blocking_download, track)

    # ── Внутреннее ────────────────────────────────────────────────────────
    def _blocking_download(self, track: RecommendedTrack) -> TrackInfo:
        """
        Синхронная часть: yt-dlp + ffmpeg постпроцессинг.
        """
        display_name = self._display_name(track)            # "Artist – Title" или просто title
        final_path = self._generate_path(display_name)

        if os.path.exists(final_path):
            logger.info("🎵 Трек уже в кэше: %s", final_path)
            return TrackInfo(name=display_name, file_path=final_path)

        temp_base = final_path[:-4]  # без ".mp3"
        archive_path = os.path.join(self._cache_dir, "download_archive.txt")

        ydl_opts = {
            "format": "bestaudio/best",
            "noplaylist": True,
            "quiet": True,
            "outtmpl": temp_base + ".%(ext)s",
            "socket_timeout": self._socket_timeout,
            "download_archive": archive_path,
            "retries": self._retries,
            "fragment_retries": self._fragment_retries,
            "concurrent_fragment_downloads": self._concurrent_fragments,
            "postprocessors": [
                {
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": self._preferred_bitrate,
                }
            ],
        }

        query = f"ytsearch1:{display_name}"

        delay = 1.5  # небольшой backoff
        for attempt in range(1, self._retries + 1):
            try:
                logger.info("⬇️ Загрузка (%s/%s): %s", attempt, self._retries, display_name)
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    ydl.download([query])

                if not os.path.exists(final_path):
                    # запись в archive есть, а файла нет — повторим без archive
                    logger.warning("Запись в download_archive есть, но mp3 не найден. Повтор без archive…")
                    ydl_opts.pop("download_archive", None)
                    with yt_dlp.YoutubeDL(ydl_opts) as ydl_retry:
                        ydl_retry.download([query])

                if not os.path.exists(final_path):
                    raise FileNotFoundError("После постпроцессинга mp3 не появился.")

                logger.info("✅ Готово: %s", final_path)
                return TrackInfo(name=display_name, file_path=final_path)

            except (DownloadError, FileNotFoundError) as e:
                logger.warning("Попытка %s не удалась: %s", attempt, e)
                if attempt >= self._retries:
                    break
                time.sleep(delay)
                delay *= 1.8  # экспоненциальный backoff
            except Exception as e:  # noqa: BLE001
                logger.exception("Непредвиденная ошибка загрузки: %s", e)
                break

        return TrackInfo(name=display_name, error="Не удалось загрузить трек.")

    # ── Помощники ─────────────────────────────────────────────────────────
    @staticmethod
    def _display_name(track: RecommendedTrack) -> str:
        """
        Унифицированное имя трека для поиска/имени файла.
        """
        # если у RecommendedTrack есть готовое поле display_name — используем его
        dn = getattr(track, "display_name", None)
        if isinstance(dn, str) and dn.strip():
            return dn.strip()

        artist = getattr(track, "artist", "") or ""
        title = getattr(track, "title", "") or ""
        base = f"{artist} – {title}".strip(" –")
        return base if base else (title or artist or "track")

    def _generate_path(self, display_name: str) -> str:
        clean = self._clean_name(display_name)
        return os.path.join(self._cache_dir, f"{clean}.mp3")

    @staticmethod
    def _clean_name(name: str) -> str:
        name = re.sub(r"[^\w\s\-\(\)\[\]]", "", name or "").strip()
        return re.sub(r"\s+", "_", name)