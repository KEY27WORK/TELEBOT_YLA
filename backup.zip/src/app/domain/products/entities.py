# 📦 app/domain/products/entities.py
"""
📦 Доменно-чисті сутності для товарів.

Призначення:
- Визначає чисту, валідовану та незмінну структуру даних `ProductInfo`.
- Не залежить від парсерів, API чи інфраструктури (чиста модель).
- Використовується в бізнес-логіці як єдине джерело правди про товар.

Ключові рішення:
- 🧮 Гроші — `Decimal` (точність фінансів, відсутність float-похибок).
- ⚖️ Вага — `weight_g: int` у грамах (завжди ціле число, без округлень і похибок).
- 📦 Наявність — типобезпечний `AvailabilityStatus` замість `bool`.
"""


from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from enum import Enum
from types import MappingProxyType
from typing import Any, Dict, Mapping

# ──────────────────────────────────────────────────────────────────────────────
# URL (залишаємо як було — нічого не ламаємо)
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True, slots=True)
class Url:
    """Чистая value-object. Хранит только валидный абсолютный URL."""
    value: str

    def __post_init__(self):
        v = (self.value or "").strip()
        if not (v.startswith("http://") or v.startswith("https://")):
            raise ValueError(f"Url must be absolute (http/https): {v!r}")
        object.__setattr__(self, "value", v)

    def __str__(self) -> str:
        return self.value


# ──────────────────────────────────────────────────────────────────────────────
# ДОДАТКОВІ ДОМЕННІ ТИПИ
# ──────────────────────────────────────────────────────────────────────────────

class Currency(str, Enum):
    USD = "USD"
    EUR = "EUR"
    GBP = "GBP"
    PLN = "PLN"
    UAH = "UAH"


# Якщо в тебе вже є свій AvailabilityStatus у domain/availability — підключи його.
# Тут робимо легкий fallback, щоб цей файл був самодостатній.
try:
    from app.domain.availability import AvailabilityStatus  # type: ignore
except Exception:
    class AvailabilityStatus(str, Enum):  # fallback
        IN_STOCK = "in_stock"
        LOW_STOCK = "low_stock"
        OUT_OF_STOCK = "out_of_stock"
        UNKNOWN = "unknown"


Sections = Mapping[str, str]
StockBySize = Mapping[str, AvailabilityStatus]   # розмір -> статус
StockData = Mapping[str, StockBySize]            # колір/вариант -> (розміри -> статус)


def _mp(d: dict) -> MappingProxyType:
    """Незмінний проксі-словник (щоб не плодити копії)."""
    return MappingProxyType(d)


# ──────────────────────────────────────────────────────────────────────────────
# ОСНОВНА СУТНІСТЬ ТОВАРУ
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(slots=True, frozen=True)
class ProductInfo:
    """
    Повна, валідована та незмінна інформація про товар.
    - price: Decimal (фінансова точність)
    - weight_g: int (грами)
    - sections/stock_data: незмінні мапи
    """
    # Обов'язкові поля
    title: str
    price: Decimal

    # Опис/медіа
    description: str = "Опис відсутній"
    image_url: str = ""
    images: tuple[str, ...] = field(default_factory=tuple)

    # Додаткові поля
    sections: Sections = field(default_factory=lambda: _mp({}))
    stock_data: StockData = field(default_factory=lambda: _mp({}))
    currency: Currency = Currency.USD
    weight_g: int = 500  # дефолт безпечний baseline

    def __post_init__(self):
        # title
        t = (self.title or "").strip()
        if not t:
            raise ValueError("Назва товару (title) не може бути порожньою.")
        object.__setattr__(self, "title", t)

        # price → Decimal ≥ 0
        try:
            price_decimal = Decimal(self.price)
        except (InvalidOperation, TypeError):
            raise ValueError(f"Некоректне значення ціни: {self.price}")
        if price_decimal < 0:
            raise ValueError("Ціна не може бути від'ємною.")
        object.__setattr__(self, "price", price_decimal)

        # weight_g → int ≥ 0
        try:
            wg = int(self.weight_g)
        except (TypeError, ValueError):
            raise ValueError(f"Некоректна вага (weight_g): {self.weight_g}")
        if wg < 0:
            raise ValueError("Вага (weight_g) не може бути від'ємною.")
        object.__setattr__(self, "weight_g", wg)

        # images → unique tuple
        if self.images:
            seen: set[str] = set()
            unique = tuple(img for img in self.images if img and not (img in seen or seen.add(img)))
            object.__setattr__(self, "images", unique)

    # Зручний серіалізатор (напр., для відповіді в бот)
    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "price": str(self.price),                 # Decimal -> str (без втрати)
            "description": self.description,
            "image_url": self.image_url,
            "images": list(self.images),
            "sections": dict(self.sections),
            "stock_data": {
                color: {size: status.value for size, status in sizes.items()}
                for color, sizes in self.stock_data.items()
            },
            "currency": self.currency.value,
            "weight_g": self.weight_g,
        }


__all__ = [
    "Url",
    "ProductInfo",
    "Currency",
    "Sections",
    "StockData",
    "StockBySize",
]