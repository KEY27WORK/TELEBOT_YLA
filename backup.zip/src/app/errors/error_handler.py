# 🛠️ app/errors/error_handler.py
"""
Фабрика декораторов для безопасного выполнения async-хендлеров.
"""

from __future__ import annotations

import asyncio
import functools
from typing import Any, Awaitable, Callable, Coroutine, Optional

from telegram import Update

from .exception_handler_service import ExceptionHandlerService


# Сигнатура: совместимая с typedi/telegram handlers
AsyncHandler = Callable[..., Awaitable[Any]]


def make_error_handler(service: ExceptionHandlerService) -> Callable[[AsyncHandler], AsyncHandler]:
    """
    Возвращает декоратор, замкнутый на переданный сервис (DI-friendly).
    Декоратор:
      • не меняет сигнатуру цели,
      • корректно пропускает CancelledError,
      • находит Update среди *args/**kwargs,
      • передает ошибку в ExceptionHandlerService.handle.
    """
    def decorator(func: AsyncHandler) -> AsyncHandler:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return await func(*args, **kwargs)
            except asyncio.CancelledError:
                # никогда не глотаем отмену
                raise
            except Exception as e:
                update: Optional[Update] = kwargs.get("update")
                if update is None:
                    # Ищем Update среди позиционных
                    for arg in args:
                        if isinstance(arg, Update):
                            update = arg
                            break
                await service.handle(e, update)
                return None
        return wrapper  # type: ignore[return-value]
    return decorator