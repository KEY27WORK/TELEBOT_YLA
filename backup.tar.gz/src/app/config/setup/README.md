# 🧰 app/config/setup

Пакет "сборки" приложения. Здесь нет бизнес‑логики — только инфраструктура,
инициализация зависимостей и регистрация обработчиков Telegram‑бота.

## 📦 Состав

- `constants.py` — типобезопасные константы проекта:
  - UI‑тексты и эмодзи,
  - режимы/команды/ключи user_data,
  - валютные мапы `PRICE_ORDER`, `CURRENCY_SYMBOLS`, `CURRENCY_MAP`,
  - **legacy‑враппер** `generate_menu_pattern()` (совместим со старым кодом).
- `container.py` — DI‑контейнер, создаёт все сервисы и хендлеры **в правильном порядке**
  (исключая циклические зависимости и ошибки инициализации).
- `bot_registrar.py` — централизованная регистрация всех хендлеров в `telegram.ext.Application`
  с использованием **error‑decorator** из контейнера.

> Пакет экспортирует удобные символы из `__init__.py`:
> ```python
> from app.config.setup import CONST, Container, BotRegistrar, generate_menu_pattern
> ```

## 🧭 Архитектурные принципы

- **Чистые границы слоёв:** верхние слои (bot) зависят от setup, но не наоборот.
- **Единая точка входа в константы:** импортируйте `CONST` вместо жёстких строк.
- **Нулевая бизнес‑логика:** только конфигурация, проводка и регистрация.

## 🚀 Быстрый старт

```python
from telegram.ext import ApplicationBuilder
from app.config.config_service import ConfigService
from app.config.setup import Container, BotRegistrar

# 1) Конфиг и контейнер
config = ConfigService()
container = Container(config)

# 2) Telegram Application (v21)
app = ApplicationBuilder().token("YOUR_TELEGRAM_TOKEN").build()

# 3) Регистрация хендлеров
registrar = BotRegistrar(app, container)
registrar.register_handlers()

# 4) Запуск
app.run_polling(allowed_updates=app.allowed_updates)
