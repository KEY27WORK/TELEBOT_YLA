# 📦 `__init__.py` для `app/infrastructure/availability`

"""
🌍 availability — інфраструктурний шар перевірки наявності.

Відповідає за:
  • Оркестрацію перевірок (`AvailabilityProcessingService`, `AvailabilityManager`)
  • Кешування результатів (`AvailabilityCacheService`)
  • Форматування та побудову звітів (`ColorSizeFormatter`, `AvailabilityReportBuilder`)
  • Інтеграцію з Telegram (`AvailabilityHandler`)
  • DTO та локалізацію (`AvailabilityReports`, `t`, `normalize_lang`)
  • Метрики Prometheus (`metrics`)
"""

from .availability_handler import AvailabilityHandler
from .availability_processing_service import AvailabilityProcessingService, ProcessedAvailabilityData
from .availability_manager import AvailabilityManager
from .cache_service import AvailabilityCacheService
from .report_builder import AvailabilityReportBuilder
from .formatter import ColorSizeFormatter
from .dto import AvailabilityReports
from .i18n import t, normalize_lang

__all__ = [
    "AvailabilityHandler",
    "AvailabilityProcessingService",
    "ProcessedAvailabilityData",
    "AvailabilityManager",
    "AvailabilityCacheService",
    "AvailabilityReportBuilder",
    "ColorSizeFormatter",
    "AvailabilityReports",
    "t",
    "normalize_lang",
]