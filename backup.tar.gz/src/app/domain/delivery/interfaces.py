# 🚚 app/domain/delivery/interfaces.py
"""
🚚 Доменно-орієнтовані контракти для сервісів доставки.

Ключові рішення:
• Гроші — Decimal (жодних float-похибок).
• Вага — лише у грамах (int), як для вхідних аргументів, так і для тарифікованої ваги.
• Контракти чисті: ніяких залежностей від інфраструктури.

Гарантії реалізацій:
• Детермінована поведінка для однакових вхідних даних.
• Жодної мережевої роботи у __init__.
• Не «ковтати» asyncio.CancelledError.
"""

from __future__ import annotations

# 🔠 Системні імпорти
from abc import ABC, abstractmethod
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional


# ================================
# 🏛️ DTO РЕЗУЛЬТАТУ РОЗРАХУНКУ
# ================================
@dataclass(frozen=True, slots=True)
class DeliveryQuote:
    """
    📦 Структурований результат розрахунку вартості доставки.

    Атрибути:
        price (Decimal): Підсумкова ціна доставки.
        currency (str): Валюта ISO‑коду (напр., "USD"). Використовуємо str, аби
            не створювати циклічних залежностей з іншими доменами.
        service_code (str): Ідентифікатор сервісу/тарифу (напр., "meest").
        billed_weight_g (int): Тарифікована вага у грамах (може відрізнятися від фактичної).
    """
    price: Decimal
    currency: str
    service_code: str
    billed_weight_g: int


# ================================
# 🏛️ ІНТЕРФЕЙС СЕРВІСУ ДОСТАВКИ
# ================================
class IDeliveryService(ABC):
    """
    🚚 Контракт для сервісу розрахунку вартості доставки.

    Реалізація повинна:
      • Бути ідемпотентною для однакових аргументів.
      • Перевіряти і (за потреби) нормалізувати вагу та методи тарифікації.
      • Повертати валідний DeliveryQuote або кинути доменний виняток.
    """
    @abstractmethod
    def quote(
        self,
        *,
        country: str,                      # ISO‑2: "UA", "PL", ...
        method: str,                       # "air" | "ground" | ...
        type_: str,                        # "parcel" | "letter" | ...
        weight_g: int,                     # фактична вага, г
        volumetric_weight_g: Optional[int] = None,  # об’ємна вага, г
    ) -> DeliveryQuote:
        """
        📐 Розрахувати вартість доставки.

        Args:
            country: 🌍 Двобуквений код країни призначення (ISO‑3166‑1 alpha‑2), напр. "UA", "PL".
            method:  🚛 Метод/канал доставки (напр., "air", "ground", "express").
            type_:   📦 Тип відправлення (напр., "parcel", "letter").
            weight_g:            ⚖️ Фактична вага у грамах (невід’ємне ціле).
            volumetric_weight_g: 📦 Об’ємна вага у грамах (за наявності, невід’ємне ціле).

        Returns:
            DeliveryQuote: Структурований результат із Decimal‑ціною
            та тарифікованою вагою у грамах.
        """
        ...


# ================================
# 📦 ПУБЛІЧНИЙ API МОДУЛЯ
# ================================
__all__ = ["DeliveryQuote", "IDeliveryService"]
