# app/shared/utils/number.py
"""
app/shared/utils/number.py

Единая нормализация цены → Decimal.

Публичное API:
    - sanitize_price_text(text: str) -> str
    - decimal_from_price_str(text: str | float | int | None) -> Decimal
"""

from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation
from typing import Union

# Удаляем всё, что не цифры/минус/запятая/точка
_TRASH_RE = re.compile(r"[^\d,.\-]")

def sanitize_price_text(text: str) -> str:
    """
    Очищает строку цены от валютных символов/пробелов/мусора.
    Сохраняет только цифры, '-', ',' и '.'.
    Нормализует множественные минусы: оставляет один ведущий при необходимости.
    """
    if text is None:
        return ""
    s = str(text).strip()
    if not s:
        return ""
    s = _TRASH_RE.sub("", s)
    # если минус встречается несколько раз — оставляем только ведущий
    if s.count("-") > 1:
        s = ("-" if s.lstrip().startswith("-") else "") + s.replace("-", "")
    return s

def _normalize_decimal_separators(clean: str) -> str:
    """
    Нормализует разделители для европейских/US форматов.
    Примеры:
      1.234,56 -> 1234.56
      1,234.56 -> 1234.56
      1234,56  -> 1234.56
      1234.56  -> 1234.56
    """
    if not clean:
        return ""
    if "," in clean and "." in clean:
        last_comma = clean.rfind(",")
        last_dot = clean.rfind(".")
        # правый разделитель трактуем как дробный
        if last_comma > last_dot:
            clean = clean.replace(".", "")
            clean = clean.replace(",", ".")
        else:
            clean = clean.replace(",", "")
    else:
        # если только запятая — считаем её десятичной
        clean = clean.replace(",", ".")
    return clean

def decimal_from_price_str(text: Union[str, float, int, None]) -> Decimal:
    """
    Приводит значение к Decimal, устойчиво к форматам:
      "€ 1.234,56", "USD 1,234.56", "1 234,56", 1234.56, 1234, None и т.п.
    Любая ошибка → Decimal("0.0").
    """
    if text is None:
        return Decimal("0.0")

    if isinstance(text, (int, float)):
        # float -> через str, чтобы не тащить двоичную погрешность
        try:
            return Decimal(str(text))
        except Exception:
            return Decimal("0.0")

    s = sanitize_price_text(text)
    if not s or s in (".", "-", "-."):
        return Decimal("0.0")

    s = _normalize_decimal_separators(s)
    if not s or s in (".", "-", "-."):
        return Decimal("0.0")

    try:
        return Decimal(s)
    except InvalidOperation:
        return Decimal("0.0")