# app/infrastructure/size_chart/ocr_service.py
from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
from typing import Optional, Dict, Any, Final, cast

from app.config.config_service import ConfigService
from app.infrastructure.ai.open_ai_serv import OpenAIService
from app.infrastructure.ai.prompt_service import PromptService
from app.infrastructure.size_chart.dto import SizeChartOcrResult, SizeChartOcrStatus
from app.shared.utils.prompt_service import ChartType
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(f"{LOG_NAME}.ocr")

_JSON_BLOCK_RE: Final[re.Pattern[str]] = re.compile(
    r"```(?:json)?\s*(.*?)\s*```", re.DOTALL | re.IGNORECASE
)

SizeChartJSON = Dict[str, Any]


def _cfg_float(cfg: ConfigService, key: str, default: float) -> float:
    """Безопасно читает float из конфигурации (з типом, фолбэком и приводом)."""
    v = cfg.get(key, default, cast=float)
    try:
        return float(v) if v is not None else default
    except Exception:
        return default


def _cfg_int(cfg: ConfigService, key: str, default: int) -> int:
    """Безопасно читает int из конфигурации (з типом, фолбэком и приводом)."""
    v = cfg.get(key, default, cast=int)
    try:
        return int(v) if v is not None else default
    except Exception:
        return default


class OCRService:
    """OCR через OpenAI Vision с ретраями и устойчивым JSON-парсером.

    Конфіг:
      • ocr.request_timeout_s
      • ocr.max_retries
      • ocr.backoff_s

    Значения берутся из YAML (напр., src/app/config/yamls/base/25_ocr.yaml),
    а явные аргументы конструктора имеют приоритет.
    """

    def __init__(
        self,
        openai_service: OpenAIService,
        prompt_service: PromptService,
        *,
        request_timeout_s: float | None = None,
        max_retries: int | None = None,
        backoff_s: float | None = None,
    ) -> None:
        self.openai_service = openai_service
        self.prompt_service = prompt_service

        cfg = ConfigService()

        # ⚠️ ВАЖНО: не передаём Optional в float()/int() → сначала выбираем значение
        if request_timeout_s is not None:
            self.request_timeout_s = float(request_timeout_s)
        else:
            self.request_timeout_s = _cfg_float(cfg, "ocr.request_timeout_s", 60.0)

        if max_retries is not None:
            self.max_retries = int(max_retries)
        else:
            self.max_retries = _cfg_int(cfg, "ocr.max_retries", 2)

        if backoff_s is not None:
            self.backoff_s = float(backoff_s)
        else:
            self.backoff_s = _cfg_float(cfg, "ocr.backoff_s", 1.5)

    async def recognize(self, image_path: str, size_chart_type: ChartType) -> SizeChartOcrResult:
        logger.info("🔍 OCR: %s | type=%s", image_path, getattr(size_chart_type, "value", size_chart_type))

        # читаем файл → base64
        try:
            with open(image_path, "rb") as f:
                encoded_image = base64.b64encode(f.read()).decode("utf-8")
        except Exception as e:
            msg = f"io_error: {e}"
            logger.error("❌ Не удалось прочитать файл изображения: %s", e, exc_info=True)
            return SizeChartOcrResult(status=SizeChartOcrStatus.IO_ERROR, error=msg)

        # готовим ChatPrompt (DTO) через PromptService
        prompt = self.prompt_service.size_chart(chart_type=size_chart_type)

        attempt = 0
        last_raw: Optional[str] = None
        while True:
            attempt += 1
            try:
                # ⚠️ явный cast для Pylance
                resp_text = await asyncio.wait_for(
                    cast(OpenAIService, self.openai_service).chat_completion_with_vision(
                        prompt=prompt,
                        image_base64=encoded_image,
                    ),
                    timeout=self.request_timeout_s,
                )

                last_raw = resp_text or ""
                if not resp_text:
                    logger.warning("⚠️ Порожня відповідь від Vision (attempt %s/%s)", attempt, self.max_retries + 1)
                    if attempt > self.max_retries:
                        return SizeChartOcrResult(status=SizeChartOcrStatus.EMPTY, raw_text=last_raw, error="empty_response")
                    await asyncio.sleep(self.backoff_s * attempt)
                    continue

                logger.debug("🧾 Vision raw (preview): %s", self._jsonish_preview(resp_text))

                clean_text = self._extract_json(resp_text)
                data = json.loads(clean_text)

                logger.info("✅ OCR распознан успешно (chars=%s, keys=%s)",
                            len(clean_text), (len(data) if isinstance(data, dict) else "n/a"))
                logger.debug("🧩 OCR JSON (pretty): %s", self._json_preview(data))

                return SizeChartOcrResult(
                    status=SizeChartOcrStatus.OK,
                    data=data if isinstance(data, dict) else {"data": data},
                    raw_text=clean_text,
                )

            except (json.JSONDecodeError, ValueError) as e:
                logger.warning("⚠️ Проблема парсинга OCR (attempt %s/%s): %s",
                               attempt, self.max_retries + 1, e)
                if attempt > self.max_retries:
                    return SizeChartOcrResult(status=SizeChartOcrStatus.INVALID_JSON, raw_text=last_raw,
                                              error=f"json_parse_error: {e}")

            except asyncio.TimeoutError:
                logger.warning("⏳ Vision timeout (attempt %s/%s)", attempt, self.max_retries + 1)
                if attempt > self.max_retries:
                    return SizeChartOcrResult(status=SizeChartOcrStatus.TIMEOUT, raw_text=last_raw, error="timeout")

            except Exception as e:
                logger.error("❌ Критическая ошибка OCR: %s", e, exc_info=True)
                if attempt > self.max_retries:
                    return SizeChartOcrResult(status=SizeChartOcrStatus.API_ERROR, raw_text=last_raw,
                                              error=f"api_error: {e}")

            await asyncio.sleep(self.backoff_s * attempt)

    # ── Helpers ─────────────────────────────────────────────────────────
    @staticmethod
    def _extract_json(text: str) -> str:
        m = _JSON_BLOCK_RE.search(text or "")
        if m:
            return m.group(1).strip()
        s = (text or "").strip()
        first_obj = s.find("{")
        first_arr = s.find("[")
        start = min([x for x in (first_obj, first_arr) if x != -1], default=-1)
        last = max(s.rfind("}"), s.rfind("]"))
        if start != -1 and last != -1 and last > start:
            return s[start:last + 1].strip()
        return s

    @staticmethod
    def _jsonish_preview(text: str, max_chars: int = 1200) -> str:
        s = (text or "").strip()
        return s if len(s) <= max_chars else s[:max_chars] + f"... <trimmed {len(s) - max_chars} chars>"

    @staticmethod
    def _json_preview(data: Any, max_chars: int = 2000) -> str:
        try:
            pretty = json.dumps(data, ensure_ascii=False, indent=2)
        except Exception:
            pretty = str(data)
        return pretty if len(pretty) <= max_chars else pretty[:max_chars] + f"... <trimmed {len(pretty) - max_chars} chars>"