# 🧠 Шаблони Промтів

Директорія **`prompts`** містить усі текстові шаблони, що використовуються для генерації запитів до OpenAI (через GPT-4o/ChatGPT).

📌 Промти зберігаються **окремо від коду** для:
- зручного редагування
- перевикористання у різних сервісах
- підтримки чистої архітектури (SRP, separation of concerns)

---

## 📂 Структура
```bash
prompts/
├── ocr/
│   ├── base.txt
│   ├── example_general.json
│   └── example_unique.json
├── uk/
│   ├── clothing_type.txt
│   ├── hashtags.txt
│   ├── music.txt
│   ├── slogan.txt
│   ├── translation.txt
│   └── weight.txt
├── README.md
└── init.py
```
---

## 🏷️ Підкаталоги

### `uk/`
Україномовні шаблони для генерації:
- `music.txt` — добірка музики
- `hashtags.txt` — генерація хештегів
- `slogan.txt` — створення слоганів
- `weight.txt` — оцінка ваги товару
- `clothing_type.txt` — визначення типу одягу
- `translation.txt` — переклад опису

### `ocr/`
Шаблони та приклади для розпізнавання таблиць розмірів:
- `base.txt` — базовий текстовий шаблон
- `example_unique.json` — приклад для унікальної сітки
- `example_general.json` — приклад для загальної сітки

---

## ⚙️ Використання

Шаблони динамічно завантажуються через:
- **`PromptService`** (`app.shared.utils.prompt_service`)
- сумісні шари (`prompts.py`, `prompt_loader.py`)

### Приклад
```python
from app.shared.utils.prompt_service import PromptService, PromptType

ps = PromptService()
text = ps.get_prompt(
    PromptType.SLOGAN,
    title="YoungLA Oversized Tee",
    description="Чорна футболка з преміальної бавовни"
)
```

## ✏️ Редагування
Шаблони можна змінювати або доповнювати без змін у Python-коді.
Це дозволяє:
	•	швидко оновлювати логіку генерації (наприклад, інструкції для GPT)
	•	адаптувати стиль текстів під бренд YoungLA
	•	уникати повторного деплою коду

⸻

##  ✅ Переваги
	•	Чистий домен: лише текст, без Python-залежностей
	•	Легке редагування: зручне для контент-менеджерів
	•	Продуктивність: кешування файлів у пам’яті (@lru_cache)
	•	Модульність: підтримка багатомовності та різних форматів OCR

⸻