# app/infrastructure/parsers/contracts.py
from __future__ import annotations

from typing import Protocol, runtime_checkable, TYPE_CHECKING, Optional, List, Dict, Any, Union

# ВАЖНО: никаких рантайм-импортов домена — только под TYPE_CHECKING,
# чтобы не ловить циклические зависимости и не тащить домен в runtime.
if TYPE_CHECKING:
    # ДОМЕННЫЕ ТИПЫ (только для тайпчека)
    from app.domain.products.entities import Url, ProductInfo
    from app.domain.products.dto import ProductHeaderDTO
    from app.domain.products.interfaces import (
        ICollectionLinksProvider,
        IProductDataProvider,
        IProductSearchProvider,
    )

__all__ = [
    "ICollectionParser",
    "IProductParser",
    "ISearchParser",
    "IParserFactory",
]


# =============================================================================
# Инфраструктурные «реальные» парсеры (маркерные протоколы)
# -----------------------------------------------------------------------------
# Эти протоколы описывают минимальный контракт классов уровня infrastructure,
# на который опираются адаптеры (ParserFactoryAdapter и т.п.).
# Они НЕ возвращают/принимают инфраструктурные зависимости и не импортируют домен в runtime.
# =============================================================================

@runtime_checkable
class ICollectionParser(Protocol):
    """
    Реальный парсер коллекции (infrastructure): возвращает «сырые» product-URL (str).
    Адаптер приведёт их к Url (domain).
    """
    async def get_product_links(self) -> List[str]:
        """
        Вернуть список ссылок на товары (как строки).
        Пустой список допустим и трактуется как «нет результатов».
        """
        ...


@runtime_checkable
class IProductParser(Protocol):
    """
    Реальный парсер товара (infrastructure).
    Возвращает полные данные товара; опционально — быстрые «заголовочные» данные.
    """

    async def get_product_info(self) -> "ProductInfo":
        """
        Основной метод полного парсинга карточки товара.
        Должен быть устойчив к ошибкам и возвращать валидный ProductInfo
        (даже «пустой/дефолтный», если что-то пошло не так).
        """
        ...

    async def get_header_info(self) -> Union["ProductHeaderDTO", Dict[str, Any], None]:
        """
        (Опционально) Быстрый метод: вернуть минимум для предпросмотра карточки
        (title, image_url, product_url). Если метод не реализован — адаптер
        сделает fallback через get_product_info().
        """
        ...


@runtime_checkable
class ISearchParser(Protocol):
    """
    Реальный поисковый резолвер (infrastructure).
    Задача — найти ПЕРВЫЙ релевантный product URL (str) по строке запроса.
    """
    async def resolve(self, query: str) -> Optional[str]:
        """
        Вернуть product URL в случае удачи или None, если ничего не нашли / капча / таймаут.
        """
        ...


# =============================================================================
# ДОМЕННО-ЧИСТАЯ ФАБРИКА (возвращает уже ДОМЕННЫЕ интерфейсы)
# -----------------------------------------------------------------------------
# Этой фабрикой пользуются верхние слои. Она отвечает за «что отдаёт», а не «как создаёт».
# В реализации — DI/конфиги/адаптеры, которые оборачивают реальные инфраструктурные парсеры
# в доменные интерфейсы.
# =============================================================================

@runtime_checkable
class IParserFactory(Protocol):
    """
    ДОМЕННО-ЧИСТАЯ фабрика провайдеров парсинга.

    Гарантии контракта:
    • Создание провайдера — лёгкая операция (без сетевых вызовов / IO).
    • Никаких инфраструктурных флагов в сигнатурах (progress, html_parser и т.п.).
    • Возвращаются доменные интерфейсы (структурная типизация совместима с Protocol).
    """

    def create_collection_provider(self, url: "Url") -> "ICollectionLinksProvider":
        """
        Вернуть провайдера ссылок на товары для коллекции (/collections/...).

        :param url: Доменная сущность Url (НЕ str).
        """
        ...

    def create_product_provider(self, url: "Url") -> "IProductDataProvider":
        """
        Вернуть провайдера данных одного товара.

        :param url: Доменная сущность Url (НЕ str).
        """
        ...

    def create_search_provider(self) -> "IProductSearchProvider":
        """
        (Опционально) Вернуть доменный провайдер поиска товара (по артикулу/наименованию).
        Если в системе поиск не используется — реализация может кинуть NotImplementedError.
        """
        ...