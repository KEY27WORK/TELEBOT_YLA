# 🧾 bot_registrar.py
"""
🧾 Модуль для централізованої реєстрації всіх обробників у застосунку.

- Реєструє команди з модулів "фіч".
- Реєструє глобальні обробники (меню, колбеки, посилання), огортаючи їх
  у декоратор для централізованої обробки помилок.
"""

# 🌐 Зовнішні бібліотеки
from telegram.ext import Application, CallbackQueryHandler, MessageHandler, filters

# 🔠 Системні імпорти
from typing import Callable, Optional
import logging

# 🧩 Внутрішні модулі проєкту
from app.config.setup import constants as const
from app.config.setup.container import Container
from app.shared.utils.logger import LOG_NAME

# ================================
# 🧾 ЛОГЕР МОДУЛЯ
# ================================
logger = logging.getLogger(LOG_NAME)


# ================================
# 🏛️ КЛАС РЕЄСТРАТОРА
# ================================
class BotRegistrar:
    """
    🔌 Реєструє всі обробники (хендлери) в екземплярі `telegram.ext.Application`.
    Використовує DI‑контейнер для доступу до всіх необхідних залежностей.
    """

    def __init__(self, application: Application, container: Container) -> None:
        """
        ⚙️ Ініціалізація з додатком та контейнером залежностей.
        """
        self.app = application
        self.container = container
        # 🛡️ Централізований декоратор помилок (callable(handler) -> wrapped_handler)
        self.error_handler: Callable = container.error_handler

    # ================================
    # 🔗 ПУБЛІЧНИЙ ІНТЕРФЕЙС
    # ================================
    def register_handlers(self) -> None:
        """
        🔗 Реєструє всі обробники: спочатку з модулів фіч, потім глобальні.
        """
        self._register_features()
        self._register_global_handlers()

    # ================================
    # ✨ РЕЄСТРАЦІЯ ФІЧ
    # ================================
    def _register_features(self) -> None:
        """Реєструє обробники, що інкапсульовані в окремих "фічах"."""
        logger.info("--- Починаю реєстрацію фіч (команд) ---")

        for feature in self.container.features:
            # не всі об'єкти у списку фіч зобов'язані мати register_handlers
            if hasattr(feature, "register_handlers") and callable(feature.register_handlers):
                feature.register_handlers(self.app)
                logger.info("✅ Фіча '%s' успішно зареєстрована.", feature.__class__.__name__)

        logger.info("--- Реєстрація фіч завершена ---")

    # ================================
    # 🤖 РЕЄСТРАЦІЯ ГЛОБАЛЬНИХ ОБРОБНИКІВ
    # ================================
    def _register_global_handlers(self) -> None:
        """Реєструє наскрізні обробники: меню, inline‑кнопки, посилання."""
        logger.info("--- Починаю реєстрацію глобальних обробників ---")

        # 🔀 CallbackQuery — одна точка входу
        cb_handle = self.container.callback_handler.handle
        self.app.add_handler(CallbackQueryHandler(self.error_handler(cb_handle)))
        logger.info("✅ Глобальний обробник Callback-ів зареєстровано.")

        # 📋 Reply‑меню (кнопки головного меню)
        menu_pattern = const.generate_menu_pattern()
        menu_handler = self._resolve_menu_handler()
        if menu_handler is not None:
            self.app.add_handler(
                MessageHandler(filters.TEXT & filters.Regex(menu_pattern), self.error_handler(menu_handler))
            )
            logger.info("✅ Глобальний обробник головного меню зареєстровано.")
        else:
            logger.warning("⚠️ Меню‑фіча не знайдена у контейнері (main_menu_feature / menu_handler). Пропускаю реєстрацію меню.")

        # 🔗 Всі інші текстові повідомлення (URL/пошук)
        link_handle = self.container.link_handler.handle_link
        self.app.add_handler(
            MessageHandler(
                filters.TEXT & ~filters.COMMAND & ~filters.Regex(menu_pattern),
                self.error_handler(link_handle),
            )
        )
        logger.info("✅ Глобальний обробник посилань (LinkHandler) зареєстровано.")
        logger.info("--- Всі глобальні обробники зареєстровано ---")

    # ================================
    # 🧭 ДОПОМІЖНІ
    # ================================
    def _resolve_menu_handler(self) -> Optional[Callable]:
        """
        Повертає метод обробки меню із контейнера з урахуванням різних назв
        (main_menu_feature / menu_handler) для зворотної сумісності.
        """
        # новий стиль
        feature = getattr(self.container, "main_menu_feature", None)
        if feature and hasattr(feature, "handle_menu"):
            return feature.handle_menu

        # legacy‑алиас
        legacy = getattr(self.container, "menu_handler", None)
        if legacy and hasattr(legacy, "handle_menu"):
            return legacy.handle_menu

        return None
