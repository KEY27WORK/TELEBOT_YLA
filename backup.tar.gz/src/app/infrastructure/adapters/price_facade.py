"""
💰 price_facade_adapter.py — адаптер над PriceCalculationHandler,
дающий чистый фасад для получения (price_message, images) без Telegram-зависимостей.
"""

from __future__ import annotations
from typing import List, Tuple, Protocol

from app.domain.products.entities import ProductInfo


# ================================
# 🏛️ Доменный контракт фасада
# ================================
class IPriceMessageFacade(Protocol):
    async def calculate_and_format(self, url: str) -> Tuple[ProductInfo, str, List[str]]:
        """
        Принимает URL товара, возвращает тройку:
          (ProductInfo, price_message:str, images:List[str])
        """
        ...


# ================================
# 🧩 Адаптер
# ================================
class PriceMessageFacade(IPriceMessageFacade):
    def __init__(self, handler) -> None:
        # handler = PriceCalculationHandler
        self._handler = handler

    async def calculate_and_format(self, url: str) -> Tuple[ProductInfo, str, List[str]]:
        """
        Делегирует в приватный метод _calculate_and_format,
        который у тебя уже есть в PriceCalculationHandler.
        """
        return await self._handler._calculate_and_format(url)