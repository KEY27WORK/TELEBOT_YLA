 # 💱 app/domain/currency

Доменно-рівень модуль для роботи з валютами.  
Містить лише **контракти, DTO та винятки** (ніякої інфраструктурної логіки).

---

## 📦 Структура

- `interfaces.py`  
  - `CurrencyCode` — типобезпечний ISO-4217 код валюти  
  - `Money` — DTO для суми в конкретній валюті (на базі `Decimal`)  
  - `CurrencyRateNotFoundError` — доменний виняток при відсутності курсу  
  - `ICurrencyConverter` — 💀 *legacy* API (float, позначено як `@deprecated`)  
  - `IMoneyConverter` — новий основний API (Decimal + Money DTO)  
  - `ICurrencyRatesProvider` — контракт асинхронного провайдера курсів  

---

## 🎯 Призначення

- **Staged rollout** підходу:
  1. Увесь новий код пишеться під `IMoneyConverter` (Decimal API).  
  2. Legacy-місця поступово переводяться зі старого `ICurrencyConverter`.  
  3. Після завершення міграції `ICurrencyConverter` видаляється, а `IMoneyConverter` може бути перейменований у новий дефолтний `ICurrencyConverter`.  

---

## ⚖️ Принципи

- Domain-layer не містить логіки зберігання чи отримання курсів — лише **контракти**.  
- Всі обчислення мають виконуватись на рівні **infrastructure** (наприклад, у `CurrencyConverter` / `CurrencyManager`).  
- DTO (`Money`) завжди використовує `Decimal` для уникнення похибок float.  

---