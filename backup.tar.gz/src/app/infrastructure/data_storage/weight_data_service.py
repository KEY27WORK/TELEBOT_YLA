# ⚖️ app/infrastructure/data_storage/weight_data_service.py
"""
Асинхронний сервіс локального сховища ваг (грами, int) з in-memory кешем і debounced-флашем.

Контракт: реалізує IWeightDataProvider:
    • get_all_weights() -> Dict[str, int]
    • update_weight(keyword: str, weight_g: int) -> None

Особливості:
    • Кеш у пам'яті, що ліниво завантажується з JSON-файлу.
    • Debounced-збереження (один запис на «пачку» апдейтів).
    • Атомічна запис у файл (спочатку .tmp, потім rename).
    • Міграція старих форматів: якщо в JSON були кг/float/str — конвертуємо в грам і int.
"""

from __future__ import annotations

# 🔠 системні імпорти
import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Dict, Optional

import aiofiles

# 🧩 домен/контракти
from app.domain.products.interfaces import IWeightDataProvider
# 🧰 інфраструктура
from app.config.config_service import ConfigService
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


def _to_int_grams(value: object) -> Optional[int]:
    """
    Нормалізує довільне значення у грами (int).

    Допускаємо:
        - int (вважаємо, що це вже грами)
        - float (🛈 трактуємо як КГ і множимо на 1000, якщо value < 50; інакше як уже грами)
        - str  (намагаємось перетворити як int → грами; якщо float-запис — як кг)
    Повертає None, якщо привести не вдалось.
    """
    # int → вважаємо грами
    if isinstance(value, int):
        return value if value >= 0 else None

    # float → якщо < 50.0 — це, швидше за все, кг; інакше — вже грами
    if isinstance(value, float):
        if value < 0:
            return None
        grams = int(round(value * 1000)) if value < 50.0 else int(round(value))
        return grams

    # str → пробуємо int, потім float як кг
    if isinstance(value, str):
        s = value.strip().replace(",", ".")
        # чистий int?
        try:
            iv = int(s)
            return iv if iv >= 0 else None
        except Exception:
            pass
        # float?
        try:
            fv = float(s)
            if fv < 0:
                return None
            grams = int(round(fv * 1000)) if fv < 50.0 else int(round(fv))
            return grams
        except Exception:
            return None

    return None


class WeightDataService(IWeightDataProvider):
    """
    ⚖️ Локальне сховище ваг у грамах. Працює через in-memory кеш і періодично флашить в JSON.

    Конфіг:
        files.weights         -> шлях до файлу (str), дефолт: "weights.json"
        weights.flush_sec     -> debounce-затримка перед записом (float), дефолт: 1.5 сек
        weights.ensure_dir    -> створювати батьківську директорію, якщо її немає (bool), дефолт: True
    """

    def __init__(self, config: ConfigService) -> None:
        # шляхи/настройки
        self._file_path = str(config.get("files.weights", "weights.json"))
        self._flush_sec = float(config.get("weights.flush_sec", 1.5) or 1.5)
        self._ensure_dir = bool(config.get("weights.ensure_dir", True))

        # стан
        self._lock = asyncio.Lock()
        self._cache: Optional[Dict[str, int]] = None
        self._flush_task: Optional[asyncio.Task] = None

        # гарантуємо директорію (за потреби)
        if self._ensure_dir:
            try:
                Path(self._file_path).parent.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                logger.warning("⚠️ Не вдалося створити директорію для %s: %s", self._file_path, e)

        logger.info("⚖️ WeightDataService init (file=%s, flush=%.2fs)", self._file_path, self._flush_sec)

    # ──────────────────────────────────────────────────────────────────────
    # Публічний контракт
    # ──────────────────────────────────────────────────────────────────────
    async def get_all_weights(self) -> Dict[str, int]:
        """
        Повертає копію актуальних ваг у грамах.
        Ліниво завантажує кеш з диску.
        """
        async with self._lock:
            await self._ensure_cache_loaded()
            # повертаємо копію, щоб ззовні не зміняли кеш напряму
            return dict(self._cache or {})

    async def update_weight(self, keyword: str, weight_g: int) -> None:
        """
        Оновлює/встановлює вагу (в грамах) і планує debounced-флаш у файл.
        """
        key = (keyword or "").strip().lower()
        if not key:
            raise ValueError("Порожній ключ ваги (keyword).")
        if not isinstance(weight_g, int) or weight_g < 0:
            raise ValueError("weight_g повинен бути цілим невід'ємним числом (грами).")

        async with self._lock:
            await self._ensure_cache_loaded()
            assert self._cache is not None  # для лінтера

            self._cache[key] = weight_g
            logger.info("♻️ Вага оновлена: %s = %d г", key, weight_g)

            # плануємо відкладений запис
            self._schedule_flush_locked()

    # ──────────────────────────────────────────────────────────────────────
    # Внутрішні методи
    # ──────────────────────────────────────────────────────────────────────
    async def _ensure_cache_loaded(self) -> None:
        if self._cache is not None:
            return

        # читаємо файл, мігруємо дані до грамів
        try:
            async with aiofiles.open(self._file_path, "r", encoding="utf-8") as f:
                content = await f.read()
            raw = json.loads(content) if content else {}
            if not isinstance(raw, dict):
                raise ValueError("Очікувався JSON-об'єкт із вагами.")

            cache: Dict[str, int] = {}
            for k, v in raw.items():
                kg_int = _to_int_grams(v)
                if kg_int is not None:
                    cache[str(k).lower()] = kg_int
            self._cache = cache
            logger.info("📖 Кеш ваг завантажено: %d запис(ів).", len(self._cache))
        except FileNotFoundError:
            logger.info("📄 Файл ваг не знайдено, стартуємо з порожнього кешу.")
            self._cache = {}
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning("⚠️ Некоректний формат файлу ваг (%s). Стартуємо з порожнього кешу.", e)
            self._cache = {}

    def _schedule_flush_locked(self) -> None:
        """
        Планує debounced-флаш. Викликати під self._lock!
        """
        # скасовуємо попередню задачу, якщо ще не стартувала
        if self._flush_task and not self._flush_task.done():
            self._flush_task.cancel()

        self._flush_task = asyncio.create_task(self._delayed_flush())

    async def _delayed_flush(self) -> None:
        try:
            await asyncio.sleep(max(0.0, float(self._flush_sec)))
            async with self._lock:
                await self._flush_now_locked()
        except asyncio.CancelledError:
            # дебаунс: ок, буде новий цикл
            return
        except Exception:
            logger.exception("❌ Помилка під час відкладеного збереження ваг.")

    async def _flush_now_locked(self) -> None:
        """
        Негайний запис у файл. Викликати ТІЛЬКИ під self._lock!
        """
        if self._cache is None:
            return

        # стабільний порядок ключів
        payload_obj = dict(sorted(self._cache.items()))
        payload = json.dumps(payload_obj, indent=2, ensure_ascii=False)

        tmp_path = f"{self._file_path}.tmp"
        try:
            # пишемо у тимчасовий файл
            async with aiofiles.open(tmp_path, "w", encoding="utf-8") as f:
                await f.write(payload)
            # атомічно підміняємо оригінал
            os.replace(tmp_path, self._file_path)
            logger.info("💾 Ваги збережено (%d запис(ів)) → %s", len(payload_obj), self._file_path)
        except Exception:
            logger.exception("❌ Не вдалося зберегти ваги у файл: %s", self._file_path)
            # намагаємось прибрати tmp
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass

    # ──────────────────────────────────────────────────────────────────────
    # Корисне API для життєвого циклу сервісу (не обов'язкове)
    # ──────────────────────────────────────────────────────────────────────
    async def flush(self) -> None:
        """
        Примусовий флаш у файл (без очікування debounce). Безпечно викликати ззовні.
        """
        async with self._lock:
            await self._flush_now_locked()