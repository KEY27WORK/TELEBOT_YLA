"""
Базовый клиент до OpenAI: принимает наш ChatPrompt (DTO), в т.ч. vision-вариант.
"""

from __future__ import annotations

import logging
from typing import Optional, List, cast, Any

import openai
from openai import RateLimitError
from openai.types.chat import ChatCompletionMessageParam

from app.config.config_service import ConfigService
from app.shared.utils.logger import LOG_NAME
from .dto import ChatPrompt, ChatMessage, Role

logger = logging.getLogger(f"{LOG_NAME}.ai")


def _to_openai(messages: List[ChatMessage]) -> List[ChatCompletionMessageParam]:
    """Конвертация нашего DTO → формат OpenAI Chat."""
    out: List[ChatCompletionMessageParam] = []
    for m in messages:
        role_value: str = m.role.value if isinstance(m.role, Role) else str(m.role)
        payload: Any = {"role": role_value, "content": m.content}
        out.append(cast(ChatCompletionMessageParam, payload))
    return out


class OpenAIService:
    """Клиент OpenAI: chat + vision."""

    def __init__(self, config_service: ConfigService) -> None:
        self._cfg = config_service
        api_key = self._cfg.get("openai.api_key")
        if not api_key:
            logger.critical("❌ OPENAI_API_KEY не знайдено")
            raise ValueError("OPENAI_API_KEY is required")
        self._client = openai.AsyncOpenAI(api_key=api_key)
        logger.info("✅ OpenAIService ініціалізовано")

    async def chat_completion(self, prompt: ChatPrompt) -> Optional[str]:
        """Обычный чат: получает ChatPrompt и возвращает текст."""
        try:
            model: str = cast(str, prompt.model or self._cfg.get("openai.model", "gpt-4o-mini"))
            temperature: float = float(getattr(prompt, "temperature", 0.3) or 0.3)
            max_tokens: Optional[int] = prompt.max_tokens

            logger.debug("📤 OpenAI chat (model=%s, temp=%.2f)", model, temperature)

            resp = await self._client.chat.completions.create(
                model=model,
                messages=_to_openai(prompt.messages),
                temperature=temperature,
                max_tokens=max_tokens,
            )
            if not resp.choices:
                logger.error("❌ Відповідь OpenAI без choices")
                return None

            content = resp.choices[0].message.content
            return content.strip() if content else None

        except RateLimitError:
            logger.error("🚦 RateLimitError від OpenAI")
            return None
        except openai.APIError as e:
            logger.error("❌ OpenAI APIError: %s", e, exc_info=True)
            return None

    async def chat_completion_with_vision(self, *, prompt: ChatPrompt, image_base64: str) -> Optional[str]:
        """
        Vision: объединяем текст промпта + картинку.
        Формат messages → content со списком блоков: {"type": "text"|"image_url"}.
        """
        try:
            model: str = cast(str, prompt.model or self._cfg.get("openai.vision_model", "gpt-4o-mini"))
            temperature: float = float(getattr(prompt, "temperature", 0.2) or 0.2)
            max_tokens: Optional[int] = prompt.max_tokens

            # Склеиваем system/assistant как есть, а для user добавляем image_url
            messages: list[ChatCompletionMessageParam] = []
            data_url = f"data:image/png;base64,{image_base64}"

            for m in prompt.messages:
                role_value: str = m.role.value if isinstance(m.role, Role) else str(m.role)

                # Если это user — делаем мультимодальное content
                if role_value == "user":
                    content_blocks = [
                        {"type": "text", "text": str(m.content)},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ]
                    messages.append(cast(ChatCompletionMessageParam, {"role": "user", "content": content_blocks}))
                else:
                    # system/assistant оставляем текстовыми
                    messages.append(cast(ChatCompletionMessageParam, {"role": role_value, "content": str(m.content)}))

            resp = await self._client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            if not resp.choices:
                logger.error("❌ Vision: пустой choices")
                return None

            content = resp.choices[0].message.content
            return content.strip() if content else None

        except RateLimitError:
            logger.error("🚦 Vision: RateLimitError")
            return None
        except openai.APIError as e:
            logger.error("❌ Vision: OpenAI APIError: %s", e, exc_info=True)
            return None
