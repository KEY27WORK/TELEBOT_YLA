# 🚀 TELEBOTYLAUKRAINE

Телеграм-бот для просунутої роботи з **e-commerce**:
парсинг товарів, мульти-регіональна перевірка наявності, розрахунок цін, генерація контенту та інтеграція з OpenAI API.

⸻

## 📌 Основні можливості

✅ **Парсинг товарів та колекцій** — асинхронне отримання даних із сайтів (ціна, фото, вага, наявність).
✅ **Розрахунок цін** — нове математичне ядро у domain/pricing: доставка, комісії, націнка, округлення через UAH.
✅ **Перевірка наявності**  — паралельна перевірка кольорів та розмірів у регіонах (США, ЄС, UK).
✅ **Обробка таблиць розмірів** — OCR-розпізнавання та генерація таблиць у сантиметрах.
✅ **Інтеграція з OpenAI** — переклад, генерація хештегів, музичні рекомендації.
✅ **Playwright + Cloudflare Bypass**  — стабільний парсинг навіть із захистом Cloudflare.

⸻

## 📂 Архітектура та структура проєкту

Проєкт побудований за принципами **Clean Architecture**:
логіка розділена на незалежні шари, що робить код гнучким, тестованим і простим у підтримці.

```bash
📦 TELEBOTYLAUKRAINE
┣ 📂 src
┃  ┗ 📂 app
┃     ┣ 📂 bot                  # 🤖 UI-шар: Telegram-команди та обробники
┃     ┃  ┣ 📂 commands          # 📜 Фічі бота (/start, /help, меню, валюта)
┃     ┃  ┣ 📂 handlers          # 🔗 Обробники: товари, колекції, калькулятор цін, size chart
┃     ┃  ┣ 📂 services          # 🛠️ CallbackRegistry, CustomContext, фабрики даних
┃     ┃  ┣ 📂 ui                # 🖼️ Форматери, messengers, клавіатури, статичні тексти
┃     ┃  ┗ 📜 main.py           # 🚀 Точка входу (запуск бота)
┃     ┣ 📂 config               # ⚙️ Конфігурація та DI
┃     ┃  ┣ 📂 setup             # 📦 Контейнер, реєстратор, константи
┃     ┃  ┣ 📂 yamls             # 📑 YAML-конфіги (регіони, курси, прайсинг, availability, telegram)
┃     ┃  ┣ 📂 providers         # 🚚 Провайдери (delivery.yaml тощо)
┃     ┃  ┣ 📂 features          # 🎵/🖼️ Конфіги фіч (music, image_generation, telegram)
┃     ┃  ┗ 📜 config_service.py # 🔑 Робота з конфігами та .env
┃     ┣ 📂 domain               # 🧠 Ядро бізнес-логіки (чисте)
┃     ┃  ┣ 📂 pricing           # 💰 Новий модуль розрахунку цін (PriceInput → PriceBreakdown)
┃     ┃  ┣ 📂 availability      # 🌍 Логіка перевірки наявності
┃     ┃  ┣ 📂 products          # 📦 ProductInfo + сервіси (WeightResolver)
┃     ┃  ┣ 📂 currency          # 💱 Валюта, Money, IMoneyConverter
┃     ┃  ┣ 📂 delivery          # 🚚 Контракти доставки
┃     ┃  ┣ 📂 music             # 🎵 Контракти музики
┃     ┃  ┗ 📂 ai                # 🤖 Контракти AI (PromptServiceInterface)
┃     ┣ 📂 errors               # 🛡️ Глобальний шар обробки помилок
┃     ┃  ┣ 📜 error_handler.py
┃     ┃  ┣ 📜 exception_handler_service.py
┃     ┃  ┗ 📜 custom_errors.py
┃     ┣ 📂 infrastructure       # 🏗️ Інтеграції та адаптери
┃     ┃  ┣ 📂 ai                # OpenAI, Translator, PromptService
┃     ┃  ┣ 📂 availability      # Manager, Handler, ProcessingService, Cache
┃     ┃  ┣ 📂 content           # HashtagGenerator, GenderClassifier, ProductContentService
┃     ┃  ┣ 📂 currency          # CurrencyManager + LegacyConverter
┃     ┃  ┣ 📂 delivery          # MeestDeliveryService
┃     ┃  ┣ 📂 parsers           # BaseParser, ParserFactory, SearchResolver, CollectionParser
┃     ┃  ┣ 📂 product_processing# ProductProcessingService
┃     ┃  ┣ 📂 size_chart        # OCR, генератори таблиць, SizeChartService
┃     ┃  ┗ 📂 web               # WebDriverService
┃     ┣ 📂 shared               # 🧰 Спільні утиліти й промпти
┃     ┃  ┣ 📂 prompts           # ✍️ Тексти для AI (uk/ocr)
┃     ┃  ┗ 📂 utils             # Logger, URL parser, PromptLoader
┃     ┗ 📂 tests                # 🧪 Тести (в розробці)
┣ 📂 music_cache                # 🎵 Кеш музичних файлів
┣ 📜 .env                       # 🔐 API-ключі та токени
┣ 📜 pyproject.toml             # 📦 Залежності (Poetry)
┗ 📜 README.md                  # 📘 Цей файл

```
⸻

## 🧩 Шари архітектури

🔹 domain — чисте ядро системи: тільки моделі та бізнес-логіка, без зовнішніх залежностей.
🔹 infrastructure — робота із зовнішнім світом: парсери, API, OpenAI, WebDriver, кеш.
🔹 bot — UI шар: Telegram-команди, хендлери, форматери, повідомлення.
🔹 config — DI та налаштування: yaml-файли, сервіси, константи.
🔹 errors — централізований обробник помилок для стабільності бота.
🔹 shared — загальні утиліти та промпти.

⸻

## 🚀 Запуск бота

1️⃣ Встановіть залежності:

poetry install

2️⃣ Створіть .env і вкажіть ключі API:

OPENAI_API_KEY=your-key
TELEGRAM_BOT_TOKEN=your-token

3️⃣ Запустіть бота:

poetry run python app/bot/main.py


⸻

## 🛠 Технології
	•	Python 3.11+
	•	Clean Architecture + Dependency Injection
	•	python-telegram-bot (PTB)
	•	Playwright + BeautifulSoup
	•	OpenAI GPT-4
	•	yt-dlp (музика)

⸻

### 👤 Розробник

Кирилл / @key27
📬 Telegram: t.me/key27

⸻

### 📜 Ліцензія

MIT License