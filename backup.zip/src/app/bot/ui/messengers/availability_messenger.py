# 📬 app/bot/ui/messengers/availability_messenger.py
"""
📬 availability_messenger.py — Відправка звітів про наявність у Telegram.

🔹 Клас `AvailabilityMessenger`:
- Відправляє користувачу заголовок з посиланням на товар
- Відправляє зображення товару (якщо є)
- Виводить публічний звіт і адмінський звіт
"""

# 🌐 Telegram API
from telegram import Update, Message  # type: ignore

# 🔠 Системні імпорти
import logging
from typing import Final

# 🧩 Внутрішні модулі проєкту
from app.infrastructure.availability.availability_processing_service import (
    ProcessedAvailabilityData,
)
from app.shared.utils.logger import LOG_NAME


# ================================
# 📬 МЕСЕНДЖЕР НАЯВНОСТІ
# ================================
logger: Final = logging.getLogger(LOG_NAME)												# 🧾 Єдиний логер за ім'ям із конфіга


class AvailabilityMessenger:
    """
    📬 Відповідає за надсилання звітів про наявність у Telegram.
    """

    # ================================
    # 📤 ВІДПРАВКА ПОВІДОМЛЕНЬ
    # ================================
    async def send(self, update: Update, data: ProcessedAvailabilityData) -> None:
        """
        📤 Відправляє фото/заголовок товару, публічний і адмінський звіти.

        Args:
            update (Update): 📬 Оновлення від Telegram (містить message/chat)
            data (ProcessedAvailabilityData): 📦 Оброблені дані (зображення, звіти, URL)
        """
        if update.message is None:														# 🚫 Якщо Update не має message (напр., callback-only)
            return  # 🛑 Нема куди відповідати — безпечний вихід

        message: Message = update.message												# 🔒 Фіксуємо локально тип Message — далі без Optional (прибирає підкреслення Pylance)

        caption = f"<b><a href='{data.header.product_url}'>{data.header.title}</a></b>"	# 🏷️ Клікабельний HTML-заголовок із посиланням на товар

        if data.header.image_url:														# 🖼️ Якщо є прев'ю — спершу надсилаємо фото з підписом
            await message.reply_photo(													# ✉️ Відправляємо фото у цей самий чат
                photo=data.header.image_url,
                caption=caption,
                parse_mode="HTML",
            )
        else:																			# 💬 Фото відсутнє — шлемо лише заголовок
            await message.reply_text(caption, parse_mode="HTML")

        await message.reply_text(														# 📢 Публічний звіт (читабельний для користувача)
            data.reports.public_report,
            parse_mode="HTML",
        )
        await message.reply_text(														# 🔒 Адмінський звіт (детальний технічний)
            data.reports.admin_report,
            parse_mode="HTML",
        )

        logger.info("✅ Надіслано звіти про наявність для: %s", data.header.title)		# 🧾 Аудит-лог для трасування
