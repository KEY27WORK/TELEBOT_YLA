# ✨ app/bot/services/custom_context.py
"""
✨ custom_context.py — Кастомний типобезпечний контекст для Telegram-бота.

🔹 Розширює `CallbackContext`, додаючи власні атрибути з типовою анотацією.
🔹 Використовується хендлерами для зберігання параметрів callback-кнопок.
"""

# 🌐 Зовнішні бібліотеки
from telegram.ext import CallbackContext									# 🤖 Базовий контекст з python-telegram-bot

# 🔠 Системні імпорти
from typing import Dict, Optional, cast								# 🔤 Типи та безпечні перетворення

# 🧩 Внутрішні модулі проєкту
from app.config.setup.constants import CONST							# ⚙️ Статичні ключі для user_data


# ================================
# 🏛️ КАСТОМНИЙ КЛАС КОНТЕКСТУ
# ================================
class CustomContext(CallbackContext):
    """
    🧰 Кастомний контекст, який розширює стандартний для підтримки
    додаткових, типобезпечних атрибутів.

    Має бути встановлений через `context_types` в `ApplicationBuilder`.
    """

    def __init__(self, *args, **kwargs) -> None:
        """⚙️ Ініціалізує батьківський клас та додає нові атрибути."""
        super().__init__(*args, **kwargs)									# 🧬 Передаємо базову ініціалізацію в CallbackContext
        self.callback_params: Dict[str, str] = {}							# 🧷 Місце для параметрів callback-кнопок (типобезпечно)

    # ================================
    # ⚙️ MODE
    # ================================
    @property
    def mode(self) -> Optional[str]:
        """🔎 Типобезпечний getter для поточного режиму роботи бота."""
        return cast(dict, self.user_data).get(CONST.LOGIC.USER_DATA.MODE)		# 🗂️ Дістаємо значення за фіксованим ключем

    @mode.setter
    def mode(self, value: Optional[str]) -> None:
        """✍️ Типобезпечний setter для поточного режиму роботи бота."""
        cast(dict, self.user_data)[CONST.LOGIC.USER_DATA.MODE] = value			# 🧩 Зберігаємо значення у user_data

    # ================================
    # 🌐 URL
    # ================================
    @property
    def url(self) -> Optional[str]:
        """🔎 Типобезпечний getter для URL, що обробляється."""
        return cast(dict, self.user_data).get(CONST.LOGIC.USER_DATA.URL)			# 🌍 Отримуємо поточний URL із user_data

    @url.setter
    def url(self, value: Optional[str]) -> None:
        """✍️ Типобезпечний setter для URL, що обробляється."""
        cast(dict, self.user_data)[CONST.LOGIC.USER_DATA.URL] = value				# 🧩 Зберігаємо URL у user_data
