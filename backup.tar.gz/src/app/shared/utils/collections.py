# app/shared/utils/collections.py
from __future__ import annotations

from typing import Iterable, List, Tuple, TypeVar, Union, Hashable

T = TypeVar("T", bound=Hashable)

def uniq_keep_order(
    seq: Iterable[T],
    *,
    as_tuple: bool = False,
) -> Union[List[T], Tuple[T, ...]]:
    """
    Дедупликация с сохранением порядка.
    - Пустые/ложные элементы отбрасываются (совместимо с текущим кодом).
    - По умолчанию возвращает List[T]; при as_tuple=True — Tuple[T, ...].
    """
    seen: set[T] = set()
    out: List[T] = []
    for x in seq:
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return tuple(out) if as_tuple else out

__all__ = ["uniq_keep_order"]