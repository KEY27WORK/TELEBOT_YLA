from __future__ import annotations
from dataclasses import dataclass
from typing import Generic, TypeVar, Union, Callable

T = TypeVar("T")
E = TypeVar("E")

@dataclass(frozen=True, slots=True)
class Ok(Generic[T]):
    value: T

@dataclass(frozen=True, slots=True)
class Err(Generic[E]):
    error: E

Result = Union[Ok[T], Err[E]]

def is_ok(r: Result[T, E]) -> bool:
    return isinstance(r, Ok)

def is_err(r: Result[T, E]) -> bool:
    return isinstance(r, Err)

def map_ok(r: Result[T, E], fn: Callable[[T], T]) -> Result[T, E]:
    return Ok(fn(r.value)) if isinstance(r, Ok) else r  # type: ignore[attr-defined]