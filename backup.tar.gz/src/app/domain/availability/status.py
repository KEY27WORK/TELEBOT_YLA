# 🧩 app/domain/availability/status.py
"""
🧩 status.py — Перечисление статусов наличия товара.

Зачем Enum?
- В отличие от Optional[bool], None не схлопывается в False (bool(None) == False).
- Типобезопасность и понятная семантика: YES / NO / UNKNOWN.
- Удобные утилиты для конвертаций, сравнения и агрегации статусов.
"""

from __future__ import annotations

from enum import Enum, unique
from typing import Iterable, Optional


@unique
class AvailabilityStatus(str, Enum):
    """Трёхсостояний статус наличия."""
    YES = "yes"          # ✅ В наличии
    NO = "no"            # ❌ Нет в наличии
    UNKNOWN = "unknown"  # ❔ Неизвестно (ошибка/нет данных)

    # ---------- БАЗОВЫЕ УДОБСТВА ----------
    def __str__(self) -> str:  # Для красивого вывода и сериализации
        return self.value

    @property
    def is_available(self) -> bool:
        """True, если статус — YES."""
        return self is AvailabilityStatus.YES

    def emoji(self) -> str:
        """Человеко‑понятная пиктограмма статуса."""
        if self is AvailabilityStatus.YES:
            return "✅"
        if self is AvailabilityStatus.NO:
            return "🚫"
        return "❔"  # UNKNOWN

    def to_bool(self) -> Optional[bool]:
        """
        Конвертирует статус в булево представление:
          YES -> True, NO -> False, UNKNOWN -> None.
        """
        if self is AvailabilityStatus.YES:
            return True
        if self is AvailabilityStatus.NO:
            return False
        return None

    # ---------- КЛАССОВЫЕ УТИЛИТЫ ----------
    @classmethod
    def from_bool(cls, value: Optional[bool]) -> "AvailabilityStatus":
        """True -> YES, False -> NO, None -> UNKNOWN."""
        if value is True:
            return cls.YES
        if value is False:
            return cls.NO
        return cls.UNKNOWN

    @classmethod
    def from_str(cls, value: Optional[str]) -> "AvailabilityStatus":
        """
        Парсинг из строки (безопасно, регистронезависимо).
        Понимает: "yes"/"true"/"1"/"y"/"available", "no"/"false"/"0"/"n"/"unavailable", остальное -> UNKNOWN.
        """
        if value is None:
            return cls.UNKNOWN
        s = value.strip().lower()
        if s in {"yes", "true", "1", "y", "available", "in_stock", "ok"}:
            return cls.YES
        if s in {"no", "false", "0", "n", "unavailable", "out_of_stock"}:
            return cls.NO
        if s in {"unknown", "?", "na", "n/a", "none", ""}:
            return cls.UNKNOWN
        # дефолт — осторожно считаем неизвестным
        return cls.UNKNOWN

    @classmethod
    def merge(cls, a: "AvailabilityStatus", b: "AvailabilityStatus") -> "AvailabilityStatus":
        """
        Объединение двух статусов (приоритеты):
          1) если есть хотя бы один YES → YES
          2) иначе если есть хотя бы один NO → NO
          3) иначе → UNKNOWN
        """
        if a is cls.YES or b is cls.YES:
            return cls.YES
        if a is cls.NO or b is cls.NO:
            return cls.NO
        return cls.UNKNOWN

    @classmethod
    def combine(cls, statuses: Iterable["AvailabilityStatus"]) -> "AvailabilityStatus":
        """
        Агрегирует произвольную последовательность статусов по тем же правилам, что и merge.
        Удобно для сводки по множеству регионов.
        """
        seen_no = False
        for st in statuses:
            if st is cls.YES:
                return cls.YES
            if st is cls.NO:
                seen_no = True
        return cls.NO if seen_no else cls.UNKNOWN

    @classmethod
    def priority(cls, status: "AvailabilityStatus") -> int:
        """
        Числовой приоритет для сортировок/сравнений (меньше — «лучше»):
          YES(0) < NO(1) < UNKNOWN(2)
        """
        if status is cls.YES:
            return 0
        if status is cls.NO:
            return 1
        return 2  # UNKNOWN


# ==============================
# 📦 ПУБЛИЧНЫЙ API МОДУЛЯ
# ==============================
__all__ = ["AvailabilityStatus"]