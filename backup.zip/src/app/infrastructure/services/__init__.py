"""
📦 Пакет services

Экспортирует приложенческий оркестратор:
- ProductProcessingService — собирает все данные для карточки товара
- ProcessedProductData — DTO результата

Зависимости по слоям:
- domain: ProductInfo, ProductPromptDTO
- infrastructure: AvailabilityProcessingService, ProductContentService, ParserFactory
"""
from .product_processing_service import ProductProcessingService, ProcessedProductData

__all__ = ["ProductProcessingService", "ProcessedProductData"]