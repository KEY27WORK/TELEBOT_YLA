# 🔌 infrastructure/adapters

Інфраструктурні адаптери — тонкі прослойки для узгодження інтерфейсів між доменом та інфраструктурою.

---

## 📌 Призначення
- **Вирівнювання API**: коли доменні сервіси очікують одне, а інфраструктурні реалізації повертають інше.  
- **Тестованість**: адаптери легко мокати в unit-тестах.  
- **Принцип DIP**: домен залежить від контрактів, а не від деталей реалізації.

---

## 📂 Вміст

- `hashtag_adapter.py` — обгортка над `IHashtagGenerator`, що перетворює `Set[str]` у єдиний `str`.  
- `price_facade.py` — фасад над існуючим `PriceCalculationHandler`, щоб мати уніфікований метод `calculate_and_format(...)`.  
- `__init__.py` — публічний API пакета (`HashtagGeneratorStringAdapter`, `PriceMessageFacade`, `IPriceMessageFacade`).

---

## 📜 Приклад використання

```python
from app.infrastructure.adapters import HashtagGeneratorStringAdapter
from app.infrastructure.content.hashtag_generator import HashtagGenerator

adapter = HashtagGeneratorStringAdapter(HashtagGenerator(...))
hashtags_str = await adapter.generate(product_info)
```

