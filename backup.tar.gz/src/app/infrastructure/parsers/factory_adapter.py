# app/infrastructure/parsers/factory_adapter.py
from __future__ import annotations

from typing import List, Any, Optional
from urllib.parse import urlparse, urlunparse
import inspect

from app.domain.products.entities import Url, ProductInfo
from app.domain.products.dto import ProductHeaderDTO
from app.domain.products.interfaces import (
    ICollectionLinksProvider,
    IProductDataProvider,
    IProductSearchProvider,
)
from app.infrastructure.parsers.contracts import IParserFactory
from app.infrastructure.parsers.parser_factory import ParserFactory  # реальная фабрика


def _normalize_link(raw: str) -> str:
    """
    Минимальная нормализация ссылки:
      • trim пробелы
      • убираем фрагмент (#…)
      • приводим протокол-агностичные ссылки вида //host/... к https://host/...
      • отбрасываем явные не-HTTP схемы (mailto:, tel:, javascript:, data: и т.п.)
      • убираем завершающий '/' (канонизация)
      • возвращаем пустую строку, если после нормализации ничего не осталось
    """
    if not isinstance(raw, str):
        return ""

    s = raw.strip()
    if not s:
        return ""

    # срезаем фрагмент
    hash_pos = s.find("#")
    if hash_pos != -1:
        s = s[:hash_pos]

    # протокол-агностичная форма -> считаем https безопасным дефолтом
    if s.startswith("//"):
        s = "https:" + s

    lower = s.lower()
    BAD_PREFIXES = ("javascript:", "data:", "vbscript:", "mailto:", "tel:")
    if lower.startswith(BAD_PREFIXES):
        return ""

    try:
        p = urlparse(s)
    except Exception:
        return ""

    # допустим только http/https
    if p.scheme and p.scheme.lower() not in ("http", "https"):
        return ""

    # относительные ссылки отбрасываем здесь же (в доменной Url чаще ждут абсолют)
    if not p.scheme or not p.netloc:
        return ""

    # убираем фрагмент окончательно и собираем назад
    p = p._replace(fragment="")
    s = urlunparse(p).strip()

    # канонизируем хвостовой слеш (кроме корня)
    if s.endswith("/") and len(s) > len(f"{p.scheme}://{p.netloc}/"):
        s = s[:-1]

    return s


class _LinksProviderAdapter(ICollectionLinksProvider):
    """Адаптер поверх реального парсера коллекций. Приводит ссылки к Url и нормализует их."""
    __slots__ = ("_inner",)

    def __init__(self, inner: Any) -> None:
        # inner должен уметь: async get_product_links() -> List[str]
        self._inner = inner

    async def get_product_links(self) -> List[Url]:
        raw_links: List[str] = await self._inner.get_product_links()

        # Нормализация + дедуп
        seen: set[str] = set()
        normalized: List[str] = []
        for href in raw_links or []:
            u = _normalize_link(href)
            if not u:
                continue
            if u in seen:
                continue
            seen.add(u)
            normalized.append(u)

        return [Url(u) for u in normalized]


class _ProductProviderAdapter(IProductDataProvider):
    """
    Адаптер поверх реального парсера товара.
    Гарантирует доменный контракт:
      • url: Url   (атрибут, а НЕ property)
      • async get_product_info() -> ProductInfo
      • async get_header_info()  -> ProductHeaderDTO
    """
    __slots__ = ("_inner", "url")

    url: Url  # важно: это data-attribute, чтобы совпасть с Protocol

    def __init__(self, inner: Any, url: Url) -> None:
        self._inner = inner
        self.url = url

    async def get_product_info(self) -> ProductInfo:
        return await self._inner.get_product_info()

    async def get_header_info(self) -> ProductHeaderDTO:
        """
        Поддерживаем оба варианта:
          • async def get_header_info(...)
          • def get_header_info(...)  # вдруг реализация синхронная
        В случае ошибки — безопасный fallback через полный ProductInfo.
        Гарантируем строгий str для title (без Optional).
        """
        hdr_callable = getattr(self._inner, "get_header_info", None)

        if callable(hdr_callable):
            try:
                result = hdr_callable()
                # если это корутина — дождёмся
                if inspect.iscoroutine(result):
                    result = await result

                # допускаем dict или объект с атрибутами
                raw_title = (
                    result.get("title") if isinstance(result, dict) else getattr(result, "title", None)
                )
                raw_image = (
                    result.get("image_url") if isinstance(result, dict) else getattr(result, "image_url", None)
                )

                # ➜ Жёсткая нормализация типов
                title: str = str(raw_title).strip() if raw_title is not None else "ТОВАР"
                if not title:
                    title = "ТОВАР"

                image_url: Optional[str] = str(raw_image).strip() if raw_image else None
                if image_url == "":
                    image_url = None

                return ProductHeaderDTO(title=title, image_url=image_url, product_url=self.url)
            except Exception:
                # тихо валимся в fallback — лучше вернуть что-то валидное, чем None
                pass

        # Fallback: из полного ProductInfo (если внутренняя реализация кэширует — лишнего запроса не будет)
        info: ProductInfo = await self.get_product_info()

        # здесь тоже жёстко приводим к str
        info_title = getattr(info, "title", None)
        title: str = str(info_title).strip() if info_title is not None else "ТОВАР"
        if not title:
            title = "ТОВАР"

        info_image = getattr(info, "image_url", None)
        image_url: Optional[str] = str(info_image).strip() if info_image else None
        if image_url == "":
            image_url = None

        return ProductHeaderDTO(title=title, image_url=image_url, product_url=self.url)


class ParserFactoryAdapter(IParserFactory):
    """Обёртка над ParserFactory, возвращающая доменные интерфейсы."""
    __slots__ = ("_inner",)

    def __init__(self, inner: ParserFactory) -> None:
        self._inner = inner

    def create_collection_provider(self, url: Url) -> ICollectionLinksProvider:
        parser = self._inner.create_collection_parser(url.value)
        return _LinksProviderAdapter(parser)

    def create_product_provider(self, url: Url) -> IProductDataProvider:
        parser = self._inner.create_product_parser(url.value)
        return _ProductProviderAdapter(parser, url)

    def create_search_provider(self) -> IProductSearchProvider:
        """
        Возвращает доменный провайдер поиска. Внутри — строго созданный ProductSearchResolver.
        """
        return self._inner.create_search_provider()