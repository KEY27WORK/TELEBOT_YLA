# 🧠 app/infrastructure/content/product_header_service.py
"""
Сервіс створення легкого "заголовка" товару (title + головне зображення + url)
без повного циклу парсингу сторінки.
"""
from __future__ import annotations

import logging
from typing import Optional
from dataclasses import dataclass

from app.infrastructure.parsers.parser_factory import ParserFactory
from app.infrastructure.parsers.html_data_extractor import HtmlDataExtractor
from app.shared.utils.url_parser_service import UrlParserService
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


@dataclass(frozen=True)
class ProductHeaderDTO:
    """DTO для базової інформації про товар (заголовок)."""
    title: str
    image_url: Optional[str]
    product_url: str


class ProductHeaderService:
    """
    Стандартизовано будує заголовок товару (назва, фото, URL),
    щоб уникати дублювання логіки в різних частинах застосунку.
    """

    def __init__(self, parser_factory: ParserFactory, url_parser_service: UrlParserService) -> None:
        self.parser_factory = parser_factory
        self.url_parser = url_parser_service

    async def create_header(self, product_path: str, region: str = "us") -> Optional[ProductHeaderDTO]:
        """
        Завантажує лише HTML і витягує title та головне зображення.
        """
        url = self.url_parser.build_product_url(region, product_path)
        if not url:
            logger.error("❌ Не вдалося побудувати URL (region=%s, path=%s)", region, product_path)
            return None

        logger.info("🏷️ Створення заголовка для: %s", url)

        try:
            parser = self.parser_factory.create_product_parser(url, enable_progress=False)

            # TODO: бажано замінити на публічний метод парсера (щоб не чіпати приватні поля).
            await parser._fetch_and_prepare_soup()  # type: ignore[attr-defined]
            if not getattr(parser, "_page_soup", None):  # type: ignore[attr-defined]
                raise ConnectionError("Не вдалося завантажити HTML для заголовка.")

            extractor = HtmlDataExtractor(parser._page_soup)  # type: ignore[attr-defined]
            title = extractor.extract_title()
            image_url = extractor.extract_main_image()

            if not title or "Помилка" in title or "Без назви" in title:
                logger.warning("⚠️ Не вдалося отримати валідний title: %s", url)
                return ProductHeaderDTO(title="🔗 ТОВАР", image_url=None, product_url=url)

            return ProductHeaderDTO(title=title.upper(), image_url=image_url, product_url=url)

        except Exception as e:  # noqa: BLE001
            logger.exception("🔥 Помилка при створенні заголовка (%s): %s", product_path, e)
            return ProductHeaderDTO(title="🔗 ТОВАР", image_url=None, product_url=url)


__all__ = ["ProductHeaderService", "ProductHeaderDTO"]