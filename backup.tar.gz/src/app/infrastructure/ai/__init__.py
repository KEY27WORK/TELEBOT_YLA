# 🤖 app/infrastructure/ai/__init__.py
"""
AI-шар інфраструктури.

Складається з:
- DTO: ChatPrompt / ChatMessage / Role (прості, без залежностей від SDK)
- OpenAIService: тонкий клієнт до OpenAI (приймає ChatPrompt)
- PromptService: адаптер, що будує ChatPrompt із shared PromptService + конфігів
- AITaskService: високорівневі задачі (оцінка ваги, переклад, слогани)

Залежності:
- app.config.config_service.ConfigService (ключі див. README)
- app.shared.utils.prompt_service.PromptService (builder промтів)
"""

from .dto import ChatPrompt, ChatMessage, Role
from .open_ai_serv import OpenAIService
from .prompt_service import PromptService
from .ai_task_service import AITaskService

__all__ = [
    "ChatPrompt",
    "ChatMessage",
    "Role",
    "OpenAIService",
    "PromptService",
    "AITaskService",
]