# 🎨 app/infrastructure/availability/formatter.py
"""
🎨 formatter.py — Сервіс форматування карти наявності товарів.

🔹 Клас `ColorSizeFormatter`:
    • Форматує дані про наявність у публічному та адмінському форматі
    • Витягує перелік регіонів із конфігурації через DI
    • Підставляє прапори для кожного регіону
    • Дає стабільний (детермінований) порядок виводу для тестів/логів
"""

from __future__ import annotations

# 🔠 Стандартні імпорти
from typing import Mapping, Sequence, List

# 🧩 Внутрішні модулі
from app.config.config_service import ConfigService
from app.domain.availability.status import AvailabilityStatus  # ✅ Enum: YES / NO / UNKNOWN


# ================================
# 🎨 КЛАС-ФОРМАТЕР
# ================================
class ColorSizeFormatter:
    """
    🎨 Сервіс форматування кольорів і розмірів для відображення в Telegram.
    """

    # Можна розширити при потребі (наприклад: "jp": "🇯🇵")
    FLAGS = {
        "us": "🇺🇸",
        "eu": "🇪🇺",
        "uk": "🇬🇧",
        "ua": "🇺🇦",
    }

    def __init__(self, config_service: ConfigService):
        """
        ✅ Ініціалізація з ConfigService для отримання списку регіонів.
        Безпечно опрацьовує випадки, коли ключу немає або він None.
        """
        regions_cfg = config_service.get("regions") or {}
        # Збережемо стабільний порядок для звітів
        self.regions: List[str] = sorted(regions_cfg.keys())

    # ================================
    # 🏳️ ПРАПОРИ
    # ================================
    @staticmethod
    def get_flag(region_code: str) -> str:
        """
        🏳️ Повертає emoji‑прапор за кодом країни (ISO Alpha‑2).
        Для невідомих кодів — будує прапор з двох літер або повертає UPPERCASE.
        """
        if not region_code:
            return "🏳️"
        code = region_code.strip().lower()
        if code in ColorSizeFormatter.FLAGS:
            return ColorSizeFormatter.FLAGS[code]
        if len(code) == 2 and code.isalpha():
            return "".join(chr(0x1F1E6 + (ord(ch.upper()) - ord("A"))) for ch in code)
        return code.upper()

    # ================================
    # 🧭 МАППІНГ СТАТУСІВ
    # ================================
    @staticmethod
    def human_flag(status: AvailabilityStatus) -> str:
        """
        Перетворює статус у зрозумілий символ.
        YES → ✅, NO → 🚫, UNKNOWN → ❔
        """
        if status is AvailabilityStatus.YES:
            return "✅"
        if status is AvailabilityStatus.NO:
            return "🚫"
        return "❔"  # UNKNOWN

    # ================================
    # 📢 ПУБЛІЧНИЙ ЗВІТ
    # ================================
    @staticmethod
    def format_public_report(
        merged_stock: Mapping[str, Mapping[str, AvailabilityStatus]]
    ) -> str:
        """
        📋 Форматує зведену карту наявності для публічного звіту.

        Args:
            merged_stock: {'Black': {'S': AvailabilityStatus.YES, 'M': AvailabilityStatus.NO, ...}}

        Returns:
            str: Готовий текст для Telegram.
        """
        # Детермінується порядок: спочатку кольори за алфавітом, потім розміри за алфавітом
        colors_sorted = sorted(merged_stock.keys(), key=lambda s: s.upper())
        result_lines: List[str] = []

        for color in colors_sorted:
            sizes_map = merged_stock.get(color, {})
            # Натуральне сортування тут не робимо — домен уже подав упорядковано;
            # але якщо дикт — то для стабільності відсортуємо ключі лексикографічно.
            size_keys = sorted(sizes_map.keys(), key=lambda s: s.upper())

            yes_sizes = [sz for sz in size_keys if sizes_map.get(sz) is AvailabilityStatus.YES]
            any_unknown = any(sizes_map.get(sz) is AvailabilityStatus.UNKNOWN for sz in size_keys)

            if yes_sizes:
                result_lines.append(f"• {color}: {', '.join(yes_sizes)}")
            else:
                # Немає жодного YES: показуємо ❔ якщо є UNKNOWN, інакше 🚫
                result_lines.append(f"• {color}: {'❔' if any_unknown else '🚫'}")

        return "\n".join(result_lines)

    # ================================
    # 🛠 АДМІНСЬКИЙ ЗВІТ
    # ================================
    def format_admin_report(
        self,
        availability: Mapping[str, Mapping[str, Sequence[str]]],
        all_sizes_map: Mapping[str, Sequence[str]],
    ) -> str:
        """
        🦾 Форматує детальну карту наявності для адмінів по регіонах.

        Args:
            availability: {'Black': {'us': ['M', 'L'], 'eu': ['S']}} — розміри, що доступні (YES) в кожному регіоні.
            all_sizes_map: {'Black': ['S', 'M', 'L']} — повний перелік відомих розмірів по кольору (для рядків).

        Returns:
            str: Деталізований текст для внутрішнього використання.
        """
        # Стабільний порядок: регіони по алфавіту + 'ua' наприкінці як локальний
        regions_with_ua = sorted(self.regions) + (["ua"] if "ua" not in self.regions else [])
        lines: List[str] = []

        # Стабільний порядок кольорів
        for color in sorted(all_sizes_map.keys(), key=lambda s: s.upper()):
            all_sizes = list(all_sizes_map.get(color, []))
            # Якщо домен подав уже відсортовано — просто використаємо; інакше забезпечимо стабільність
            if all_sizes != sorted(all_sizes, key=lambda s: s.upper()):
                all_sizes = sorted(all_sizes, key=lambda s: s.upper())

            lines.append(f"• {color}")
            for size in all_sizes:
                parts = [f"{size}:"]
                for region in regions_with_ua:
                    # В адмінському звіті позначаємо лише факт доступності (YES) у регіоні.
                    has_size = size in (availability.get(color, {}).get(region, []) or [])
                    parts.append(f"{self.get_flag(region)} - {'✅' if has_size else '🚫'}")
                lines.append(" ".join(parts) + ";")
            lines.append("")  # відступ між кольорами

        return "\n".join(lines)

    # ================================
    # 🔁 ЗВОРОТНА СУМІСНІСТЬ
    # ================================
    @property
    def format_color_size_availability(self):
        """
        Старий аліас — лишаємо для зворотної сумісності зовнішніх викликів.
        """
        return self.format_public_report


__all__ = ["ColorSizeFormatter"]