# ⚙️ app/config/__init__.py
"""
⚙️ Пакет Config — централізована конфігурація та ініціалізація застосунку.

Цей пакет відповідає за:
- Завантаження та управління всіма налаштуваннями (.env, *.yaml з підпапок config/yamls).
- Створення та зв'язування всіх сервісів через DI‑контейнер.
- Реєстрацію обробників Telegram.
"""

# ================================
# 🧩 ПУБЛІЧНИЙ API ПАКЕТУ
# ================================
from .config_service import ConfigService
from .setup.bot_registrar import BotRegistrar
from .setup.constants import CONST, AppConstants, generate_menu_pattern
from .setup.container import Container

# ================================
# 📤 EXPORT
# ================================

__all__ = [
    "AppConstants",
    "BotRegistrar",
    "ConfigService",
    "CONST",
    "Container",
    "generate_menu_pattern",
]
