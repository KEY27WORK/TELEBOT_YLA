# 🧩 app/domain/pricing/interfaces.py
"""
Контракты и DTO для расчёта цены (Decimal‑only, без I/O).

Что внутри:
  • Строгие денежные типы на базе Decimal (никаких float).
  • Два входа/выхода под разные сценарии:
      1) PriceInput → PriceBreakdown  (универсальная квота; build_quote)
      2) PricingContext + Money → FullPriceDetails  (расширенный отчёт; calculate_full_price)
  • Два протокола сервиса:
      — IPriceService  — современный и минималистичный (build_quote)
      — IPricingService — совместимость со старым кодом (calculate_full_price)

Зависимости:
  • Валютные операции выполняются реализацией IMoneyConverter (контракт домена currency).
"""

from __future__ import annotations

# 🔠 Стандартные импорты
from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol, runtime_checkable

# 💱 Доменный контракт конвертера валют (точная работа с Decimal/Money)
# Если у вас иной путь — поправьте импорт.
from app.domain.currency.interfaces import IMoneyConverter


# ================================
# 💵 БАЗОВЫЕ ТИПЫ
# ================================
CurrencyCode = str


@dataclass(frozen=True, slots=True)
class Money:
    """
    Денежная сумма с кодом валюты (ISO‑4217).

    Пример:
        Money(Decimal("12.34"), "USD")
    """
    amount: Decimal
    currency: CurrencyCode


# ================================
# 🧾 ВАРИАНТ А: УНИВЕРСАЛЬНЫЙ ВХОД/ВЫХОД (build_quote)
# ================================
@dataclass(frozen=True, slots=True)
class PriceInput:
    """
    Универсальные входные данные для построения квоты.
    Все суммы и вес должны быть нормализованы уровнем выше.
    """
    base_price: Money               # цена товара у поставщика
    weight_kg: Decimal              # вес (кг)
    supplier_region: str            # код региона поставщика (us/eu/uk...), если логика его учитывает
    target_currency: CurrencyCode   # желаемая валюта результата (UAH/USD/...)


@dataclass(frozen=True, slots=True)
class PriceBreakdown:
    """
    Итоговая разбивка цены. Все Money — уже в target_currency.
    """
    base_converted: Money           # сконвертированная базовая цена
    shipping: Money                 # доставка (локальная+международная — как решит домен)
    commission: Money               # комиссии (эквайринг/сервис и пр.)
    discount: Money                 # скидка (если нет — 0)
    total_before_round: Money       # сумма до финального округления
    total: Money                    # финальная цена (после округления)


@runtime_checkable
class IPriceService(Protocol):
    """
    Современный минималистичный контракт сервиса прайсинга.
    """
    def build_quote(self, data: PriceInput) -> PriceBreakdown:
        """Детерминированно рассчитать финальную цену и вернуть разбивку."""
        ...


# ================================
# 🧾 ВАРИАНТ B: РАСШИРЕННЫЙ КОНТЕКСТ (calculate_full_price)
# ================================
@dataclass(frozen=True, slots=True)
class PricingContext:
    """
    Региональные параметры, влияющие на расчёт цены.

    Примечание:
      Валюта каждого Money может быть своей (напр., локальная доставка в UAH,
      комиссия в USD) — реализация сервиса нормализует значения через конвертер.
    """
    local_delivery_cost: Money   # 🚚 Локальная доставка (например, UAH)
    ai_commission: Money         # 🤖 Сервисный сбор/комиссия (абсолют)
    phone_number_cost: Money     # 📞 Доп. сервисная стоимость (абсолют)
    country_code: str            # 🌍 Код страны (например, "UA")


@dataclass(frozen=True, slots=True)
class FullPriceDetails:
    """
    Полный отчёт о расчёте цены.

    Рекомендация:
      Для консистентности договоритесь о единой target‑валюте (например, "USD")
      в реализации сервиса и формируйте все Money в ней.
    """
    sale_price: Money            # 🛒 Рекомендованная финальная цена
    sale_price_rounded: Money    # 🪙 Округлённая финальная цена
    cost_price: Money            # 🧮 Полная себестоимость
    profit: Money                # 💚 Прибыль (до округления)
    profit_rounded: Money        # 💚🪙 Прибыль после округления
    full_delivery: Money         # ✈️ Полная доставка (локальная + международная)
    protection: Money            # 🛡️ Страхование/защита
    markup: Decimal              # 📈 Наценка, %
    markup_adjustment: Decimal   # 🔧 Дельта к базовой наценке, %
    weight_lbs: Decimal          # ⚖️ Вес (lbs)
    round_delta_uah: Decimal     # 🇺🇦 Дельта округления в гривне (для UI/отчётов)


@runtime_checkable
class IPricingService(Protocol):
    """
    Совместимость со старым контрактом прайсинга.
    ⚠️ Помечен как legacy: для нового кода используйте IPriceService.
    """
    def calculate_full_price(
        self,
        price: Money,
        weight_lbs: Decimal,
        context: PricingContext,
        converter: IMoneyConverter,
    ) -> FullPriceDetails:
        """Рассчитать полную цену и вернуть детальный отчёт."""
        ...


# ================================
# 🔓 ПУБЛИЧНЫЙ API МОДУЛЯ
# ================================
__all__ = [
    # базовые типы
    "Money",
    # вариант A
    "PriceInput",
    "PriceBreakdown",
    "IPriceService",
    # вариант B (legacy‑совместимость)
    "PricingContext",
    "FullPriceDetails",
    "IPricingService",
]