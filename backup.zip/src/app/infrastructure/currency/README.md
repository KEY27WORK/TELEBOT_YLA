# 💱 Infrastructure / Currency

Готовий Decimal-first стек для конвертації валют та керування «снімком» курсів.

## Файли

- `currency_converter.py` — чистий синхронний конвертер:
  - `IMoneyConverter` (Decimal API — точний)
  - `ICurrencyConverter` (legacy float API — для зворотної сумісності)

- `currency_manager.py` — асинхронний менеджер курсів:
  - Тягне дані з API (Monobank), додає маржу, кешує у файлі.
  - Видає snapshot-конвертери через `get_money_converter()` та `get_converter()`.

- `current_rate.txt` — кеш курсів у JSON. Значення зберігаються як рядки, напр.:
  ```json
  {
    "USD": "42.6900",
    "EUR": "49.9900",
    "GBP": "58.0400",
    "PLN": "12.1500",
    "UAH": "1.0000"
  }

## Typical usage

```python
from app.infrastructure.currency import CurrencyManager

rates = CurrencyManager(config).get_money_converter()  # точний Decimal API
```

## Налаштування (config)

Очікувані ключі:
	•	currency_api.url — endpoint Monobank
	•	currency_api.codes — map назва→ISO-код A (A/UAH)
	•	currency_api.margin — Decimal/float/int/str, додається до курсу
	•	currency_api.timeout_sec, retry_attempts, retry_delay_sec, ttl_sec
	•	currency_api.fallback_rates — dict для cold-start
	•	files.currency_rates — шлях до current_rate.txt

---

# app/infrastructure/currency/current_rate.txt
```json
{
  "USD": "42.6900",
  "EUR": "49.9900",
  "GBP": "58.0400",
  "PLN": "12.1500",
  "UAH": "1.0000"
}
```