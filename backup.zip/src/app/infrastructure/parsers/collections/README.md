# 📦 Parsers · `collections/`

Парсери сторінок **колекцій** (`/collections/...`) для збирання усіх товарних URL.

## Ключовий клас: `UniversalCollectionParser`
- JSON‑LD (ItemList/CollectionPage/SearchResultsPage) → DOM‑fallback.
- Абсолютні `/products/...` лінки без query/fragment, унікалізація з порядком.
- Опційна пагінація з лімітом сторінок.

## Контракти
**Вхід:** `url: str`, `WebDriverService`, `UrlParserService`, `ConfigService` (опц.).  
**Вихід:** `list[str]` — абсолютні `/products/...` URL.

## Примітка
Це **INFRA‑шар**. Для домену використовуйте адаптер `ParserFactoryAdapter`.