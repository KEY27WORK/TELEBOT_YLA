# 📦 app/domain/availability/services.py
"""
📦 services.py — Чистий доменний сервіс для логіки перевірки наявності товару.

🔹 Обов'язки:
- Агрегація даних про наявність з різних регіонів.
- Групування за кольорами та регіонами, побудова карти всіх розмірів.
- Формування структурованого DTO-звіту (`AvailabilityReport`).

❗ Примітка:
Модуль **не** виконує мережевих запитів і не працює з кешем/файлами — лише чисті перетворення
переданих структур даних (без побічних ефектів).
"""

from __future__ import annotations

# 🔠 Стандартні імпорти
from collections import defaultdict
from typing import DefaultDict, Dict, List, Mapping, Set, Tuple

# 🧩 Доменні типи/DTO
from .interfaces import (
    IAvailabilityService,
    RegionStock,
    AvailabilityReport,
    Color,
    Size,
    RegionCode,
)
from .status import AvailabilityStatus  # Enum: YES / NO / UNKNOWN
from .sorting_strategies import default_size_sort_key, SizeKey


def _norm_key(value: str) -> str:
    """Проста нормалізація ключів (зрізаємо пробіли)."""
    return (value or "").strip()


class AvailabilityService(IAvailabilityService):
    """💧 Чисті операції з даними про наявність (без I/O, лише трансформації)."""

    # ---------- Публічний інтерфейс ----------
    def create_report(
        self,
        all_regions_data: List[RegionStock],
        *,
        size_key: SizeKey = default_size_sort_key,  # ключ сортування інʼєктується
    ) -> AvailabilityReport:
        """
        Приймає сирі дані по всіх регіонах і повертає структурований звіт.

        Args:
            all_regions_data: Список структур `RegionStock` з даними про наявність.
            size_key: Ключ сортування розмірів (стратегія). За замовчуванням — універсальна.

        Returns:
            AvailabilityReport: Агрегований звіт для UI/подальшої обробки.
        """
        # 1) Групування для адмін-перегляду + карта всіх відомих розмірів
        availability_by_region, all_sizes_map = self._group_data(all_regions_data, size_key)  # 🧭

        # 2) Зведена карта наявності (трьохстанова логіка по всіх регіонах)
        merged_stock = self._merge_stock(all_regions_data, size_key)  # 🧮

        # 3) Повертаємо DTO
        return AvailabilityReport(
            availability_by_region=availability_by_region,  # 🗺️ {color: {region: [sizes...]}}
            all_sizes_map=all_sizes_map,                    # 🧾 {color: [all_known_sizes...]}
            merged_stock=merged_stock,                      # 🧩 {color: {size: AvailabilityStatus}}
        )

    # ---------- Внутрішні методи ----------
    def _group_data(
        self,
        all_regions_data: List[RegionStock],
        size_key: SizeKey,
    ) -> Tuple[Dict[Color, Dict[RegionCode, List[Size]]], Dict[Color, List[Size]]]:
        """
        Будує:
          • `grouped`: {color: {region_code: [sizes_available_sorted_unique...]}}
          • `all_sizes_map`: {color: [all_known_sizes_sorted...]}

        Стабільність порядку: спершу збираємо у множини, потім сортуємо size_key.
        """
        grouped_sets: DefaultDict[Color, DefaultDict[RegionCode, Set[Size]]] = defaultdict(lambda: defaultdict(set))
        sizes_acc: DefaultDict[Color, Set[Size]] = defaultdict(set)

        for region_data in all_regions_data:
            region: RegionCode = _norm_key(region_data.region_code)
            stock: Mapping[Color, Mapping[Size, AvailabilityStatus]] = region_data.stock_data or {}

            for color_raw, sizes in stock.items():
                color = _norm_key(color_raw)
                if not color:
                    continue

                for size_raw, status in (sizes or {}).items():
                    size = _norm_key(size_raw)
                    if not size:
                        continue

                    # 1) Карта всіх відомих розмірів по кольору (навіть якщо UNKNOWN/NO)
                    sizes_acc[color].add(size)

                    # 2) До per-region списку включаємо ТІЛЬКИ ті, що дійсно доступні в регіоні
                    if status is AvailabilityStatus.YES:
                        grouped_sets[color][region].add(size)

        # Сортування
        grouped: Dict[Color, Dict[RegionCode, List[Size]]] = {}
        for color, regions in grouped_sets.items():
            grouped[color] = {}
            for region_code, size_set in regions.items():
                grouped[color][region_code] = sorted(size_set, key=size_key)

        all_sizes_map: Dict[Color, List[Size]] = {
            color: sorted(size_set, key=size_key) for color, size_set in sizes_acc.items()
        }
        return grouped, all_sizes_map

    def _merge_stock(
        self,
        all_regions_data: List[RegionStock],
        size_key: SizeKey,
    ) -> Dict[Color, Dict[Size, AvailabilityStatus]]:
        """
        Створює єдину тристанову карту наявності:
        Правило для кожного (color, size) по всіх регіонах:
          • Якщо є хоча б один YES → YES
          • Інакше, якщо є хоча б один NO (і не було YES) → NO
          • Інакше → UNKNOWN
        """
        merged: Dict[Color, Dict[Size, AvailabilityStatus]] = {}

        for region_data in all_regions_data:
            stock: Mapping[Color, Mapping[Size, AvailabilityStatus]] = region_data.stock_data or {}

            for color_raw, sizes in stock.items():
                color = _norm_key(color_raw)
                if not color:
                    continue

                dst = merged.setdefault(color, {})
                for size_raw, status in (sizes or {}).items():
                    size = _norm_key(size_raw)
                    if not size:
                        continue

                    prev = dst.get(size)

                    if prev is None:
                        # перша зустріч — просто покладемо як є
                        dst[size] = status
                        continue

                    # агрегуємо за правилом пріоритетів
                    if prev is AvailabilityStatus.YES or status is AvailabilityStatus.YES:
                        dst[size] = AvailabilityStatus.YES
                    elif prev is AvailabilityStatus.NO or status is AvailabilityStatus.NO:
                        # YES уже відсутній (вище оброблено), тому NO має пріоритет над UNKNOWN
                        dst[size] = AvailabilityStatus.NO
                    else:
                        dst[size] = AvailabilityStatus.UNKNOWN

        # Детерміноване впорядкування розмірів усередині кожного кольору
        for color in list(merged.keys()):
            items = merged[color].items()  # Iterable[Tuple[str, AvailabilityStatus]]
            merged[color] = {k: v for k, v in sorted(items, key=lambda kv: size_key(kv[0]))}

        return merged