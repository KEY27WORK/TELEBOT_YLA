"""
🌍 i18n.py — крошечный словарик сообщений для Availability‑флоу.
"""

from __future__ import annotations

MESSAGES = {
    "uk": {
        "empty_url": "⚠️ Посилання порожнє. Надішли коректний URL товару.",
        "process_failed": "⚠️ Не вдалося обробити посилання на товар.",
        "send_failed": "❌ Сталася помилка під час відправки результату. Спробуй ще раз пізніше.",
    },
    "ru": {
        "empty_url": "⚠️ Ссылка пуста. Пришли корректный URL товара.",
        "process_failed": "⚠️ Не удалось обработать ссылку на товар.",
        "send_failed": "❌ Ошибка при отправке результата. Попробуй позже.",
    },
    "en": {
        "empty_url": "⚠️ URL is empty. Please send a valid product link.",
        "process_failed": "⚠️ Failed to process the product link.",
        "send_failed": "❌ An error occurred while sending the result. Please try again later.",
    },
}

_SUPPORTED = set(MESSAGES.keys())


def t(key: str, lang: str = "uk") -> str:
    """Возвращает локализованное сообщение по ключу, fallback → uk."""
    pack = MESSAGES.get(lang if lang in _SUPPORTED else "uk", MESSAGES["uk"])
    return pack.get(key, key)


def normalize_lang(code: str | None, default: str = "uk") -> str:
    """
    Превращает «сырое» language_code из Telegram в наш короткий код.
    Поддерживаем: uk/ru/en. Остальное — fallback на default.
    """
    if not code:
        return default
    short = code.strip().lower()[:2]
    return short if short in _SUPPORTED else default


__all__ = ["t", "normalize_lang"]