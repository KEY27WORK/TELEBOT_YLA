# app/domain/availability/__init__.py

"""
Domain package: availability

Публічний API зручного імпорту для зовнішніх шарів (infrastructure/ui/tests):

    from app.domain.availability import (
        AvailabilityStatus,
        RegionStock,
        AvailabilityReport,
        IAvailabilityService,
        AvailabilityService,
        SizeKey,
        default_size_sort_key,
    )
"""

from .status import AvailabilityStatus
from .interfaces import (
    RegionStock,
    AvailabilityReport,
    IAvailabilityService,
)
from .services import AvailabilityService, SizeKey
from .sorting_strategies import default_size_sort_key

__all__ = [
    # Enum
    "AvailabilityStatus",
    # DTO & contract
    "RegionStock",
    "AvailabilityReport",
    "IAvailabilityService",
    # Service
    "AvailabilityService",
    # Sorting
    "SizeKey",
    "default_size_sort_key",
]