# 💱 app/bot/commands/currency_feature.py
"""
💱 currency_feature.py — Фіча для команд, пов'язаних із валютами.

🔹 Інкапсулює логіку для команд `/rate`, `/set_rate` та відповідних inline-кнопок.
🔹 Реєструє власні обробники команд і callback'ів через спільний реєстр.
"""

# 🔠 Системні імпорти
import logging													# 🧾 Логування подій фічі
import re														# 🔤 Регулярні вирази для парсингу вводу
from decimal import Decimal, InvalidOperation						# 💰 Точна робота з грошима
from typing import Dict, Optional, Tuple							# 🧰 Типізація для чіткого контракту

# 🌐 Зовнішні бібліотеки
from telegram import Update										# ✉️ Подія від Telegram
from telegram.ext import Application, CommandHandler				# 🤖 Реєстрація команд у застосунку

# 🧩 Внутрішні модулі проєкту
from app.bot.commands.base import BaseFeature						# 🏛️ Базовий контракт фічі
from app.bot.services.callback_data_factory import CallbackData		# 🧲 Типи callback-ключів
from app.bot.services.callback_registry import CallbackRegistry		# 📚 Реєстр callback-обробників
from app.bot.services.custom_context import CustomContext				# 🧠 Кастомний контекст оновлень
from app.bot.services.types import CallbackHandlerType				# 🔗 Сигнатура callback-обробника
from app.bot.ui import static_messages as msg						# 📝 Статичні повідомлення інтерфейсу
from app.config.setup.constants import AppConstants					# ⚙️ Константи застосунку
from app.errors.error_handler import make_error_handler				# 🛡️ Обгортка для безпечного виклику
from app.errors.exception_handler_service import ExceptionHandlerService	# 🚑 Сервіс централізованих винятків
from app.infrastructure.currency.currency_manager import CurrencyManager	# 💱 Менеджер курсів валют
from app.shared.utils.logger import LOG_NAME							# 🧾 Ім'я логера застосунку


# ================================
# 🧭 НАЛАШТУВАННЯ ЛОГУВАННЯ
# ================================
logger = logging.getLogger(LOG_NAME)									# 🧾 Виділений логер для цієї фічі


# ================================
# 💼 ОСНОВНИЙ КЛАС ФІЧІ
# ================================
class CurrencyFeature(BaseFeature):
    """
    💱 Інкапсулює логіку перегляду та встановлення курсів валют.
    """

    def __init__(
        self,
        currency_manager: CurrencyManager,
        registry: CallbackRegistry,
        constants: AppConstants,
        exception_handler: ExceptionHandlerService,
    ) -> None:
        self.currency_manager = currency_manager							# 💱 Джерело істини для курсів
        self.registry = registry										# 📚 Реєстрація callback-ів
        self.const = constants										# ⚙️ Константи команд/UI
        self.registry.register(self)									# 🔗 Експонуємо свої callback-и у реєстр

        # 🛡️ Уніфікована обробка помилок для публічних методів
        _eh = make_error_handler(exception_handler)						# 🧰 Фабрика безпечних обгорток
        self.show_current_rate = _eh(self.show_current_rate)				# 🧷 Обгортка для /rate
        self.set_custom_rate = _eh(self.set_custom_rate)					# 🧷 Обгортка для /set_rate
        self.prompt_set_rate = _eh(self.prompt_set_rate)					# 🧷 Обгортка для callback-промпта

    # ================================
    # 🔌 РЕЄСТРАЦІЯ ОБРОБНИКІВ
    # ================================
    def register_handlers(self, application: Application) -> None:
        """Реєструє командні обробники в Telegram Application."""
        cmd = self.const.LOGIC.COMMANDS									# 🧭 Зручно діставати імена команд
        application.add_handler(CommandHandler(cmd.RATE, self.show_current_rate))	# ➕ /rate → показати курси
        application.add_handler(CommandHandler(cmd.SET_RATE, self.set_custom_rate))	# ➕ /set_rate → встановити курс

    def get_callback_handlers(self) -> Dict[CallbackData, CallbackHandlerType]:
        """Повертає карту callback → обробник для реєстру."""
        cb = self.const.CALLBACKS										# 🧭 Простір імен callback-ів
        return {
            cb.CURRENCY_SHOW_RATE: self.show_current_rate,				# 🔘 Кнопка «Показати курси»
            cb.CURRENCY_SET_RATE: self.prompt_set_rate,					# 🔘 Кнопка «Задати курс вручну»
        }

    # ================================
    # 📞 ОБРОБНИКИ КОМАНД/КНОПОК
    # ================================
    async def show_current_rate(self, update: Update, context: CustomContext) -> None:
        """Відображає поточні курси валют з кеш-оновленням за потреби."""
        await self.currency_manager.update_all_rates_if_needed()				# ♻️ Оновлюємо кеш, якщо протух
        all_rates = self.currency_manager.get_all_rates()						# 📥 Дістаємо словник код → курс
        logger.info("Показано актуальні курси валют.")							# 🧾 Аналітичний лог

        lines = ["<b>📊 Поточні курси валют:</b>"]								# 🖼️ Шапка повідомлення
        for code, rate in all_rates.items():
            try:
                lines.append(f"{code} → UAH: <b>{Decimal(rate):.2f} грн</b>")		# ✔️ Форматуємо до 2 знаків
            except Exception:
                # На випадок, якщо провайдер повернув нетипове значення
                lines.append(f"{code} → UAH: <b>{rate} грн</b>")				# ⚠️ Без гарантії форматування

        set_rate_cmd = self.const.LOGIC.COMMANDS.SET_RATE						# 🧭 Назва команди /set_rate
        lines.append(f"\n👉 Задати вручну: /{set_rate_cmd} USD 42.50")			# 📝 Підказка для користувача

        await self._safe_reply_or_edit(update, "\n".join(lines))					# ✉️ Відправляємо/редагуємо текст

    async def set_custom_rate(self, update: Update, context: CustomContext) -> None:
        """Встановлює курс для конкретного коду валюти з валідацією введення."""
        if not update.message or not context.args:
            return														# 🚫 Немає аргументів — нічого робити

        parsed = self._parse_rate_arg(" ".join(context.args))					# 🔍 Пробуємо розпарсити "USD 42.5"
        set_rate_cmd = self.const.LOGIC.COMMANDS.SET_RATE						# 🧭 Ім'я команди для підказок

        if not parsed:
            await self._safe_reply_or_edit(
                update,
                msg.CURRENCY_SET_RATE_INVALID_FORMAT.format(command=set_rate_cmd),
            )														# ⚠️ Невірний формат — показати інструкцію
            return

        code, value = parsed													# 🧩 3-літерний код та Decimal-значення
        supported_codes = set(self.currency_manager.get_all_rates().keys())		# ✅ Дозволені коди з менеджера

        if code not in supported_codes:
            await self._safe_reply_or_edit(
                update, msg.CURRENCY_UNKNOWN_CODE.format(code=code)
            )														# 🚫 Невідомий код валюти
            return

        if not (Decimal("1") <= value <= Decimal("500")):
            await self._safe_reply_or_edit(update, msg.CURRENCY_RATE_OUT_OF_RANGE)	# 🚫 Межі адекватності курсу
            return

        await self.currency_manager.set_rate_manually(code, float(value))			# 💾 Зберегти встановлений курс
        if update.effective_user:
            logger.info(
                "User %s встановив курс %s на %s",
                update.effective_user.id,
                code,
                value,
            )														# 🧾 Аудит операції у логах

        await self._safe_reply_or_edit(
            update, f"✅ Курс <b>{code}</b> встановлено на {value:.2f} грн"
        )															# ✉️ Підтвердження користувачу

    async def prompt_set_rate(self, update: Update, context: CustomContext) -> None:
        """Надсилає підказку користувачу, як встановити курс вручну."""
        set_rate_cmd = self.const.LOGIC.COMMANDS.SET_RATE						# 🧭 Назва команди для прикладу
        await self._safe_reply_or_edit(
            update, msg.CURRENCY_SET_RATE_PROMPT.format(command=set_rate_cmd)
        )															# ✉️ Відправити підказку

    # ================================
    # 🧰 ДОПОМІЖНІ МЕТОДИ
    # ================================
    async def _safe_reply_or_edit(self, update: Update, text: str) -> None:
        """Безпечно редагує/відповідає та завжди намагається закрити callback."""
        parse_mode = self.const.UI.DEFAULT_PARSE_MODE						# 🖋️ Рендеринг HTML/Markdown
        cq = getattr(update, "callback_query", None)						# 🔎 Чи є це callback

        if cq:
            try:
                await cq.edit_message_text(text, parse_mode=parse_mode)			# ✏️ Редагуємо існуюче повідомлення
            except Exception:
                logger.exception("edit_message_text failed; fallback to send_message")
                try:
                    if cq.message and cq.message.chat:
                        await cq.message.chat.send_message(text, parse_mode=parse_mode)
                except Exception:
                    logger.exception("fallback send_message failed")
            finally:
                try:
                    await cq.answer()											# ✅ Закриваємо спінер у кнопки
                except Exception:
                    logger.debug("callback_query.answer failed", exc_info=True)	# ℹ️ Не критично, але логнемо
            return

        if update.message:
            try:
                await update.message.reply_text(text, parse_mode=parse_mode)		# ✉️ Відповідь у чат
            except Exception:
                logger.exception("reply_text failed")							# ⚠️ Залогували для подальшої діагностики

    def _parse_rate_arg(self, raw: str) -> Optional[Tuple[str, Decimal]]:
        """Гнучко парсить рядок формату: 'USD 42.5', 'usd=42,5', 'Usd: 42.5'."""
        rate_re = re.compile(r"^\s*([A-Za-z]{3})\s*[:=]?\s*([\d.,]+)\s*$")		# 🔎 Патерн: код + число з комою/крапкою
        match = rate_re.match(raw)
        if match:
            code, num_str = match.groups()										# 🧩 Витягли код та числовий рядок
        else:
            parts = raw.split()
            if len(parts) != 2:
                return None													# 🚫 Непридатний формат
            code, num_str = parts

        code = code.upper().strip()											# 🔤 Нормалізуємо код до верхнього регістру
        num_str = num_str.replace(",", ".")									# 🔁 Підтримка коми як десяткового роздільника

        try:
            value = Decimal(num_str)										# 💰 Конвертуємо у Decimal
        except InvalidOperation:
            return None													# 🚫 Не змогли конвертувати число

        return code, value													# ✅ Успіх: код і значення
