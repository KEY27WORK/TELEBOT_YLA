# 📬 app/bot/commands/core_commands_feature.py
"""
📬 core_commands_feature.py — Фіча з базовими командами бота.

🔹 Реалізує логіку команд `/start` та `/help`
🔹 Реєструє власні обробники команд
🔹 Надає callback‑хендлери для кнопок розділу «Допомога»
"""

# 🌐 Зовнішні бібліотеки
from telegram import Update                             # 📡 Об'єкт вхідного апдейту
from telegram.ext import Application, CommandHandler    # 🧰 Реєстрація команд у застосунку

# 🔠 Системні імпорти
import logging                                          # 🧾 Логування
from typing import Dict                                 # 🧰 Типізація

# 🧩 Внутрішні модулі проєкту
from app.bot.commands.base import BaseFeature                           # 🏛️ Базовий контракт фічі
from app.bot.services.callback_data_factory import CallbackData         # 🧷 Типи callback-даних
from app.bot.services.callback_registry import CallbackRegistry         # 📚 Реєстр callback‑хендлерів
from app.bot.services.custom_context import CustomContext               # 🧠 Розширений контекст
from app.bot.services.types import CallbackHandlerType                  # 🔗 Сигнатура callback‑хендлера
from app.bot.ui.keyboards.keyboards import Keyboard                               # 🎛️ Клавіатури інтерфейсу
from app.bot.ui import static_messages as msg                           # 📝 Статичні тексти інтерфейсу
from app.config.setup.constants import AppConstants                     # ⚙️ Константи застосунку
from app.shared.utils.logger import LOG_NAME                            # 🏷️ Ім'я логера

logger = logging.getLogger(LOG_NAME)                                    # 🧾 Ініціалізація логера


# ================================
# 🏛️ ФІЧА БАЗОВИХ КОМАНД
# ================================
class CoreCommandsFeature(BaseFeature):
    """
    ✨ Інкапсулює `/start`, `/help` та callback‑кнопки «Допомоги».
    """

    # ================================
    # ⚙️ ІНІЦІАЛІЗАЦІЯ
    # ================================
    def __init__(self, registry: CallbackRegistry, constants: AppConstants) -> None:
        """
        ⚙️ Отримує DI‑залежності та реєструє себе в реєстрі callback‑ів.

        Args:
            registry: Реєстр для підписки фічі на callback‑події.
            constants: Об'єкт з константами (команди, callback‑ключі, налаштування UI).
        """
        self.registry = registry													# 🗂️ Зберігаємо реєстр callback‑ів
        self.const = constants														# ⚙️ Зберігаємо константи застосунку
        self.registry.register(self)												# ✅ Реєструємо фічу в загальному реєстрі

    # ================================
    # 🔌 РЕЄСТРАЦІЯ ОБРОБНИКІВ
    # ================================
    def register_handlers(self, application: Application) -> None:
        """
        🔌 Реєструє хендлери команд у застосунку Telegram.
        """
        cmd = self.const.LOGIC.COMMANDS                                             # 🧭 Простір імен для команд
        application.add_handler(CommandHandler(cmd.START, self.start_command))		# ➕ /start
        application.add_handler(CommandHandler(cmd.HELP, self.help_command))			# ➕ /help

    def get_callback_handlers(self) -> Dict[CallbackData, CallbackHandlerType]:
        """
        📚 Повертає мапу callback‑ключів на відповідні корутини‑обробники.
        """
        cb = self.const.CALLBACKS                                                   # 🧭 Простір імен для callback‑ів
        return {
            cb.HELP_SHOW_FAQ: self.show_faq,										# ❓ FAQ
            cb.HELP_SHOW_USAGE: self.show_help_usage,								# 📘 Як користуватись
            cb.HELP_SHOW_SUPPORT: self.show_help_support,							# 🆘 Підтримка
        }

    # ================================
    # ▶️ КОМАНДИ
    # ================================
    async def start_command(self, update: Update, context: CustomContext) -> None:
        """
        ▶️ Відповідь на `/start`: коротке вітання + головне меню.
        """
        user_id = update.effective_user.id if update.effective_user else "unknown"	# 🆔 Ідентифікатор користувача (для логів)
        logger.info("➡️  /start by user=%s", user_id)								# 🧾 Технічний лог

        if update.message:                                                          # 📨 Є об'єкт повідомлення?
            await update.message.reply_text(                                        # 📤 Відправляємо текст
                msg.HELP_WELCOME_SHORT,                                             # 📝 Коротке вітання
                reply_markup=Keyboard.main_menu(),                                  # 🎛️ Клавіатура головного меню
                parse_mode="HTML",                                                  # 🅷 Форматування HTML
            )

    async def help_command(self, update: Update, context: CustomContext) -> None:
        """
        ▶️ Відповідь на `/help`: головна сторінка «Допомоги».
        """
        user_id = update.effective_user.id if update.effective_user else "unknown"	# 🆔 Ідентифікатор користувача (для логів)
        logger.info("ℹ️  /help by user=%s", user_id)								# 🧾 Технічний лог

        if update.message:                                                          # 📨 Є об'єкт повідомлення?
            await update.message.reply_text(                                        # 📤 Відправляємо текст «Допомоги»
                msg.HELP_MAIN_TEXT,                                                 # 📝 Основний контент розділу
                parse_mode="HTML",                                                  # 🅷 Форматування HTML
                reply_markup=Keyboard.help_menu(),                                  # 🎛️ Клавіатура розділу «Допомога»
            )

    # ================================
    # 📞 CALLBACK‑КНОПКИ «ДОПОМОГА»
    # ================================
    async def show_faq(self, update: Update, context: CustomContext) -> None:
        """
        ❓ Показує секцію «FAQ».
        """
        if update.callback_query:                                                   # 🔔 Подія від inline‑кнопки?
            await update.callback_query.edit_message_text(                          # ✏️ Оновлюємо текст повідомлення
                msg.HELP_FAQ_TEXT                                                   # 📝 Контент «FAQ»
            )

    async def show_help_usage(self, update: Update, context: CustomContext) -> None:
        """
        📘 Показує секцію «Як користуватись».
        """
        if update.callback_query:                                                   # 🔔 Подія від inline‑кнопки?
            await update.callback_query.edit_message_text(
                msg.HELP_USAGE_TEXT,                                                # 📝 Інструкція користування
                parse_mode=self.const.UI.DEFAULT_PARSE_MODE,                        # 🅷 Форматування (із констант)
            )

    async def show_help_support(self, update: Update, context: CustomContext) -> None:
        """
        🆘 Показує секцію «Підтримка».
        """
        if update.callback_query:                                                   # 🔔 Подія від inline‑кнопки?
            await update.callback_query.edit_message_text(
                msg.HELP_SUPPORT_TEXT,                                              # 📝 Канали зв'язку з підтримкою
                parse_mode=self.const.UI.DEFAULT_PARSE_MODE,                        # 🅷 Форматування (із констант)
            )
