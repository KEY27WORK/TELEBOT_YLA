# data_storage

Инфраструктурный слой для простых локальных хранилищ (файлы, кеши и т.п.).

## Состав

- `weight_data_service.py` — асинхронный сервис работы с локальной базой весов товара.
  Реализует доменный контракт `IWeightDataProvider`:
  - `get_all_weights() -> Dict[str, int]` — чтение всех весов (в граммах)
  - `update_weight(keyword: str, weight_g: int) -> None` — обновление/добавление записи

## Как это работает

- **Формат хранения:** обычный JSON-файл, путь берётся из конфига `files.weights`
  (fallback: `weights.json`).
- **Валюта веса:** граммы (`int`), без плавающей точки.
- **Производительность:** используется in-memory кеш + `asyncio.Lock` для
  потокобезопасности. Диск пишется пачками — сохраняется **весь** актуальный кеш.
- **Надёжность:** аккуратная обработка `FileNotFoundError`/битого JSON; при проблемах
  сервис стартует с пустым кешем.

## Конфигурация

```yaml
# app/config/yamls/anything.yaml
files:
  weights: "var/data/weights.json"  # путь к файлу с весами
```

## Пример использования

```python
from app.infrastructure.data_storage import WeightDataService
from app.config.config_service import ConfigService

cfg = ConfigService()
weights = WeightDataService(cfg)

# загрузить все веса
all_weights = await weights.get_all_weights()   # -> {"hoodie": 980, "tee": 260, ...}

# обновить/добавить вес
await weights.update_weight("Hoodie", 980)      # ключи нормализуются к lower()
```

## Контракты домена

Сервис следует интерфейсу IWeightDataProvider из app/domain/products/interfaces.py:

```python
class IWeightDataProvider(Protocol):
    async def get_all_weights(self) -> Dict[str, int]: ...
    async def update_weight(self, keyword: str, weight_g: int) -> None: ...
```

## Нотации
	•	Сервис не выполняет IO в __init__, только в методах.
	•	Возможна дальнейшая оптимизация: периодическая фоновая запись на диск по таймеру,
если потребуется уменьшить частоту операций записи.