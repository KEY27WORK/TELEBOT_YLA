# app/infrastructure/web/webdriver_service.py
"""
🧭 Реализация IWebClient поверх Playwright.
— Явные startup()/shutdown()
— Stealth и ретраи против Cloudflare/502/403/429
— Конфигурируемые таймауты и per-call overrides
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional, List, Literal, cast

from playwright.async_api import (
    async_playwright,
    Playwright,
    Browser,
    BrowserContext,
    Page,
    Response,
    Error as PlaywrightError,
)
from playwright_stealth import stealth_async

from app.config.config_service import ConfigService
from app.domain.web.interfaces import IWebClient
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(f"{LOG_NAME}.web")


class WebDriverService(IWebClient):
    """
    Лёгкая обёртка Playwright как «клиента веб-страниц».
    Не светит Playwright наружу — только HTML по URL.
    """

    # ---------------------------
    # Lifecycle / DI
    # ---------------------------
    def __init__(self, config_service: ConfigService) -> None:
        self._cfg = config_service

        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None

        # --- Config (жёстко приводим типы, чтобы избежать Optional) ---
        self._is_headless: bool = bool(self._cfg.get("playwright.headless", True))
        self._retry_attempts: int = self._cfg.get("playwright.retry_attempts", 5, cast=int) or 5
        self._retry_delay_sec: int = self._cfg.get("playwright.retry_delay_sec", 2, cast=int) or 2
        self._user_agent: Optional[str] = self._cfg.get("playwright.user_agent")

        # Таймауты
        self._navigation_timeout_ms: int = self._cfg.get(
            "playwright.navigation_timeout_ms", 30000, cast=int
        ) or 30000
        self._network_idle_wait_ms: int = self._cfg.get(
            "playwright.network_idle_wait_ms", 1500, cast=int
        ) or 1500

        # Stealth можно отключить через конфиг, если нужно дебажить
        self._enable_stealth: bool = bool(self._cfg.get("playwright.enable_stealth", True))

        # Cloudflare-phrases: берём из конфига, нормализуем к lower/strip
        raw_phrases: List[str] = self._cfg.get("playwright.cloudflare_phrases", None) or [
            "Your connection needs to be verified",
            "Please complete the security check",
            "Verifying you are human",
            "Checking your browser before accessing",
        ]
        self._cloudflare_phrases: List[str] = [str(p).strip().lower() for p in raw_phrases if str(p).strip()]

        logger.info(
            "✅ WebDriverService: headless=%s, retry_attempts=%s, nav_timeout_ms=%s",
            self._is_headless,
            self._retry_attempts,
            self._navigation_timeout_ms,
        )

    async def __aenter__(self):
        await self.startup()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.shutdown()

    async def startup(self) -> None:
        """Запускает Playwright и Chromium (idempotent)."""
        if self._browser and self._browser.is_connected():
            return

        if self._playwright is None:
            self._playwright = await async_playwright().start()

        logger.info("🚀 Chromium launch (headless=%s)…", self._is_headless)
        self._browser = await self._playwright.chromium.launch(headless=self._is_headless)
        self._context = await self._browser.new_context(user_agent=self._user_agent)
        logger.info("✅ Playwright готов")

    async def shutdown(self) -> None:
        """Корректно закрывает браузер и сам Playwright."""
        if self._browser:
            await self._browser.close()
            self._browser = None
            self._context = None
            logger.info("🔒 Chromium closed")
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None
            logger.info("🔌 Playwright stopped")

    # ---------------------------
    # Public API (IWebClient)
    # ---------------------------
    async def get_page_content(
        self,
        url: str,
        *,
        wait_until: Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,                                  # e.g. "networkidle" | "domcontentloaded"
        timeout_ms: Optional[int] = None,          # override навигационного таймаута
        retries: Optional[int] = None,             # override количества попыток
        retry_delay_sec: Optional[int] = None,     # override задержки между повторами
        use_stealth: Optional[bool] = None,        # override stealth на вызов
    ) -> Optional[str]:
        """
        Возвращает HTML страницы с устойчивыми ретраями.
        Обрабатывает Cloudflare splash и статусы 502/403/429.

        Параметры можно переопределять per-call, не меняя глобальный конфиг.
        """
        if not url or not url.startswith(("http://", "https://")):
            logger.error("❌ Некорректный URL: %r", url)
            return None

        await self.startup()
        page: Optional[Page] = None

        _wait_until: Literal["commit", "domcontentloaded", "load", "networkidle"] = (
            wait_until or "networkidle"
        )
        _timeout_ms = int(timeout_ms or self._navigation_timeout_ms)
        _retries = int(retries or self._retry_attempts)
        _retry_delay = int(retry_delay_sec or self._retry_delay_sec)
        _stealth = self._enable_stealth if use_stealth is None else bool(use_stealth)

        for attempt in range(1, _retries + 1):
            try:
                if not self._context:
                    raise RuntimeError("BrowserContext not initialized")

                page = await self._context.new_page()
                if _stealth:
                    await stealth_async(page)

                logger.info("🌍 Загрузка (%s/%s): %s", attempt, _retries, url)
                resp: Optional[Response] = await page.goto(url, wait_until=_wait_until, timeout=_timeout_ms)
                # доп. время на дорендер DOM, если нужно
                if self._network_idle_wait_ms > 0:
                    await asyncio.sleep(self._network_idle_wait_ms / 1000)

                # Проверка HTTP статуса
                status = resp.status if resp else None
                if status in (403, 429, 502):
                    logger.warning("⚠️ HTTP %s — retry через %s сек", status, _retry_delay)
                    await asyncio.sleep(_retry_delay)
                    continue

                html = await page.content()

                # Сигналы «не годится» → повтор
                if self._is_blocked_by_cloudflare(html):
                    logger.warning("⚠️ Cloudflare splash → retry через %s сек", _retry_delay)
                    await asyncio.sleep(_retry_delay)
                    continue

                return html

            except PlaywrightError as e:
                logger.warning("❌ PlaywrightError на попытке %s: %s", attempt, e)
                await asyncio.sleep(_retry_delay)

            finally:
                # Всегда аккуратно закрываем вкладку
                if page:
                    try:
                        if not page.is_closed():
                            await page.close()
                    except Exception as close_err:  # noqa: BLE001
                        logger.debug("ℹ️ Ошибка при закрытии вкладки: %s", close_err)

        logger.error("❌ Не удалось получить HTML после %s попыток: %s", _retries, url)
        return None

    # ---------------------------
    # Helpers
    # ---------------------------
    def _is_blocked_by_cloudflare(self, html: str) -> bool:
        if not html:
            return False
        body = html.lower()
        # Быстрые эвристики Cloudflare splash/защиты
        if any(phrase in body for phrase in self._cloudflare_phrases):
            return True
        # Иногда Cloudflare отдаёт минимальный html с title
        if "<title>just a moment...</title>" in body:
            return True
        return False