# 📄 app/infrastructure/availability/report_builder.py
"""
📄 report_builder.py — Генератор форматированных отчётов о наличии.

Задача:
- принять чистые доменные DTO (RegionStock, AvailabilityReport),
- собрать «легенду» по регионам (✅ / ❌ / ❔),
- отдать два текста (публичный и админский) в виде DTO AvailabilityReports.
"""

from __future__ import annotations

# 🔠 Стандартные импорты
import logging
from typing import Iterable, List

# 🧩 Наши модули
from .formatter import ColorSizeFormatter
from .dto import AvailabilityReports
from app.shared.utils.logger import LOG_NAME
 
# ⚠️ ВАЖНО: импортировать DTO из доменного ИНТЕРФЕЙСА, а не из services
from app.domain.availability.interfaces import AvailabilityReport, RegionStock
from app.domain.availability.status import AvailabilityStatus

logger = logging.getLogger(LOG_NAME)


def _region_symbol(statuses: Iterable[AvailabilityStatus]) -> str:
    """
    Вычисляет компактный символ для региона:
      • есть хотя бы один YES → ✅
      • иначе есть хотя бы один NO → ❌
      • иначе (все UNKNOWN/пусто) → ❔
    """
    has_no = False
    for st in statuses:
        if st is AvailabilityStatus.YES:
            return "✅"
        if st is AvailabilityStatus.NO:
            has_no = True
    return "❌" if has_no else "❔"


class AvailabilityReportBuilder:
    """
    📊 Генератор отчётов, работающий с чистыми DTO (`AvailabilityReport`, `RegionStock`).

    Принимает результаты по регионам (RegionStock) и агрегированный доменный отчёт,
    возвращает пару строк для Telegram (публичный и админский) внутри DTO AvailabilityReports.
    """

    def __init__(self, formatter: ColorSizeFormatter) -> None:
        self.formatter = formatter

    def build(
        self,
        region_results: List[RegionStock],
        report_dto: AvailabilityReport,
    ) -> AvailabilityReports:
        """
        Сформировать тексты отчётов.

        Args:
            region_results: список RegionStock (сырые данные по регионам)
            report_dto: агрегированный доменный отчёт (сортировки уже применены)

        Returns:
            AvailabilityReports: {public_report, admin_report}
        """
        # На всякий случай страховка от None
        region_results = region_results or []

        # =========================
        # «Легенда» по регионам 🏳️
        # =========================
        region_lines: List[str] = []
        for region_data in region_results:
            # region_data.stock_data: Dict[color, Dict[size, AvailabilityStatus]]
            statuses_iter = (
                st
                for sizes in (region_data.stock_data or {}).values()
                for st in (sizes or {}).values()
            )
            symbol = _region_symbol(statuses_iter)
            region_lines.append(f"{self.formatter.get_flag(region_data.region_code)} - {symbol}")

        # Бизнес‑правило: локальный 'ua' фиксированно ❌
        region_lines.append(f"{self.formatter.get_flag('ua')} - ❌")
        region_checks = "\n".join(region_lines) if region_lines else f"{self.formatter.get_flag('ua')} - ❌"

        # =========================
        # Тексты отчётов 🧾
        # ВАЖНО: merged_stock содержит AvailabilityStatus, не bool!
        # =========================
        public_format = self.formatter.format_public_report(report_dto.merged_stock)
        admin_format = self.formatter.format_admin_report(
            availability=report_dto.availability_by_region,
            all_sizes_map=report_dto.all_sizes_map,
        )

        logger.info("📝 Сгенерированы отчёты о наличии.")

        # =========================
        # DTO для Telegram 📦
        # =========================
        public_text_header = "🎨 ДОСТУПНІ КОЛЬОРИ ТА РОЗМІРИ"
        admin_text_header = "👨‍🎓 Детально по регіонах"

        return AvailabilityReports(
            public_report=f"{region_checks}\n\n{public_text_header}:\n{public_format}",
            admin_report=f"{admin_text_header}:\n{admin_format}",
        )