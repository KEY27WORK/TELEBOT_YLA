# 📐 app/infrastructure/size_chart/services/table_geometry_service.py
from __future__ import annotations

"""
📐 TableGeometryService — сервіс розрахунку геометрії для адаптивних таблиць розмірів.

Особливості:
- Акуратні тайпінги (Sequence/Mapping) → без конфліктів інваріантності dict у Pylance.
- Безпечна робота з порожніми headers/parameters (жодних ділення на нуль).
- Центральне місце для констант/мінімумів і обмеження масштабування.
- Працює з вашим IFontService та FontType.
"""

from typing import Mapping, Sequence, Dict

from app.domain.image_generation.interfaces import IFontService, FontType


class TableGeometryService:
    """
    Сервіс для обчислення макета адаптивної таблиці (позиції, шрифти, масштаби).
    """

    # ✍️ базові значення (можна тюнити за потреби)
    _MIN_FIRST_COL = 250
    _EXTRA_PARAM_PADDING = 50
    _MIN_COLUMN_WIDTH = 60
    _MIN_SPACING = 10
    _BASE_CELL_HEIGHT = 80
    _BASE_TITLE_PT = 50
    _BASE_PADDING_INSIDE = 20
    _SCALE_MIN = 0.5         # не стискаємо сильніше за 50%
    _SCALE_MAX = 0.85        # не роздуваємо більше ніж на 85% від екрану

    def __init__(self, img_width: int, img_height: int, padding: int) -> None:
        self.img_width = int(img_width)
        self.img_height = int(img_height)
        self.padding = int(padding)

    def calculate_layout(
        self,
        *,
        headers: Sequence[str],
        parameters: Mapping[str, Sequence[object]],
        base_font_size: int,
        font_service: IFontService,
    ) -> Dict[str, int | float]:
        """
        Розраховує геометрію для таблиці «параметр → [розміри...]».

        Args:
            headers: список назв розмірів (S, M, L, ...). Може бути порожнім.
            parameters: мапа {назва_параметра: послідовність значень по кожному розміру}.
            base_font_size: базовий кегль для шрифту параметрів (буде масштабовано).
            font_service: сервіс шрифтів (ваш FontService через IFontService).

        Returns:
            dict з ключами:
                - first_col_width, column_width, column_spacing
                - cell_height, title_font_size, padding_inside
                - scale_factor
        """
        # доступна «рамка» для всього контенту
        max_table_width = self.img_width - 2 * self.padding
        max_table_height = self.img_height - 2 * self.padding

        # ► ширина першої колонки: беремо максимальну ширину тексту параметра + запас
        param_font = font_service.get_font(FontType.BOLD, int(base_font_size))
        if parameters:
            max_param_text_width = max(
                font_service.get_text_width(str(param), param_font) for param in parameters.keys()
            )
        else:
            max_param_text_width = 0

        first_col_width = max(self._MIN_FIRST_COL, max_param_text_width + self._EXTRA_PARAM_PADDING)

        # ► права частина: N колонок під розміри
        num_sizes = max(1, len(headers))          # ніколи не 0 — щоб уникати ділення на нуль
        num_gaps = max(0, num_sizes - 1)

        remaining_width = max(0, max_table_width - first_col_width)

        # спершу пробуємо мінімальний відступ, далі коригуємо
        spacing = self._MIN_SPACING if num_gaps > 0 else 0
        # базова ширина колонки
        column_width = (remaining_width - num_gaps * spacing) // num_sizes if num_sizes > 0 else remaining_width

        # якщо не влазить мінімальна ширина — перераховуємо spacing і фіксуємо column_width на мінімумі
        if column_width < self._MIN_COLUMN_WIDTH:
            column_width = self._MIN_COLUMN_WIDTH
            if num_gaps > 0:
                free_for_gaps = remaining_width - num_sizes * column_width
                spacing = max(0, free_for_gaps // num_gaps)
            else:
                spacing = 0

        # ► базові вертикальні параметри
        cell_height = self._BASE_CELL_HEIGHT
        title_font_size = self._BASE_TITLE_PT
        padding_inside = self._BASE_PADDING_INSIDE

        # фактичний розмір таблиці до масштабування
        actual_width = first_col_width + num_sizes * column_width + num_gaps * spacing
        rows_count = max(1, len(parameters))      # щонайменше один рядок під заголовки параметрів
        actual_height = (rows_count + 1) * cell_height + title_font_size + padding_inside * 3

        # ► масштабування (щоб все помістилось в картинку)
        if actual_width <= 0 or actual_height <= 0:
            scale = 1.0
        else:
            scale = min(
                self._SCALE_MAX,
                max_table_width / actual_width if actual_width > 0 else 1.0,
                max_table_height / actual_height if actual_height > 0 else 1.0,
            )
            scale = max(self._SCALE_MIN, float(scale))

        return {
            "first_col_width": int(first_col_width),
            "column_width": int(column_width),
            "column_spacing": int(spacing),
            "cell_height": int(cell_height * scale),
            "title_font_size": int(title_font_size * scale),
            "scale_factor": float(scale),
            "padding_inside": int(padding_inside),
        }