# 🧠 Модуль: Парсери продуктів

Модуль відповідає за **повну логіку парсингу** сторінок товарів, колекцій і результатів пошуку на сайті YoungLA.

## 🔍 Призначення

- Завантаження HTML-сторінок і витяг структурованих даних (назва, опис, ціна, зображення, наявність тощо).
- Пошук товарів за артикулом або назвою (UI‑пошук).
- Уніфікований інтерфейс для подальшої обробки у верхніх шарах (через `IProductDataProvider`, `ICollectionLinksProvider`).

## 📦 Основні компоненти

### `base_parser.py` — оркестратор
- Повний цикл обробки сторінки товару (fetch → extract → process → validate).
- Делегує витяг даних у `HtmlDataExtractor`.
- Приймає рішення щодо fallback‑логіки (опис, stock, зображення).

### `html_data_extractor.py` — екстрактор даних
- Низькорівнева утиліта, що вміє **витягувати** дані з DOM/JSON‑LD/legacy Shopify.
- **Не містить логіки вибору джерела** — це робить `BaseParser`.

### `parser_factory.py` — фабрика створення
- Створює інстанси парсерів (`BaseParser`, `UniversalCollectionParser`, `ProductSearchResolver`).
- Ін’єктує загальні сервіси (`WebDriverService`, `TranslatorService`, `WeightResolver`, `UrlParserService`, `ConfigService`).
- Використовує єдині інфра‑опції `ParserInfraOptions` (див. `_infra_options.py`).

### `factory_adapter.py` — адаптер фабрики
- Обгортає реальні INFRA‑парсери в **доменні інтерфейси** (`IProductDataProvider`, `ICollectionLinksProvider`).
- Нормалізує лінки і гарантує сумісність зі strict‑typing домену.

### `collections/universal_collection_parser.py`
- Парсить сторінки колекцій (`/collections/...`).
- JSON‑LD → DOM‑fallback → пагінація → унікалізація `/products/...` посилань.

### `product_search/search_resolver.py`
- Реалізує UI‑пошук YoungLA через Playwright.
- Повертає перший/кілька релевантних товарів (`Url`/`SearchResult`).

## 🧱 Архітектура папок


```bash
parsers
├─ collections/
│  ├─ README.md
│  ├─ __init__.py
│  └─ universal_collection_parser.py
├─ product_search/
│  ├─ README.md
│  ├─ __init__.py
│  └─ search_resolver.py
├─ _infra_options.py
├─ base_parser.py
├─ contracts.py
├─ factory_adapter.py
├─ parser_factory.py
├─ __init__.py
└─ README.md  ← (цей файл)
```

## ✅ Принципи

- SOLID, DI: усі сервіси передаються через конструктори.
- Розділення обов’язків: оркестратор (`BaseParser`) vs екстрактор (`HtmlDataExtractor`).
- Мінімум зв’язності між компонентами, чисті контракти для домену.
- Єдині інфраструктурні опції `ParserInfraOptions` (логування, таймаути, HTML‑парсер, ліміти).
- Гнучка інтеграція з Telegram‑ботом через інтерфейси `IProductDataProvider` та `ICollectionLinksProvider`.
