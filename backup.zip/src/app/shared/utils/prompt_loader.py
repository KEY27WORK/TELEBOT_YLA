# ⚙️ app/shared/utils/prompt_loader.py
"""
⚙️ prompt_loader.py — завантажує та кешує текстові шаблони промтів з файлів.

❗ Deprecated:
    Використовуйте `PromptService` з `prompt_service.py`.
    Цей модуль залишено лише для зворотної сумісності.
"""

from __future__ import annotations

# 🔠 Системні імпорти
from enum import Enum
from typing import Final

# 🧩 Внутрішні модулі проєкту
from .prompt_service import PromptService

# ================================
# 🏛️ КОНСТАНТИ
# ================================
_ps: Final[PromptService] = PromptService()   # 🧠 Єдиний інстанс для шиму


# ================================
# 🌀 СТАРІ API (зворотна сумісність)
# ================================
def load_prompt(file_name: str, lang: str = "uk") -> str:
    """
    📜 Завантажує текстовий промт зі старим API.

    Args:
        file_name: Імʼя файлу (очікує "music.txt" тощо).
        lang: Код мови (default: "uk").
    """
    # Старий API міг передавати без `.txt`
    if not file_name.endswith(".txt"):
        file_name += ".txt"

    return _ps._load_lang_text(file_name, lang=lang)  # type: ignore[attr-defined]


def load_ocr_asset(file_name: str) -> str:
    """
    📜 Завантажує OCR-ассет зі старим API.
    """
    return _ps._load_ocr_file(file_name)  # type: ignore[attr-defined]


# ================================
# 📦 ПУБЛІЧНИЙ API МОДУЛЯ
# ================================
__all__ = ["load_prompt", "load_ocr_asset"]