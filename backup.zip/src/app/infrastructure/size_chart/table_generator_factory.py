# 🏭 app/infrastructure/size_chart/table_generator_factory.py
from __future__ import annotations

"""
TableGeneratorFactory — фабрика генераторов PNG-таблиц.

Особенности:
- Строгие и дружелюбные к Pylance типы (Mapping для входных данных, dict внутри).
- Разные дефолты для канвы/отступов под обычные/сеточные таблицы.
- Мягкая валидация входных данных под каждый ChartType (с логами-предупреждениями).
- Возможность локально переопределять canvas_size/padding/background/text_color.
- 🧭 Одна «точка правды» для приоритета типов (CHART_TYPE_PRIORITY), чтобы одинаково сортировать везде.
"""

from typing import Any, Mapping, MutableMapping, Optional, Tuple, Dict, List
import logging

from app.shared.utils.logger import LOG_NAME
from app.shared.utils.prompts import ChartType

from app.infrastructure.image_generation.font_service import FontService
from app.infrastructure.size_chart.generators.base_generator import BaseTableGenerator
from app.infrastructure.size_chart.generators.general_table_generator import GeneralTableGenerator
from app.infrastructure.size_chart.generators.unique_table_generator import UniqueTableGenerator
from app.infrastructure.size_chart.generators.unique_grid_table_generator import UniqueGridTableGenerator

logger = logging.getLogger(f"{LOG_NAME}.factory")

# ─────────────────────────────────────────────────────────────────────
# 🧭 Табличка приоритета типов (единая «точка правды»)
# Используйте это в любом месте проекта, где нужно стабильно сортировать ChartType.
# Пример: sorted(items, key=lambda x: CHART_TYPE_PRIORITY.get(x.type, 999))
# ─────────────────────────────────────────────────────────────────────
CHART_TYPE_PRIORITY: Dict[ChartType, int] = {
    ChartType.UNIQUE: 0,
    ChartType.GENERAL: 1,
    ChartType.UNIQUE_GRID: 2,
}

# Ключи-метаданные, которые не относятся к «данным таблицы»
_META_KEYS = {"Title", "Розмір", "Размер"}


class TableGeneratorFactory:
    """
    Фабрика генераторов с поддержкой параметров канвы и мягкой валидацией входных данных.
    """

    def __init__(
        self,
        font_service: FontService,
        *,
        # дефолты для классических/адаптивных
        default_canvas: Tuple[int, int] = (1080, 1920),
        default_padding: int = 20,
        # дефолты для сеток (обычно широкие)
        grid_canvas: Tuple[int, int] = (1600, 1200),
        grid_padding: int = 50,
    ) -> None:
        self.font_service = font_service
        self.default_canvas = tuple(default_canvas)
        self.default_padding = int(default_padding)
        self.grid_canvas = tuple(grid_canvas)
        self.grid_padding = int(grid_padding)

    # ─────────────────────────────────────────────────────────────────────
    # ПУБЛИЧНЫЙ API
    # ─────────────────────────────────────────────────────────────────────
    def create_generator(
        self,
        *,
        chart_type: ChartType,
        data: Mapping[str, Any],
        path: str,
        canvas_size: Optional[Tuple[int, int]] = None,
        padding: Optional[int] = None,
        background: Optional[str] = None,
        text_color: Optional[str] = None,
    ) -> BaseTableGenerator:
        """
        Создаёт подходящий генератор под тип таблицы.

        Args:
            chart_type: тип таблицы (GENERAL / UNIQUE / UNIQUE_GRID).
            data: исходные данные (OCR/JSON). Mapping выбран специально для дружбы с Pylance.
            path: путь для сохранения PNG.
            canvas_size, padding: переопределят дефолт для соответствующего chart_type.
            background, text_color: опциональные визуальные настройки (пробрасываются в BaseTableGenerator).

        Returns:
            Экземпляр конкретного генератора, готовый к вызову .generate().
        """
        # Преобразуем Mapping -> dict, чтобы наследники свободно модифицировали копию.
        payload: Dict[str, Any] = dict(data or {})

        # Выставляем дефолты канвы/паддинга под тип
        if chart_type == ChartType.UNIQUE_GRID:
            cvs = tuple(canvas_size) if canvas_size else self.grid_canvas
            pad = int(padding) if padding is not None else self.grid_padding
        else:
            cvs = tuple(canvas_size) if canvas_size else self.default_canvas
            pad = int(padding) if padding is not None else self.default_padding

        # Собираем kwargs только из непустых значений, чтобы не перетёреть дефолты
        gkwargs: Dict[str, Any] = {"canvas_size": cvs, "padding": pad}
        if background is not None:
            gkwargs["background"] = background
        if text_color is not None:
            gkwargs["text_color"] = text_color

        # Валидация/подстройка под конкретный chart_type (без разрушающих преобразований)
        if chart_type == ChartType.UNIQUE_GRID:
            self._validate_grid_shape(payload)
            logger.debug("Создаём UniqueGridTableGenerator: path=%s, canvas=%s, padding=%s", path, cvs, pad)
            return UniqueGridTableGenerator(payload, path, self.font_service, **gkwargs)

        if chart_type == ChartType.UNIQUE:
            self._validate_unique_shape(payload)
            logger.debug("Создаём UniqueTableGenerator: path=%s, canvas=%s, padding=%s", path, cvs, pad)
            return UniqueTableGenerator(payload, path, self.font_service, **gkwargs)

        # GENERAL — по умолчанию
        self._validate_general_shape(payload)
        logger.debug("Создаём GeneralTableGenerator: path=%s, canvas=%s, padding=%s", path, cvs, pad)
        return GeneralTableGenerator(payload, path, self.font_service, **gkwargs)

    # ─────────────────────────────────────────────────────────────────────
    # ВНУТРЕННИЕ ВАЛИДАТОРЫ ФОРМАТА ДАННЫХ
    # (логируют, но не ломают выполнение — BaseTableGenerator всё равно
    #  безопасно обрабатывает пограничные случаи)
    # ─────────────────────────────────────────────────────────────────────
    def _validate_general_shape(self, data: MutableMapping[str, Any]) -> None:
        """
        GENERAL: вправо идут колонки-параметры со списками значений.
        Ожидается: { "Title": str|[str], "Розмір": [..], "<param>": [..], ... }
        """
        problems: List[str] = []
        for k, v in data.items():
            if k in _META_KEYS:
                continue
            if not self._is_sequence_like(v):
                problems.append(f"{k!r} -> {type(v).__name__}")
        if problems:
            logger.warning(
                "GENERAL: значения параметров желательно передавать списками. Подозрительные ключи: %s",
                ", ".join(problems),
            )

    def _validate_unique_shape(self, data: MutableMapping[str, Any]) -> None:
        """
        UNIQUE: та же логика, что и GENERAL (параметр -> список по размерам),
        но геометрия рассчитывается адаптивно через TableGeometryService.
        """
        problems: List[str] = []
        for k, v in data.items():
            if k in _META_KEYS:
                continue
            if not self._is_sequence_like(v):
                problems.append(f"{k!r} -> {type(v).__name__}")
        if problems:
            logger.warning(
                "UNIQUE: ожидаются списки значений по размерам. Найдены: %s",
                ", ".join(problems),
            )

    def _validate_grid_shape(self, data: MutableMapping[str, Any]) -> None:
        """
        UNIQUE_GRID: значения — словари (height -> {weight: size}).
        Ожидается: { "Title": ..., "<height>": { "<weight>": "S|M|L", ... }, ... }
        """
        problems: List[str] = []
        for k, v in data.items():
            if k in _META_KEYS:
                continue
            if not isinstance(v, dict):
                problems.append(f"{k!r} -> {type(v).__name__}")
        if problems:
            logger.warning(
                "UNIQUE_GRID: ожидаются словари для каждой строки сетки. Найдены: %s",
                ", ".join(problems),
            )

    @staticmethod
    def _is_sequence_like(value: Any) -> bool:
        """
        Мини-эвристика: «похоже на список значений?»
        Не считаем строку/байты «последовательностью» — это одиночное значение.
        """
        if value is None:
            return False
        if isinstance(value, (str, bytes)):
            return False
        # Нечто итерируемое — сойдёт (list/tuple и аналоги).
        try:
            iter(value)  # type: ignore[arg-type]
            return True
        except Exception:
            return False