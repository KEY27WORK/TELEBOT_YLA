# app/domain/web/interfaces.py
from __future__ import annotations
from typing import Optional, Protocol

class IWebClient(Protocol):
    """
    Узкий контракт «клиента веб-страниц»: получить HTML.
    Реализация (Playwright/httpx и т.п.) скрыта за интерфейсом.
    """

    async def startup(self) -> None:
        """Инициализировать ресурсы (запуск браузера/сессий/пула и т.п.)."""
        ...

    async def shutdown(self) -> None:
        """Освободить ресурсы (закрыть браузер/сессии/пул и т.п.)."""
        ...

    async def get_page_content(self, url: str) -> Optional[str]:
        """Получить финальный HTML страницы."""
        ...