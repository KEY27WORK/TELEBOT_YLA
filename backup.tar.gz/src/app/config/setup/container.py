# 📦 app/config/setup/container.py
"""
📦 Контейнер залежностей (DI).

— Створює сервіси в правильному порядку
— Впроваджує залежності через конструктори
— Дає єдину точку доступу до компонентів
"""

from __future__ import annotations

# ── DOMAIN ─────────────────────────────────────────────────────────────────
from app.domain.availability.services import AvailabilityService
from app.domain.delivery.interfaces import IDeliveryService
from app.domain.pricing import PriceService, PricingRules
from app.domain.products.interfaces import IProductSearchProvider
from app.domain.products.services.weight_resolver import WeightResolver

# ── INFRASTRUCTURE ────────────────────────────────────────────────────────
from app.config.config_service import ConfigService
from app.config.setup.constants import CONST, AppConstants

# AI
from app.infrastructure.ai.open_ai_serv import OpenAIService
from app.infrastructure.ai.prompt_service import PromptService
from app.infrastructure.ai.translator import TranslatorService

# Availability
from app.infrastructure.availability.availability_handler import AvailabilityHandler
from app.infrastructure.availability.availability_manager import AvailabilityManager
from app.infrastructure.availability.availability_processing_service import AvailabilityProcessingService
from app.infrastructure.availability.cache_service import AvailabilityCacheService
from app.infrastructure.availability.formatter import ColorSizeFormatter
from app.infrastructure.availability.report_builder import AvailabilityReportBuilder

# Collections / Parsers
from app.infrastructure.collection_processing.collection_processing_service import CollectionProcessingService
from app.infrastructure.parsers.parser_factory import ParserFactory
from app.infrastructure.parsers.factory_adapter import ParserFactoryAdapter

# Content
from app.infrastructure.content.gender_classifier import GenderClassifier
from app.infrastructure.content.hashtag_generator import HashtagGenerator
from app.infrastructure.content.product_content_service import ProductContentService
from app.infrastructure.content.product_header_service import ProductHeaderService

# Currency / Pricing
from app.infrastructure.currency.currency_manager import CurrencyManager

# Data
from app.infrastructure.data_storage.weight_data_service import WeightDataService

# Delivery
from app.infrastructure.delivery.meest_delivery_service import MeestDeliveryService

# Image generation / OCR / Size chart
from app.infrastructure.image_generation.font_service import FontService
from app.infrastructure.size_chart.image_downloader import ImageDownloader
from app.infrastructure.size_chart.ocr_service import OCRService
from app.infrastructure.size_chart.size_chart_service import SizeChartService
from app.infrastructure.size_chart.table_generator_factory import TableGeneratorFactory
from app.infrastructure.size_chart.youngla_finder import YoungLASizeChartFinder  # ✅ новий finder

# Product processing
from app.infrastructure.services.product_processing_service import ProductProcessingService

# Web / URL
from app.infrastructure.web.webdriver_service import WebDriverService
from app.shared.utils.url_parser_service import UrlParserService
from app.infrastructure.url import YoungLAUrlStrategy  # ✅ Підключаємо бренд-стратегію

# Music
from app.infrastructure.music.music_file_manager import MusicFileManager
from app.infrastructure.music.yt_downloader import YtDownloader
from app.infrastructure.music.music_sender import MusicSender
from app.infrastructure.music.music_recommendation import MusicRecommendation

# ── BOT ───────────────────────────────────────────────────────────────────
from app.bot.commands.core_commands_feature import CoreCommandsFeature
from app.bot.commands.currency_feature import CurrencyFeature
from app.bot.commands.main_menu_feature import MainMenuFeature
from app.bot.handlers.callback_handler import CallbackHandler
from app.bot.handlers.link_handler import LinkHandler
from app.bot.handlers.product.collection_handler import CollectionHandler
from app.bot.handlers.product.image_sender import ImageSender
from app.bot.handlers.product.product_handler import ProductHandler
from app.bot.handlers.size_chart_handler_bot import SizeChartHandlerBot
from app.bot.services.callback_registry import CallbackRegistry
from app.bot.ui.messengers.availability_messenger import AvailabilityMessenger
from app.bot.ui.formatters.message_formatter import MessageFormatter
from app.bot.ui.messengers.product_messenger import ProductMessenger
from app.bot.ui.messengers.size_chart_messenger import SizeChartMessenger
from app.bot.handlers.price_calculator_handler import PriceCalculationHandler

# Errors
from app.errors.exception_handler_service import ExceptionHandlerService
from app.errors.error_handler import make_error_handler

# Логирование
import logging
from app.shared.utils.logger import init_logging_from_config


def bootstrap_logging() -> logging.Logger:
    """
    Читает logging-узел из конфигов и инициализирует единый логер.
    Безопасно вызывать несколько раз (идемпотентно).
    """
    cfg = ConfigService()
    node = cfg.get("logging", {}) or {}
    return init_logging_from_config(node)


class Container:
    """Єдина точка створення об’єктів і зв’язування залежностей."""

    def __init__(self, config: ConfigService):
        # ── 1) БАЗА / УТИЛІТИ ────────────────────────────────────────────
        self.config = config
        self.constants: AppConstants = CONST

        self.exception_handler_service = ExceptionHandlerService()
        self.error_handler = make_error_handler(self.exception_handler_service)

        self.webdriver_service = WebDriverService(config_service=self.config)
        self.currency_manager = CurrencyManager(config_service=self.config)

        # URL utils (✅ тепер з бренд-стратегіями)
        self.url_parser_service = UrlParserService(
            strategies=[
                YoungLAUrlStrategy(self.config),
                # тут можна додавати інші брендові стратегії
            ]
        )

        # OpenAI + Prompts (‼️ PromptService тепер приймає cfg)
        self.openai_service = OpenAIService(config_service=self.config)
        self.prompt_service = PromptService(cfg=self.config)

        # Files / data
        self.music_file_manager = MusicFileManager()
        self.music_downloader = YtDownloader(config_service=self.config)
        self.weight_data_service = WeightDataService(config_service=self.config)

        # Delivery
        self.delivery_service: IDeliveryService = MeestDeliveryService(config_service=self.config)

        # Formatters / misc
        self.formatter = MessageFormatter()
        self.availability_cache = AvailabilityCacheService()
        self.color_size_formatter = ColorSizeFormatter(config_service=self.config)

        # ImageSender повинен знати про exception handler
        self.image_sender = ImageSender(
            exception_handler=self.exception_handler_service,
            constants=self.constants,
        )

        # ── 2) AI-АДАПТЕРИ / КОНТЕНТ ─────────────────────────────────────
        self.translator_service = TranslatorService(
            openai_service=self.openai_service,
            prompt_service=self.prompt_service,
        )
        self.music_recommendation = MusicRecommendation(
            openai_service=self.openai_service,
            prompt_service=self.prompt_service,
            config_service=self.config,
        )
        self.music_sender = MusicSender(
            downloader=self.music_downloader,
            file_manager=self.music_file_manager,
            config=self.config,
        )
        self.ocr_service = OCRService(
            openai_service=self.openai_service,
            prompt_service=self.prompt_service,
        )
        self.font_service = FontService(config_service=self.config)
        self.table_generator_factory = TableGeneratorFactory(font_service=self.font_service)

        gender_rules = self.config.get("hashtags.gender_rules", {})
        self.gender_classifier = GenderClassifier(gender_rules=gender_rules)
        self.hashtag_generator = HashtagGenerator(
            config_service=self.config,
            openai_service=self.openai_service,
            prompt_service=self.prompt_service,
            gender_classifier=self.gender_classifier,
        )

        # ── 3) DOMAIN-СЕРВІСИ ────────────────────────────────────────────
        # правила прайсингу (все через Decimal — правила читаємо як рядки)
        pricing_rules = PricingRules.from_strings(
            shipping_base_uah=str(self.config.get("pricing.shipping.base_uah", "0")),
            shipping_per_kg_uah=str(self.config.get("pricing.shipping.per_kg_uah", "0")),
            commission_percent=str(self.config.get("pricing.commission.percent", "0")),
            discount_percent=str(self.config.get("pricing.discount.percent", "0")),
            free_threshold_uah=str(self.config.get("pricing.shipping.free_threshold_uah", "999999999")),
        )

        converter = self.currency_manager.get_converter()
        self.pricing_service = PriceService(converter=converter, rules=pricing_rules)

        # ⚖️ резолвер ваги (використовує WeightDataService; Translator по місцю)
        self.weight_resolver = WeightResolver(weight_data_service=self.weight_data_service)

        # Сервіс доступності (домен) — за потреби
        self.availability_service = AvailabilityService()

        # ── 4) ФАБРИКИ / МЕНЕДЖЕРИ ───────────────────────────────────────
        self.parser_factory = ParserFactory(
            webdriver_service=self.webdriver_service,
            translator_service=self.translator_service,
            weight_resolver=self.weight_resolver,
            config_service=self.config,
            url_parser_service=self.url_parser_service,
        )
        # Адаптер доменного контракта фабрики (для сервисов, где нужен IParserFactory)
        self.parser_factory_adapter = ParserFactoryAdapter(self.parser_factory)

        self.availability_report_builder = AvailabilityReportBuilder(
            formatter=self.color_size_formatter
        )

        self.availability_manager = AvailabilityManager(
            availability_service=self.availability_service,
            parser_factory=self.parser_factory,   # здесь ок — менеджеру удобен конкретный фабричный слой
            cache_service=self.availability_cache,
            report_builder=self.availability_report_builder,
            config_service=self.config,
            url_parser_service=self.url_parser_service,
        )

        # Строго создаём провайдер поиска через фабрику (закрывает «двойной путь»)
        self.search_resolver: IProductSearchProvider = self.parser_factory.create_search_provider()

        # ── 5) HIGH-LEVEL СЕРВІСИ / ХЕНДЛЕРИ ─────────────────────────────
        self.price_calculator = PriceCalculationHandler(
            currency_manager=self.currency_manager,
            parser_factory=self.parser_factory,
            pricing_service=self.pricing_service,
            config_service=self.config,
            constants=self.constants,
            exception_handler=self.exception_handler_service,
            url_parser_service=self.url_parser_service,
        )

        self.product_header_service = ProductHeaderService(
            parser_factory=self.parser_factory,
            url_parser_service=self.url_parser_service,
        )

        self.availability_processing_service = AvailabilityProcessingService(
            manager=self.availability_manager,
            header_service=self.product_header_service,
            url_parser_service=self.url_parser_service,
        )

        self.availability_messenger = AvailabilityMessenger()
        self.availability_handler = AvailabilityHandler(
            processing_service=self.availability_processing_service,
            messenger=self.availability_messenger,
        )

        self.content_service = ProductContentService(
            translator_service=self.translator_service,
            hashtag_generator=self.hashtag_generator,
            price_handler=self.price_calculator,
        )

        self.processing_service = ProductProcessingService(
            parser_factory=self.parser_factory,
            availability_processing_service=self.availability_processing_service,
            content_service=self.content_service,
            music_recommendation=self.music_recommendation,
            url_parser_service=self.url_parser_service,
        )

        # ✅ Ініціалізація downloader-а (без конфігу — його конструктор параметрів не приймає)
        self.image_downloader = ImageDownloader()

        # ✅ Реалізація доменного контракту пошуку таблиць (finder)
        self.size_chart_finder = YoungLASizeChartFinder()

        # ✅ SizeChartService тепер залежить від ISizeChartFinder
        self.size_chart_service = SizeChartService(
            downloader=self.image_downloader,
            ocr_service=self.ocr_service,
            generator_factory=self.table_generator_factory,
            size_chart_finder=self.size_chart_finder,
        )

        self.size_chart_messenger = SizeChartMessenger()
        self.size_chart_handler = SizeChartHandlerBot(
            parser_factory=self.parser_factory,
            size_chart_service=self.size_chart_service,
            messenger=self.size_chart_messenger,
            exception_handler=self.exception_handler_service,  # передаём, т.к. хендлер его ожидает
            constants=self.constants,
        )

        self.messenger = ProductMessenger(
            music_sender=self.music_sender,
            size_chart_handler=self.size_chart_handler,
            formatter=self.formatter,
            image_sender=self.image_sender,
            exception_handler=self.exception_handler_service,
            constants=self.constants,
        )

        self.product_handler = ProductHandler(
            currency_manager=self.currency_manager,
            processing_service=self.processing_service,
            messenger=self.messenger,
            exception_handler=self.exception_handler_service,
            constants=self.constants,
            url_parser_service=self.url_parser_service,
        )

        # ⚠️ CollectionProcessingService вимагає і фабрику (дом. контракт), і UrlParserService
        self.collection_processing_service = CollectionProcessingService(
            parser_factory=self.parser_factory_adapter,
            url_parser=self.url_parser_service,
        )

        self.collection_handler = CollectionHandler(
            product_handler=self.product_handler,
            url_parser_service=self.url_parser_service,
            collection_processing_service=self.collection_processing_service,
            exception_handler=self.exception_handler_service,
            constants=self.constants,
            max_items=self.config.get("collection.max_items", 50),
            concurrency=self.config.get("collection.concurrency", 4),
            per_item_retries=self.config.get("collection.per_item_retries", 2),
        )

        # ── 6) ФІЧІ / РОУТЕРИ ────────────────────────────────────────────
        self.callback_registry = CallbackRegistry()
        self.features = [
            CoreCommandsFeature(registry=self.callback_registry, constants=self.constants),
            CurrencyFeature(
                currency_manager=self.currency_manager,
                registry=self.callback_registry,
                constants=self.constants,
                exception_handler=self.exception_handler_service,
            ),
        ]
        self.callback_handler = CallbackHandler(registry=self.callback_registry)

        self.link_handler = LinkHandler(
            product_handler=self.product_handler,
            collection_handler=self.collection_handler,
            size_chart_handler=self.size_chart_handler,
            price_calculator=self.price_calculator,
            availability_handler=self.availability_handler,
            search_resolver=self.search_resolver,
            url_parser_service=self.url_parser_service,
            currency_manager=self.currency_manager,
            constants=self.constants,
            exception_handler=self.exception_handler_service,
        )

        self.main_menu_feature = MainMenuFeature(constants=self.constants)
        self.menu_handler = self.main_menu_feature  # legacy alias для BotRegistrar