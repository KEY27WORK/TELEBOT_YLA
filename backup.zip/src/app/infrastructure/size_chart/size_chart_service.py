from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Awaitable, Callable, List, Optional, Union, cast

# ── Prometheus (опционально) ──────────────────────────────────────────────
try:
    from prometheus_client import Counter  # type: ignore
except Exception:  # pragma: no cover
    Counter = None  # type: ignore

from app.domain.size_chart.interfaces import ISizeChartFinder, ISizeChartService

# Outcome даунлоадера
from app.infrastructure.size_chart.image_downloader import (
    ImageDownloader,
    DownloadResult,
    DownloadError,
    DownloadOutcome,
)

from app.infrastructure.size_chart.ocr_service import OCRService
from app.infrastructure.size_chart.table_generator_factory import TableGeneratorFactory
from app.infrastructure.size_chart.dto import SizeChartOcrResult, SizeChartOcrStatus

# ⚠️ ChartType именно из shared.prompts (его ждёт фабрика)
from app.shared.utils.prompts import ChartType
from app.shared.utils.prompt_service import ChartType as PromptChartType

from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(f"{LOG_NAME}.ai")

# ── Метрики (если prometheus_client доступен) ─────────────────────────────
if Counter:
    SIZECHART_DOWNLOAD_ERRORS_TOTAL = Counter(
        "sizechart_download_errors_total",
        "Ошибки скачивания таблиц размеров (оркестрация) по причинам",
        ["reason"],
    )
    SIZECHART_OCR_ERRORS_TOTAL = Counter(
        "sizechart_ocr_errors_total",
        "Ошибки OCR распознавания таблиц размеров по статусам",
        ["status"],
    )
    SIZECHART_GENERATE_ERRORS_TOTAL = Counter(
        "sizechart_generate_errors_total",
        "Ошибки генерации PNG таблиц размеров",
        ["kind"],
    )
else:
    SIZECHART_DOWNLOAD_ERRORS_TOTAL = None  # type: ignore
    SIZECHART_OCR_ERRORS_TOTAL = None       # type: ignore
    SIZECHART_GENERATE_ERRORS_TOTAL = None  # type: ignore


def _inc_dl_err(reason: str) -> None:
    if SIZECHART_DOWNLOAD_ERRORS_TOTAL:
        try:
            SIZECHART_DOWNLOAD_ERRORS_TOTAL.labels(reason=reason).inc()
        except Exception:
            pass


def _inc_ocr_err(status: str) -> None:
    if SIZECHART_OCR_ERRORS_TOTAL:
        try:
            SIZECHART_OCR_ERRORS_TOTAL.labels(status=status).inc()
        except Exception:
            pass


def _inc_gen_err(kind: str) -> None:
    if SIZECHART_GENERATE_ERRORS_TOTAL:
        try:
            SIZECHART_GENERATE_ERRORS_TOTAL.labels(kind=kind).inc()
        except Exception:
            pass


class Stage(Enum):
    START = "start"
    DOWNLOAD_START = "download_start"
    DOWNLOAD_OK = "download_ok"
    DOWNLOAD_FAIL = "download_fail"
    OCR_START = "ocr_start"
    OCR_OK = "ocr_ok"
    OCR_FAIL = "ocr_fail"
    GENERATE_START = "generate_start"
    GENERATE_OK = "generate_ok"
    GENERATE_FAIL = "generate_fail"
    DONE = "done"


@dataclass
class SizeChartProgress:
    idx: int
    url: str
    chart_type: ChartType
    stage: Stage
    started_at: float
    elapsed: float
    path: Optional[str] = None
    error: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)


ProgressCallback = Callable[[SizeChartProgress], Optional[Awaitable[None]]]


class SizeChartService(ISizeChartService):
    _TMP_DIR_NAME = os.getenv("SIZE_CHART_TMP", "temp_size_charts")
    _MAX_CONCURRENCY = int(os.getenv("SIZE_CHART_CONCURRENCY", "4"))

    def __init__(
        self,
        downloader: ImageDownloader,
        ocr_service: OCRService,
        generator_factory: TableGeneratorFactory,
        size_chart_finder: ISizeChartFinder,
        *,
        on_progress: Optional[ProgressCallback] = None,
    ) -> None:
        self.downloader = downloader
        self.ocr_service = ocr_service
        self.generator_factory = generator_factory
        self.finder = size_chart_finder
        self.on_progress: ProgressCallback = on_progress or (lambda *_a, **_k: None)

    async def process_all_size_charts(self, page_source: str) -> List[str]:
        if not page_source or not isinstance(page_source, str):
            logger.warning("⚠️ Передан пустой или некорректный page_source.")
            return []

        task = asyncio.current_task()
        if task is not None and task.cancelled():
            logger.info("🛑 Отмена обработки по запросу")
            return []

        started = time.time()
        images_to_process = self.finder.find_images(page_source)
        if not images_to_process:
            logger.info("ℹ️ Таблицы размеров не найдены.")
            return []

        tmp_dir = Path(self._TMP_DIR_NAME)
        tmp_dir.mkdir(parents=True, exist_ok=True)

        logger.info("🔎 Найдено %d изображений для обработки", len(images_to_process))

        sem = asyncio.Semaphore(max(1, self._MAX_CONCURRENCY))
        tasks: List[asyncio.Task[Optional[str]]] = [
            asyncio.create_task(self._process_one(i, url, ctype, tmp_dir, sem))
            for i, (url, ctype) in enumerate(images_to_process)
        ]

        try:
            results_raw: List[Union[Optional[str], BaseException]] = await asyncio.gather(
                *tasks, return_exceptions=True
            )
        except asyncio.CancelledError:
            logger.info("🛑 Отмена: прекращаем %d задач(и)...", len(tasks))
            for t in tasks:
                t.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            raise

        ok: List[str] = []
        for r in results_raw:
            if isinstance(r, BaseException):
                logger.warning("⚠️ Подзадача завершилась с ошибкой: %s", r)
                continue
            if r:
                ok.append(r)

        logger.info(
            "✅ Обработано %d/%d таблиц за %.2f сек.",
            len(ok),
            len(images_to_process),
            time.time() - started,
        )
        return ok

    async def _emit_progress(
        self,
        *,
        idx: int,
        url: str,
        chart_type: ChartType,
        stage: Stage,
        started_at: float,
        path: Optional[str] = None,
        error: Optional[str] = None,
        extra: Optional[dict[str, Any]] = None,
    ) -> None:
        payload = SizeChartProgress(
            idx=idx,
            url=url,
            chart_type=chart_type,
            stage=stage,
            started_at=started_at,
            elapsed=max(0.0, time.time() - started_at),
            path=path,
            error=error,
            extra=extra or {},
        )
        maybe_coro = self.on_progress(payload)
        if asyncio.iscoroutine(maybe_coro):
            await maybe_coro  # type: ignore[func-returns-value]

    async def _process_one(
        self,
        idx: int,
        img_url: str,
        chart_type: ChartType,
        tmp_dir: Path,
        sem: asyncio.Semaphore,
    ) -> Optional[str]:
        async with sem:
            t0 = time.time()
            pretty = f"[{idx+1}] {img_url}"
            logger.info("▶️  Старт обработки %s (type=%s)", pretty, chart_type.value)
            await self._emit_progress(
                idx=idx, url=img_url, chart_type=chart_type, stage=Stage.START, started_at=t0
            )

            # 1) Download (ветвимся по результату/коду ошибки)
            await self._emit_progress(
                idx=idx, url=img_url, chart_type=chart_type, stage=Stage.DOWNLOAD_START, started_at=t0
            )
            ext = self._guess_ext(img_url)
            download_path = tmp_dir / f"download_{idx}{ext}"

            outcome: DownloadOutcome = await self.downloader.download_info(img_url, download_path)

            if isinstance(outcome, DownloadResult):
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.DOWNLOAD_OK,
                    started_at=t0,
                    path=str(outcome.path),
                    extra={
                        "download_status": "ok",
                        "content_type": outcome.content_type,
                        "content_length": outcome.content_length,
                        "bytes_written": outcome.bytes_written,
                        "sha256": outcome.sha256,
                    },
                )
                downloaded_path = outcome.path
            else:
                err_code = (
                    getattr(outcome, "name", None)
                    or getattr(outcome, "value", None)
                    or str(outcome)
                )
                logger.warning(
                    "⛔ Пропущено (download error=%s): %s",
                    err_code, pretty,
                    extra={"download_error": err_code},
                )
                _inc_dl_err(str(err_code))
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.DOWNLOAD_FAIL,
                    started_at=t0,
                    error=f"download:{err_code}",
                    extra={"download_status": "fail", "download_error": err_code},
                )
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.DONE,
                    started_at=t0,
                    error=f"download:{err_code}",
                )
                return None

            # 2) OCR
            await self._emit_progress(
                idx=idx, url=img_url, chart_type=chart_type, stage=Stage.OCR_START, started_at=t0
            )

            ocr_res: SizeChartOcrResult = await self.ocr_service.recognize(
                str(downloaded_path), cast(PromptChartType, chart_type)
            )

            if ocr_res.status != SizeChartOcrStatus.OK:
                logger.warning(
                    "⛔ OCR не распознал данные %s (status=%s, err=%s)",
                    pretty,
                    ocr_res.status.value,
                    ocr_res.error,
                    extra={"ocr_status": ocr_res.status.value},
                )
                _inc_ocr_err(ocr_res.status.value)
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.OCR_FAIL,
                    started_at=t0,
                    error=ocr_res.status.value,
                    extra={"ocr_status": ocr_res.status.value, "ocr_error": ocr_res.error},
                )
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.DONE,
                    started_at=t0,
                    error=ocr_res.status.value,
                    extra={"ocr_status": ocr_res.status.value},
                )
                return None

            await self._emit_progress(
                idx=idx,
                url=img_url,
                chart_type=chart_type,
                stage=Stage.OCR_OK,
                started_at=t0,
                extra={"ocr_status": ocr_res.status.value},
            )

            # 3) Generate PNG
            await self._emit_progress(
                idx=idx, url=img_url, chart_type=chart_type, stage=Stage.GENERATE_START, started_at=t0
            )
            out_path = str(tmp_dir / f"generated_{idx}.png")
            try:
                generator = self.generator_factory.create_generator(
                    chart_type=chart_type,
                    data=ocr_res.data or {},
                    path=out_path,
                )
            except Exception as e:
                msg = f"factory_error: {e}"
                logger.exception(
                    "❌ Ошибка фабрики генераторов для %s: %s",
                    pretty, e,
                    extra={"generate_error": "factory_error"},
                )
                _inc_gen_err("factory_error")
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.GENERATE_FAIL,
                    started_at=t0,
                    error=msg,
                )
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.DONE,
                    started_at=t0,
                    error=msg,
                )
                return None

            try:
                result_path = await generator.generate()
            except Exception as e:
                msg = f"generate_error: {e}"
                logger.exception(
                    "❌ Ошибка генерации PNG для %s: %s",
                    pretty, e,
                    extra={"generate_error": "generate_error"},
                )
                _inc_gen_err("generate_error")
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.GENERATE_FAIL,
                    started_at=t0,
                    error=msg,
                )
                await self._emit_progress(
                    idx=idx,
                    url=img_url,
                    chart_type=chart_type,
                    stage=Stage.DONE,
                    started_at=t0,
                    error=msg,
                )
                return None

            await self._emit_progress(
                idx=idx,
                url=img_url,
                chart_type=chart_type,
                stage=Stage.GENERATE_OK,
                started_at=t0,
                path=result_path,
            )
            logger.info("✅ Готово %s → %s (%.2fs)", pretty, result_path, time.time() - t0)

            await self._emit_progress(
                idx=idx, url=img_url, chart_type=chart_type, stage=Stage.DONE, started_at=t0, path=result_path
            )
            return result_path

    @staticmethod
    def _guess_ext(url: str) -> str:
        lower = (url or "").lower()
        for ext in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"):
            if lower.endswith(ext):
                return ext
        return ".png"