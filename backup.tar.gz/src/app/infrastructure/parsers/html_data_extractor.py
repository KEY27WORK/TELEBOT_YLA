# 📦 app/infrastructure/parsers/html_data_extractor.py
# -*- coding: utf-8 -*-
"""
Низкоуровневый экстрактор данных со страницы товара.

Цели:
- Аккуратно достать title / price / images / description.
- Прочитать JSON-LD (Product/Offer/AggregateOffer) и legacy-скрипты Shopify.
- Вернуть данные в унифицированном, безопасном для типизатора (Pylance) виде.

Дизайн (KISS/DRY/SOLID):
- Селекторы и карта ключей берутся из конфигурации (yaml) с кэшем и дефолтами.
- Чёткие контракты по возвращаемым типам (совпадают с BaseParser).
- Никаких «магических» допущений: каждая ветка с проверками/фолбэками.
- Типы строго аннотированы; все спорные места приводятся через утилиты.
"""

from __future__ import annotations

# Внешние зависимости
from bs4 import BeautifulSoup
from bs4.element import NavigableString, Tag, PageElement  # типы узлов bs4

# Stdlib
import json
import logging
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union, cast

# Внутренние модули проекта
from app.config.config_service import ConfigService
from app.shared.utils.logger import LOG_NAME
from app.shared.utils.collections import uniq_keep_order  # ✅ единый дедуп

# ===============================
# 🔧 ЛОГГЕР
# ===============================
logger = logging.getLogger(f"{LOG_NAME}.parser.extractor")


# ===============================
# 🔧 ДЕФОЛТНЫЕ КОНСТАНТЫ (fallback)
# ===============================
_DEFAULT_SELECTORS: Dict[str, Any] = {
    "TITLE_LIST": (
        "h1.product-title",
        "h1.product__title",
        "h1[itemprop='name']",
        "meta[property='og:title']",
        "title",
    ),
    "PRICE_LIST": (
        ".price__current, .price--large, .product__price .price",
        ".product-price, .sale-price, .price-item--regular, .price-item--sale",
        "meta[itemprop='price']",
    ),
    "MAIN_IMAGE_LIST": (
        'meta[property="og:image"]',
        ".product__media img[src], .product-gallery__image img[src]",
        "img#FeaturedMedia-product-template[src]",
    ),
    "ALL_IMAGES_LIST": (
        ".product-gallery__thumbnail img[src]",
        ".product__media img[src]",
        ".product-gallery__thumbnail-list img[src]",
        "img[srcset], img[data-src], img[data-srcset], img[src]",
    ),
    "DESCRIPTION_CONTAINER_LIST": (
        'div[data-block-type="description"] .prose',
        "div.product__description, div#ProductAccordion-product-description .prose",
        "div#product-description, section.product-description, .rte.product__description, .prose",
    ),
    "JSON_LD_SCRIPT": 'script[type="application/ld+json"]',
    "LEGACY_STOCK_SELECTORS": (
        "script#ProductJson",
        'script[data-product-json="true"]',
        "script",  # общий фолбэк для window.Product/var Product
    ),
}

_DEFAULT_KEY_MAP: Dict[str, str] = {
    "MATERIAL": "МАТЕРИАЛ",
    "MATERIALS": "МАТЕРИАЛ",
    "FABRIC": "МАТЕРИАЛ",
    "FIT": "ПОСАДКА",
    "DESIGN": "ОПИС",
    "DESCRIPTION": "ОПИС",
    "MODEL": "МОДЕЛЬ",
    "MODELS": "МОДЕЛЬ",
    "FABRIC WEIGHT": "ЩИЛЬНОСТЬ ТКАНИНИ",
    "CARE": "ДОГЛЯД",
    "FEATURES": "ОСОБЕННОСТИ",
    "DETAILS": "ДЕТАЛИ",
}


# ===============================
# 🔧 УТИЛИТЫ НОРМАЛИЗАЦИИ
# ===============================
def _norm_ws(text: str) -> str:
    """Нормализует пробелы/переводы строк."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def _attr_to_str(value: Any) -> str:
    """
    Превращает значение HTML-атрибута в строку:
    - Если list/tuple — берём первый непустой элемент.
    - Если None — вернём пустую строку.
    - Иначе — str(value).
    """
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        for v in value:
            if v:
                return str(v)
        return ""
    return str(value)


def _as_list(x: Any) -> List[Any]:
    """Сворачивает значение к списку (для image/offers и т.п.)."""
    if x is None:
        return []
    if isinstance(x, list):
        return x
    return [x]


def _try_json_loads(raw: str) -> Optional[Any]:
    """Безопасный json.loads c логированием ошибок; пустые строки игнорируются."""
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception as e:
        logger.debug("JSON decode error: %s", e)
        return None


def _normalize_image_url(src: str) -> str:
    """
    Нормализация URL изображения:
    - Рубим srcset по пробелу (берём первый URL).
    - Префиксуем протокол для ссылок вида //cdn… .
    """
    if not src:
        return ""
    src = src.split(" ")[0]
    if src.startswith("//"):
        return f"https:{src}"
    return src


def _strip_query(u: str) -> str:
    """Отрезает query-параметры (стабилизация дублей)."""
    if not u:
        return ""
    return u.split("?", 1)[0]


def _clean_text_nodes(nodes: Iterable[Union[str, NavigableString, Tag, PageElement]]) -> str:
    """
    Склеивает текст из набора узлов:
    - str/NavigableString — берём как есть (нормализуя пробелы).
    - Tag/PageElement — берём теговый текст.
    """
    parts: List[str] = []
    for node in nodes:
        if isinstance(node, str):
            t = _norm_ws(node)
            if t:
                parts.append(t)
        elif isinstance(node, NavigableString):
            t = _norm_ws(str(node))
            if t:
                parts.append(t)
        elif isinstance(node, (Tag, PageElement)):
            try:
                text = cast(Tag, node).get_text(" ", strip=True)
            except Exception:
                text = str(node)
            t = _norm_ws(text)
            if t:
                parts.append(t)
    return _norm_ws(" ".join(parts))


# ===============================
# 🧠 ОСНОВНОЙ КЛАСС
# ===============================
class HtmlDataExtractor:
    """
    Извлекает структурированную информацию из DOM-дерева продукта.

    Контракт с BaseParser:
      - extract_title()             -> str
      - extract_price()             -> Union[str, float]
      - extract_description()       -> str
      - extract_main_image()        -> str
      - extract_all_images(limit?, filter_small_images?) -> List[str]
      - extract_detailed_sections() -> Dict[str, str]
      - extract_stock_from_json_ld()-> Optional[Dict[str, Dict[str, bool]]]
      - extract_stock_from_legacy() -> Optional[Dict[str, Dict[str, bool]]]
    """

    # ── Кэш конфигурации на уровне класса ───────────────────────────────────
    _SELECTORS_CACHE: Optional[Dict[str, Any]] = None
    _KEY_MAP_CACHE: Optional[Dict[str, str]] = None

    @dataclass(frozen=True)
    class Selectors:
        """
        Контейнер нормализованных селекторов (tuple/str).
        Поля соответствуют ключам _DEFAULT_SELECTORS.
        """
        TITLE_LIST: Tuple[str, ...]
        PRICE_LIST: Tuple[str, ...]
        MAIN_IMAGE_LIST: Tuple[str, ...]
        ALL_IMAGES_LIST: Tuple[str, ...]
        DESCRIPTION_CONTAINER_LIST: Tuple[str, ...]
        JSON_LD_SCRIPT: str
        LEGACY_STOCK_SELECTORS: Tuple[str, ...]


    # ===============================
    # ⚙️ КОНФИГ-ЛОАДЕРЫ
    # ===============================
    @classmethod
    def _load_config_if_needed(cls) -> None:
        """Ленивое чтение конфигурации + кэширование."""
        if cls._SELECTORS_CACHE is not None and cls._KEY_MAP_CACHE is not None:
            return

        cfg = ConfigService()

        # Бренд (необязательно). Если есть, позволяем overrides в parser.selectors.brands.<brand>
        brand = (
            cfg.get("parser.selectors.brand")
            or cfg.get("brand")
            or cfg.get("brand.current")
            or cfg.get("parser.brand")
        )
        brand = (str(brand).strip().lower() if isinstance(brand, str) else None) or None

        # 1) defaults из yaml
        sel_defaults = cfg.get("parser.selectors.defaults") or {}

        # 2) brand overrides
        brand_overrides: Dict[str, Any] = {}
        if brand:
            brands_root = cfg.get("parser.selectors.brands") or {}
            if isinstance(brands_root, dict):
                brand_overrides = brands_root.get(brand) or {}

        # 3) финальная сборка селекторов с дефолтами кода
        sel = _merge_selectors_dict(_DEFAULT_SELECTORS, sel_defaults, brand_overrides)

        # key_map
        key_map_from_cfg = cfg.get("parser.selectors.key_map") or {}
        if not isinstance(key_map_from_cfg, dict):
            key_map_from_cfg = {}
        cls._KEY_MAP_CACHE = {**_DEFAULT_KEY_MAP, **{str(k).upper(): str(v) for k, v in key_map_from_cfg.items()}}

        # Нормализуем типы селекторов (tuple/str) и кладём в кэш
        cls._SELECTORS_CACHE = _normalize_selectors_types(sel)

        logger.debug("HtmlDataExtractor: selectors and key_map loaded (brand=%s).", brand or "default")

    @classmethod
    def _selectors(cls) -> "HtmlDataExtractor.Selectors":
        """Возвращает selectors из кэша, приводя к dataclass."""
        cls._load_config_if_needed()
        assert cls._SELECTORS_CACHE is not None
        s = cls._SELECTORS_CACHE
        return HtmlDataExtractor.Selectors(
            TITLE_LIST=s["TITLE_LIST"],
            PRICE_LIST=s["PRICE_LIST"],
            MAIN_IMAGE_LIST=s["MAIN_IMAGE_LIST"],
            ALL_IMAGES_LIST=s["ALL_IMAGES_LIST"],
            DESCRIPTION_CONTAINER_LIST=s["DESCRIPTION_CONTAINER_LIST"],
            JSON_LD_SCRIPT=s["JSON_LD_SCRIPT"],
            LEGACY_STOCK_SELECTORS=s["LEGACY_STOCK_SELECTORS"],
        )

    @classmethod
    def _key_map(cls) -> Dict[str, str]:
        """Возвращает key_map из кэша."""
        cls._load_config_if_needed()
        assert cls._KEY_MAP_CACHE is not None
        return cls._KEY_MAP_CACHE

    # ===============================
    # 🔎 PUBLIC API
    # ===============================
    def __init__(self, soup: BeautifulSoup) -> None:
        self.soup = soup
        # Чтение заранее — чтобы фиксировать снапшот конфигурации на момент инстанса
        self._S = self._selectors()
        self._KEY_MAP = self._key_map()

    def extract_title(self) -> str:
        # 1) JSON-LD
        title = self._title_from_json_ld()
        if title:
            return title

        # 2) DOM
        for sel in self._S.TITLE_LIST:
            tag = self.soup.select_one(sel)
            if not tag:
                continue
            if isinstance(tag, Tag) and tag.name == "meta":
                t = _attr_to_str(tag.get("content"))
            else:
                try:
                    t = cast(Tag, tag).get_text(strip=True)
                except Exception:
                    t = str(tag)
            t = _norm_ws(t)
            if t:
                return t
        return "Без назви"

    def extract_price(self) -> Union[str, float]:
        """
        Возвращает СЫРОЕ значение цены (строку/число).
        Приведение к Decimal делается на уровне BaseParser через shared/utils/number.py.
        """
        # 1) JSON-LD
        price = self._price_from_json_ld()
        if price:
            return price

        # 2) <meta itemprop="price">
        tag = self.soup.select_one("meta[itemprop='price']")
        if isinstance(tag, Tag) and tag.has_attr("content"):
            content = _norm_ws(_attr_to_str(tag.get("content")))
            if content:
                return content

        # 3) Текстовые блоки цены
        for sel in self._S.PRICE_LIST:
            price_el = self.soup.select_one(sel)
            if price_el:
                try:
                    text = cast(Tag, price_el).get_text(" ", strip=True)
                except Exception:
                    text = str(price_el)
                text = _norm_ws(text)
                m = re.search(r"[-+]?\d+(?:[.,]\d+)?", text)
                if m:
                    return m.group(0)
                if text:
                    return text

        return 0.0

    def extract_description(self) -> str:
        # 1) JSON-LD
        desc = self._description_from_json_ld()
        if desc:
            return desc

        # 2) <meta name="description">
        meta = self.soup.select_one('meta[name="description"]')
        if isinstance(meta, Tag) and meta.has_attr("content"):
            t = _norm_ws(_attr_to_str(meta.get("content")))
            if t:
                return t

        # 3) Детальные секции
        sections = self.extract_detailed_sections()
        for key in ("ОПИС", "DESCRIPTION", "DESIGN"):
            if sections.get(key):
                return sections[key]

        return ""

    def extract_main_image(self) -> str:
        # 1) JSON-LD
        img = self._main_image_from_json_ld()
        if img:
            return img

        # 2) og:image / явные img
        for sel in self._S.MAIN_IMAGE_LIST:
            tag = self.soup.select_one(sel)
            if not tag:
                continue

            if isinstance(tag, Tag) and tag.name == "meta":
                url = _normalize_image_url(_attr_to_str(tag.get("content")))
            else:
                # src / data-src / data-original
                try:
                    t = cast(Tag, tag)
                    url_raw = (
                        _attr_to_str(t.get("src"))
                        or _attr_to_str(t.get("data-src"))
                        or _attr_to_str(t.get("data-original"))
                        or _attr_to_str(t.get("data-srcset")).split(" ")[0]
                    )
                except Exception:
                    url_raw = str(tag)
                url = _normalize_image_url(url_raw)

            if url:
                return url

        return ""

    def extract_all_images(
        self,
        *,
        limit: Optional[int] = None,
        filter_small_images: bool = True,
    ) -> List[str]:
        """
        Собирает все релевантные изображения:
          • JSON-LD image (str | list[str] | list[obj])
          • Галерея/превью из DOM (src/srcset/data-src/…)
          • Канонизация Shopify-суффиксов и фильтрация мусора/миниатюр

        :param limit: если задан — «жёсткий» верхний лимит количества картинок.
        :param filter_small_images: включить/выключить фильтр миниатюр/плейсхолдеров.
        """

        def _canonicalize_shopify(u: str) -> str:
            # Удаляем _800x, _800x600 перед расширением
            return re.sub(
                r'_(\d+x\d+|\d+x)(?=\.(?:jpe?g|png|webp|avif)(?:$|\?))',
                "",
                u,
                flags=re.IGNORECASE,
            )

        def _normalize_img(u: str) -> str:
            u = _normalize_image_url(u)
            u = _canonicalize_shopify(u)
            u = _strip_query(u)
            return u

        BAD_TOKENS = (
            "sprite", "favicon", "logo", "icon", "spinner", "loading",
            "placeholder", "badge", "swatch", "thumb", "minicart", "lazy",
        )
        EXT_OK = (".jpg", ".jpeg", ".png", ".webp", ".avif")

        def _looks_like_product_img(u: str) -> bool:
            if not u:
                return False
            lu = u.lower()
            if not lu.endswith(EXT_OK):
                return False
            return not any(tok in lu for tok in BAD_TOKENS)

        def _probably_too_small(u: str) -> bool:
            # Грубый фильтр миниатюр по типичным паттернам размера в URL
            lu = u.lower()
            if re.search(r'_(3[2-9]|[4-9]\d|1\d{2})x(3[2-9]|[4-9]\d|1\d{2})\.', lu):
                return True
            if re.search(r'_(\d{1,2})x(\d{1,2})\.', lu):
                return True
            if re.search(r'/(w(?:idth)?[_-]?\d{1,3})/', lu):
                return True
            return False

        images: List[str] = []

        # 1) JSON-LD
        images.extend(self._images_from_json_ld())

        # 2) Галерея из DOM
        for sel in self._S.ALL_IMAGES_LIST:
            for img_tag in self.soup.select(sel):
                try:
                    t = cast(Tag, img_tag)
                    src = (
                        _attr_to_str(t.get("src"))
                        or _attr_to_str(t.get("data-src"))
                        or _attr_to_str(t.get("data-original"))
                        or _attr_to_str(t.get("srcset")).split(" ")[0]
                        or _attr_to_str(t.get("data-srcset")).split(" ")[0]
                    )
                except Exception:
                    src = str(img_tag)

                url = _normalize_img(src or "")
                if url:
                    images.append(url)

        # 3) Дедуп/фильтры
        dedup = list(uniq_keep_order(images))

        if filter_small_images:
            filtered = [u for u in dedup if _looks_like_product_img(u)]
            filtered = [u for u in filtered if not _probably_too_small(u)]
        else:
            # Только «типовой мусор» (favicon/logo/sprite и неправильные расширения) режем всегда
            filtered = [u for u in dedup if _looks_like_product_img(u) or True]
            # но без проверок на «маленькие» размеры

        # 4) Применяем «жёсткий» лимит, если он задан и валиден
        if isinstance(limit, int) and limit > 0:
            filtered = filtered[:limit]

        return filtered

    def extract_detailed_sections(self) -> Dict[str, str]:
        """
        Собирает структурные секции описания:
          • <p><strong>KEY:</strong> value…</p>
          • Заголовки (h2/h3/h4/strong) + последующие узлы до следующего заголовка
          • Списки <ul>/<ol> после ключевых заголовков
        """
        sections: Dict[str, str] = {}

        container: Optional[Tag] = None
        for sel in self._S.DESCRIPTION_CONTAINER_LIST:
            el = self.soup.select_one(sel)
            if isinstance(el, Tag):
                container = el
                break

        if not container:
            logger.info("Не найден контейнер описания ни по одному селектору.")
            return sections

        key_map = self._KEY_MAP

        # Вариант 1: <p><strong>KEY:</strong> value…</p>
        for p in container.find_all("p"):
            if not isinstance(p, Tag):
                continue
            strong = p.find("strong")
            if not isinstance(strong, Tag):
                continue

            key_raw = _norm_ws(str(strong.get_text(" ", strip=True)).replace(":", ""))
            if not key_raw:
                continue
            key = key_map.get(key_raw.upper())
            if not key:
                continue

            parts: List[Union[str, NavigableString, Tag, PageElement]] = []
            for node in strong.next_siblings:
                if isinstance(node, (NavigableString, Tag, PageElement, str)):
                    parts.append(node)

            # Если пусто — берём соседние узлы до следующего <p> со <strong>
            if not _norm_ws(_clean_text_nodes(parts)):
                nxt = p.next_sibling
                while nxt is not None:
                    if isinstance(nxt, Tag) and nxt.name == "p" and nxt.find("strong"):
                        break
                    parts.append(nxt)  # type: ignore[arg-type]
                    nxt = nxt.next_sibling

            value = _clean_text_nodes(parts)
            if value:
                sections[key] = value

        # Вариант 2: заголовки как ключи
        if not sections:
            for h in container.select("h2, h3, h4, strong"):
                if not isinstance(h, Tag):
                    continue
                key_candidate = _norm_ws(h.get_text(" ", strip=True).replace(":", ""))
                key = key_map.get(key_candidate.upper())
                if not key:
                    continue

                parts: List[Union[str, NavigableString, Tag, PageElement]] = []
                node = h.next_sibling
                while node is not None:
                    if isinstance(node, Tag) and node.name in {"h2", "h3", "h4", "strong"}:
                        break
                    parts.append(node)  # type: ignore[arg-type]
                    node = node.next_sibling

                value = _clean_text_nodes(parts)
                if value:
                    sections[key] = value

        # Вариант 3: списки после ключевых заголовков
        if not sections:
            for h in container.select("h2, h3, h4, strong"):
                if not isinstance(h, Tag):
                    continue
                key_candidate = _norm_ws(h.get_text(" ", strip=True).replace(":", ""))
                key = key_map.get(key_candidate.upper())
                if not key:
                    continue
                ul = h.find_next_sibling(["ul", "ol"])
                if isinstance(ul, Tag):
                    items = [li.get_text(" ", strip=True) for li in ul.find_all("li")]
                    value = _norm_ws("; ".join(i for i in items if i))
                    if value:
                        sections[key] = value

        return sections

    def extract_stock_from_json_ld(self) -> Optional[Dict[str, Dict[str, bool]]]:
        """Наличие из JSON-LD (offers) → {color: {size: available}}."""
        for prod in self._json_ld_products():
            offers = prod.get("offers")
            if not offers:
                continue
            stock = self._offers_to_stock_map(offers)
            if stock:
                return stock
        return None

    def extract_stock_from_legacy(self) -> Optional[Dict[str, Dict[str, bool]]]:
        """Legacy-источники Shopify: #ProductJson, data-product-json, window.Product."""
        # 1) #ProductJson
        tag = self.soup.select_one("script#ProductJson")
        if isinstance(tag, Tag):
            raw = (tag.string or tag.text or "").strip()
            obj = _try_json_loads(raw)
            stock = self._shopify_variants_to_stock(obj)
            if stock:
                return stock

        # 2) data-product-json="true"
        tag = self.soup.select_one('script[data-product-json="true"]')
        if isinstance(tag, Tag):
            raw = (tag.string or tag.text or "").strip()
            obj = _try_json_loads(raw)
            stock = self._shopify_variants_to_stock(obj)
            if stock:
                return stock

        # 3) window.Product / var Product
        for s in self.soup.find_all("script"):
            if not isinstance(s, Tag):
                continue
            txt = (s.string or s.text or "").strip()
            if not txt:
                continue
            m = re.search(r"window\.Product\s*=\s*(\{.*?\});", txt, re.S)
            if not m:
                m = re.search(r"var\s+Product\s*=\s*(\{.*?\});", txt, re.S)
            if m:
                obj = _try_json_loads(m.group(1))
                stock = self._shopify_variants_to_stock(obj)
                if stock:
                    return stock

        return None

    # ===============================
    # 🔒 PRIVATE: JSON-LD
    # ===============================
    def _json_ld_blocks(self) -> List[Any]:
        """Собирает и декодирует все <script type="application/ld+json"> в список объектов."""
        out: List[Any] = []
        for script in self.soup.select(self._S.JSON_LD_SCRIPT):
            if not isinstance(script, Tag):
                continue
            raw = (script.string or script.text or "").strip()
            obj = _try_json_loads(raw)
            if obj is None:
                continue
            out.extend(_as_list(obj))
        return out

    def _json_ld_products(self) -> List[Dict[str, Any]]:
        """Фильтрует JSON-LD до объектов с @type == Product (учитывая массивы типов)."""
        prods: List[Dict[str, Any]] = []
        for obj in self._json_ld_blocks():
            if not isinstance(obj, dict):
                continue
            types = _as_list(obj.get("@type"))
            if any(str(t).lower() == "product" for t in types):
                prods.append(obj)
        return prods

    def _title_from_json_ld(self) -> Optional[str]:
        for prod in self._json_ld_products():
            name = _norm_ws(str(prod.get("name", "")))
            if name:
                return name
        return None

    def _description_from_json_ld(self) -> Optional[str]:
        for prod in self._json_ld_products():
            d = prod.get("description")
            if isinstance(d, str):
                return _norm_ws(BeautifulSoup(d, "lxml").get_text(" ", strip=True))
            if isinstance(d, dict):
                val = d.get("@value") or d.get("value") or d.get("text")
                if isinstance(val, str):
                    return _norm_ws(BeautifulSoup(val, "lxml").get_text(" ", strip=True))
        return None

    def _price_from_json_ld(self) -> Optional[str]:
        """
        Достаёт цену из Product.offers:
          • Offer | [Offer] | AggregateOffer (lowPrice/highPrice/priceSpecification.price)
          • Возвращает строку, BaseParser дальше приведёт к Decimal.
        """
        for prod in self._json_ld_products():
            offers = prod.get("offers")
            if not offers:
                continue

            # AggregateOffer
            if isinstance(offers, dict) and str(offers.get("@type", "")).lower() == "aggregateoffer":
                candidates = _as_list(offers.get("offers"))
                if not candidates:
                    for k in ("lowPrice", "highPrice", "price"):
                        v = offers.get(k)
                        if v not in (None, ""):
                            return str(v)
            else:
                candidates = _as_list(offers)

            for off in candidates:
                if not isinstance(off, dict):
                    continue
                price = (
                    off.get("price")
                    or (isinstance(off.get("priceSpecification"), dict) and off["priceSpecification"].get("price"))
                    or off.get("lowPrice")
                    or off.get("highPrice")
                )
                if price not in (None, ""):
                    return str(price)
        return None

    def _main_image_from_json_ld(self) -> Optional[str]:
        for prod in self._json_ld_products():
            img = prod.get("image")
            if not img:
                continue
            for item in _as_list(img):
                if isinstance(item, str):
                    url = _normalize_image_url(item)
                elif isinstance(item, dict):
                    url = _normalize_image_url(str(item.get("url") or item.get("@id") or ""))
                else:
                    url = ""
                url = _strip_query(url)
                if url:
                    return url
        return None

    def _images_from_json_ld(self) -> List[str]:
        images: List[str] = []
        for prod in self._json_ld_products():
            img = prod.get("image")
            if not img:
                continue
            for item in _as_list(img):
                if isinstance(item, str):
                    url = _normalize_image_url(item)
                elif isinstance(item, dict):
                    url = _normalize_image_url(str(item.get("url") or item.get("@id") or ""))
                else:
                    url = ""
                url = _strip_query(url)
                if url:
                    images.append(url)
        return list(uniq_keep_order(images))
        # ^ список нужен BaseParser'у; tuple не требуется на этом слое

    # ===============================
    # 🔒 PRIVATE: LEGACY / SHOPIFY
    # ===============================
    def _shopify_variants_to_stock(self, product_obj: Any) -> Optional[Dict[str, Dict[str, bool]]]:
        """Конвертирует product.variants → {color: {size: available}}."""
        if not isinstance(product_obj, dict):
            return None
        variants = product_obj.get("variants")
        if not isinstance(variants, list):
            return None

        stock: Dict[str, Dict[str, bool]] = {}
        for var in variants:
            if not isinstance(var, dict):
                continue
            color = (var.get("option1") or "DEFAULT")
            size = (var.get("option2") or "DEFAULT")
            available = bool(var.get("available", False))
            stock.setdefault(str(color).strip(), {})[str(size).strip()] = available
        return stock or None

    def _offers_to_stock_map(self, offers_obj: Any) -> Dict[str, Dict[str, bool]]:
        """
        Переводит JSON-LD offers → {color: {size: available}}:
          • Поддержка Offer | [Offer] | AggregateOffer
          • Парсинг name в форматах "Color / Size", "Color - Size", "Color Size"
          • Фолбэки по полям color/size/itemColor/itemSize/sku
          • availability → InStock (любой регистр)
        """

        def _split_name(name: str) -> Tuple[Optional[str], Optional[str]]:
            name = _norm_ws(name)
            if not name:
                return None, None
            for sep in (" / ", " - ", " | "):
                if sep in name:
                    a, b = name.split(sep, 1)
                    return (a or "").strip() or None, (b or "").strip() or None
            m = re.match(
                r"^(?P<color>[A-Za-z].*?)\s+(?P<size>(?:\d+|[XSML]{1,4}\+?|\w{1,4}))$",
                name,
            )
            if m:
                return m.group("color").strip(), m.group("size").strip()
            return None, None

        # Если AggregateOffer — достаём вложенные offers
        if isinstance(offers_obj, dict) and str(offers_obj.get("@type", "")).lower() == "aggregateoffer":
            offers = offers_obj.get("offers")
        else:
            offers = offers_obj

        stock: Dict[str, Dict[str, bool]] = {}
        for off in _as_list(offers):
            if not isinstance(off, dict):
                continue
            available = "instock" in str(off.get("availability", "")).lower()

            name = str(off.get("name") or "")
            c_from_name, s_from_name = _split_name(name)

            color = (c_from_name or off.get("color") or off.get("itemColor") or "").strip()
            size = (s_from_name or off.get("size") or off.get("itemSize") or "").strip()

            # sku как крайний фолбэк ("BLACK-XL" / "BLACK/XL")
            if (not color or not size) and isinstance(off.get("sku"), str):
                sku = cast(str, off["sku"])
                a, b = _split_name(sku)
                color = color or (a or "")
                size = size or (b or "")

            color = color or "DEFAULT"
            size = size or "DEFAULT"

            stock.setdefault(color, {})[size] = available

        return stock


# ===============================
# 🔧 ВСПОМОГАТЕЛЬНОЕ: мердж и нормализация селекторов
# ===============================
def _as_tuple(value: Any) -> Tuple[str, ...]:
    if value is None:
        return tuple()
    if isinstance(value, (list, tuple)):
        return tuple(str(x) for x in value if str(x).strip())
    # одиночная строка -> кортеж из одного
    s = str(value).strip()
    return (s,) if s else tuple()


def _merge_selectors_dict(
    defaults: Dict[str, Any],
    cfg_defaults: Dict[str, Any],
    brand_overrides: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Сливает словари селекторов по приоритету:
    code-defaults < parser.selectors.defaults < parser.selectors.brands.<brand>

    Неизвестные ключи игнорируются.
    """
    out: Dict[str, Any] = dict(defaults)

    def _apply(src: Dict[str, Any]) -> None:
        for key, val in (src or {}).items():
            if key not in out:
                continue
            out[key] = val

    if isinstance(cfg_defaults, dict):
        _apply(cfg_defaults)
    if isinstance(brand_overrides, dict):
        _apply(brand_overrides)
    return out


def _normalize_selectors_types(sel: Dict[str, Any]) -> Dict[str, Any]:
    """
    Приводит финальные селекторы к ожидаемым типам:
      • *_LIST → Tuple[str, ...]
      • JSON_LD_SCRIPT → str
    """
    normalized: Dict[str, Any] = dict(sel)

    normalized["TITLE_LIST"] = _as_tuple(normalized.get("TITLE_LIST"))
    normalized["PRICE_LIST"] = _as_tuple(normalized.get("PRICE_LIST"))
    normalized["MAIN_IMAGE_LIST"] = _as_tuple(normalized.get("MAIN_IMAGE_LIST"))
    normalized["ALL_IMAGES_LIST"] = _as_tuple(normalized.get("ALL_IMAGES_LIST"))
    normalized["DESCRIPTION_CONTAINER_LIST"] = _as_tuple(normalized.get("DESCRIPTION_CONTAINER_LIST"))
    normalized["LEGACY_STOCK_SELECTORS"] = _as_tuple(normalized.get("LEGACY_STOCK_SELECTORS"))

    jls = normalized.get("JSON_LD_SCRIPT")
    normalized["JSON_LD_SCRIPT"] = str(jls) if jls not in (None, "") else _DEFAULT_SELECTORS["JSON_LD_SCRIPT"]
    return normalized