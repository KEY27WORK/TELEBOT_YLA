# 🎵 app/domain/music/interfaces.py
"""
🎵 interfaces.py — доменно-інтерфейсний шар для музичних сервісів.

Призначення:
    • Визначає DTO та контракти (інтерфейси) для музичного підсистеми.
    • Забезпечує слабке зв'язування між реалізаціями (SOLID: Dependency Inversion).
    • Єдина точка імпорту типів для музичних сервісів.

Ключові рішення:
    • Жодних залежностей від інфраструктури (чистий домен).
    • Структуровані DTO (без "artist — track" у сирих рядках).
    • Узгоджено з доменом AI: використовуємо ProductPromptDTO.
"""

from __future__ import annotations

# 🔠 Системні імпорти
from dataclasses import dataclass
from typing import Optional, Protocol, Sequence, runtime_checkable

# 🧩 Внутрішні модулі проєкту
from app.domain.ai import ProductPromptDTO


# ================================
# 🏛️ DTO (Data Transfer Objects)
# ================================

@dataclass(frozen=True, slots=True)
class RecommendedTrack:
    """
    ✅ Структурований опис одного рекомендованого треку.
    """
    artist: str
    title: str

    @property
    def display_name(self) -> str:
        """Зручне представлення «Виконавець — Назва» для UI/логів."""
        return f"{self.artist} — {self.title}"


@dataclass(frozen=True, slots=True)
class MusicRecommendationResult:
    """
    📦 Результат роботи сервісу музичних рекомендацій.
    """
    tracks: Sequence[RecommendedTrack]  # зазвичай tuple[RecommendedTrack, ...]
    raw_text: str                       # сирий текст моделі (для трасування/логів)
    model: str                          # ідентифікатор/назва моделі (напр., "gpt-4o-mini")


@dataclass(frozen=True, slots=True)
class TrackInfo:
    """
    🎼 Результат завантаження/пошуку конкретного треку.
    """
    name: str                           # людиночитна назва (часто = display_name)
    file_path: Optional[str] = None     # повний шлях до локального файлу (якщо є)
    error: Optional[str] = None         # опис помилки (якщо не вдалося завантажити)


# ================================
# 🧩 ІНТЕРФЕЙСИ (КОНТРАКТИ)
# ================================

@runtime_checkable
class IMusicRecommender(Protocol):
    """
    🔎 Контракт сервісу підбору музики за даними про продукт/картинку.
    Працює на рівні доменних DTO, не знає про конкретні LLM/SaaS.
    """

    async def recommend(self, product: ProductPromptDTO) -> MusicRecommendationResult:
        """
        Згенерувати добірку треків на основі вхідних метаданих продукту.

        Args:
            product: ProductPromptDTO з title/description/image_url.

        Returns:
            MusicRecommendationResult: структуровані треки + сирий вихід моделі.
        """
        ...


@runtime_checkable
class IMusicDownloader(Protocol):
    """
    ⬇️ Контракт сервісу завантаження треків (пошук і збереження локально).
    """

    async def download(self, track: RecommendedTrack) -> TrackInfo:
        """
        Завантажити трек на основі структурованих метаданих.

        Args:
            track: RecommendedTrack {artist, title}.

        Returns:
            TrackInfo: шлях до файлу або опис помилки.
        """
        ...


@runtime_checkable
class IMusicFileManager(Protocol):
    """
    🗃️ Контракт менеджера файлового кешу музики.
    """

    def get_cached_path(self, track: RecommendedTrack) -> Optional[str]:
        """
        Перевірити, чи є вже завантажений трек у кеші.

        Args:
            track: RecommendedTrack.

        Returns:
            Повний шлях до файлу або None, якщо відсутній.
        """
        ...

    async def clear_cache(self) -> None:
        """Асинхронне очищення кешу музичних файлів."""
        ...


# ================================
# 📦 ПУБЛІЧНИЙ API МОДУЛЯ
# ================================
__all__ = [
    # DTO
    "RecommendedTrack",
    "MusicRecommendationResult",
    "TrackInfo",
    # Interfaces
    "IMusicRecommender",
    "IMusicDownloader",
    "IMusicFileManager",
]