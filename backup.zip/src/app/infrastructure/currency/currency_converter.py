# 💱 app/infrastructure/currency/currency_converter.py
"""
Чистый stateless-конвертер, работающий со «снимком» курсов в Decimal:
{"USD": Decimal("40.50"), "EUR": Decimal("44.00"), "UAH": Decimal("1")}

Реализует:
- IMoneyConverter (Decimal API) — точные расчёты + параметризуемая стратегия округления.
- ICurrencyConverter (float API) — обратная совместимость (вход/выход float, внутри Decimal).

По умолчанию используется банковское округление (ROUND_HALF_EVEN / BANKERS).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_EVEN, InvalidOperation
from typing import Dict, Mapping, Union

from app.domain.currency.interfaces import (
    ICurrencyConverter,
    IMoneyConverter,
    Money,
    CurrencyCode,
    CurrencyRateNotFoundError,
)
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)

# Сколько знаков после запятой отображать/квантовать для валют
_CCY_DECIMALS: Dict[str, int] = {
    "UAH": 2,
    "USD": 2,
    "EUR": 2,
    "GBP": 2,
    "PLN": 2,
    # "JPY": 0, ...
}


def _to_decimal(value: object) -> Decimal:
    """Безопасно приводит значение к Decimal через строку (избегая артефактов float)."""
    if isinstance(value, Decimal):
        return value
    try:
        return Decimal(str(value).strip())
    except (InvalidOperation, AttributeError, ValueError) as e:
        raise ValueError(f"Невалидное числовое значение: {value!r}") from e


def _quantum_for_currency(currency: str) -> Decimal:
    digits = _CCY_DECIMALS.get(currency.upper(), 2)
    return Decimal(1).scaleb(-digits)  # 10^-digits


def _quantize(amount: Decimal, currency: str, rounding: str) -> Decimal:
    return amount.quantize(_quantum_for_currency(currency), rounding=rounding)


@dataclass(frozen=True)
class _Ctx:
    """Контекст вычислений: слепок курсов и стратегия округления."""
    rates: Dict[str, Decimal]
    rounding: str


class CurrencyConverter(ICurrencyConverter, IMoneyConverter):
    """
    Синхронная конвертация на базе снимка курсов в Decimal.

    Внутри всё в Decimal. Легаси-метод convert(float, ...) — это тонкая обёртка над
    точным путём с понижением точности только на границе (возврат float).
    """

    _ctx: _Ctx

    def __init__(
        self,
        rates: Mapping[str, Union[Decimal, int, float, str]],
        *,
        rounding: str = ROUND_HALF_EVEN,
    ) -> None:
        if not isinstance(rates, Mapping):
            raise TypeError("rates должен быть Mapping[str, Decimal|int|float|str].")

        # Нормализуем ключи и значения
        norm: Dict[str, Decimal] = {}
        for k, v in (rates or {}).items():
            ccy = (k or "").upper().strip()
            if not ccy:
                continue
            norm[ccy] = _to_decimal(v)

        # Базовая валюта — гарантируем наличие
        if "UAH" not in norm:
            norm["UAH"] = Decimal("1")

        object.__setattr__(self, "_ctx", _Ctx(rates=norm, rounding=rounding))

    # ====== Вспомогательная точная конвертация в Decimal ======
    def _convert_decimal(self, amount: Decimal, from_currency: str, to_currency: str) -> Decimal:
        f = (from_currency or "").upper()
        t = (to_currency or "").upper()

        if f == t:
            return _quantize(amount, t, self._ctx.rounding)

        try:
            from_rate_to_uah = self._ctx.rates[f]
            to_rate_from_uah = self._ctx.rates[t]
        except KeyError:
            raise CurrencyRateNotFoundError(f, t)

        if to_rate_from_uah == 0:
            raise ValueError(f"Нулевой курс для валюты: {t}")

        amount_in_uah = amount * from_rate_to_uah
        dest_amount = amount_in_uah / to_rate_from_uah
        return _quantize(dest_amount, t, self._ctx.rounding)

    # ====== Новый точный API (Decimal) ======
    def convert_money(self, money: Money, to_currency: CurrencyCode) -> Money:
        amount_dec = _to_decimal(money.amount)
        to_ccy = str(to_currency).upper()
        out = self._convert_decimal(amount_dec, str(money.currency), to_ccy)
        return Money(amount=out, currency=CurrencyCode(to_ccy))

    # ====== Легаси-API (float) — обратная совместимость ======
    def convert(self, amount: float, from_currency: str, to_currency: str) -> float:
        amount_dec = _to_decimal(amount)
        out_dec = self._convert_decimal(amount_dec, from_currency, to_currency)
        return float(out_dec)