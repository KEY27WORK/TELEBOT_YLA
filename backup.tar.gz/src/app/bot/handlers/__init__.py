# 🤖 app/bot/handlers/__init__.py
"""
🤖 Пакет `handlers` — глобальні та наскрізні обробники Telegram-бота.

📌 Призначення:
– Інкапсулює зв'язки між обробниками, що не належать окремим фічам.
– Забезпечує єдину публічну точку доступу до ключових класів пакета.
– Допомагає IDE/лізерів коду з автодоповненням через `__all__`.

⚠️ Публічно "піднімаємо" лише основні класи, решта — внутрішня реалізація.
"""

# 🌐 Зовнішні бібліотеки — відсутні

# 🔠 Системні імпорти — відсутні

# 🧩 Внутрішні модулі проєкту
from .callback_handler import CallbackHandler							# 🔗 Обробка callback-ів (inline-кнопки)
from .link_handler import LinkHandler								# 🔗 Маршрутизація та обробка посилань
from .size_chart_handler_bot import SizeChartHandlerBot					# 📏 Робота з таблицями розмірів

# 🛍️ Обробники товарів і колекцій
from .product.product_handler import ProductHandler						# 🛍️ Обробка сторінки окремого товару
from .product.collection_handler import CollectionHandler					# 📚 Обробка сторінок колекцій

# ================================
# 📦 ПУБЛІЧНИЙ ІНТЕРФЕЙС ПАКЕТА
# ================================
__all__ = [
    "CallbackHandler", 										# 🔗 Inline-кнопки / CallbackQuery
    "LinkHandler", 											# 🔗 Роутінг лінків та перевірки
    "SizeChartHandlerBot", 									# 📏 Парсинг та надсилання size chart
    "ProductHandler", 										# 🛍️ Обробка товарів (парсинг + повідомлення)
    "CollectionHandler", 									# 📚 Обхід/парсинг колекцій
]

