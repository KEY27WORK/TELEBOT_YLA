# 📁 app/assets/fonts

Сюди покладіть файли шрифтів, які будуть **завжди доступні** на будь-якому сервері/контейнері.

Рекомендовано:
- `Roboto-Bold.ttf`
- `RobotoMono-Regular.ttf`

Якщо цих файлів немає:
- `FontService` спробує знайти шрифти у системних шляхах (Linux/macOS/Windows).
- Якщо і там немає — використає вбудований шрифт Pillow (`ImageFont.load_default()`).

> За потреби шляхи можна явно задати у конфігу:
>
> ```yaml
> image_generation:
>   font_paths:
>     bold:
>       - "/opt/fonts/YourBold.ttf"
>     mono:
>       - "/opt/fonts/YourMono.ttf"
> ```