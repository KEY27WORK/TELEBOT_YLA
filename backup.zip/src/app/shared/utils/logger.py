# app/shared/utils/logger.py
"""
🧰 logger.py — Единая схема логирования для всего приложения (IMP-007).

• init_logging(...): инициализация корневого логера
• init_logging_from_config(dict): обёртка для ConfigService
• get_logger(suffix): возвращает дочерний логер "<LOG_NAME>.<suffix>"
"""

from __future__ import annotations

import json
import logging
import sys
import threading
from dataclasses import dataclass, field
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Any, Dict, Optional

# ── Константы ─────────────────────────────────────────────────────────
LOG_NAME: str = "telebot_ukraine_v2"
PLAIN_FORMAT: str = "%(asctime)s [%(levelname)s] - (%(name)s).%(funcName)s(%(lineno)d) - %(message)s"

_lock = threading.Lock()


# ── DTO конфигурации ──────────────────────────────────────────────────
@dataclass
class LoggingConfig:
    level: str = "INFO"
    console: bool = True
    json: bool = False
    file: str = "logs/bot.log"
    when: str = "midnight"
    interval: int = 1
    backup_count: int = 7
    encoding: str = "utf-8"
    # ✅ не Optional: сразу дефолт — пустой dict
    suppress: Dict[str, str] = field(default_factory=dict)  # {"urllib3": "WARNING", "playwright": "WARNING"}


# ── Форматтеры ────────────────────────────────────────────────────────
class JsonFormatter(logging.Formatter):
    """Простой JSON-форматтер: плоские поля + message/level/time/name/module/line."""
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "time": self.formatTime(record, datefmt="%Y-%m-%d %H:%M:%S"),
            "level": record.levelname,
            "name": record.name,
            "module": record.module,
            "func": record.funcName,
            "line": record.lineno,
            "message": record.getMessage(),
        }
        # Добавим extras (если передавались через extra={...})
        for k, v in record.__dict__.items():
            if k.startswith("_") or k in (
                "args", "asctime", "created", "exc_info", "exc_text", "filename",
                "levelno", "lineno", "module", "msecs", "message", "msg",
                "name", "pathname", "process", "processName", "relativeCreated",
                "stack_info", "thread", "threadName", "levelname", "funcName",
            ):
                continue
            if k not in payload:
                try:
                    json.dumps(v)  # проверка сериализуемости
                    payload[k] = v
                except Exception:
                    payload[k] = str(v)
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def _make_console_handler(fmt: logging.Formatter) -> logging.Handler:
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(fmt)
    return h


def _make_file_handler(cfg: LoggingConfig, fmt: logging.Formatter) -> logging.Handler:
    log_path = Path(cfg.file)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    h = TimedRotatingFileHandler(
        filename=cfg.file,
        when=cfg.when,
        interval=cfg.interval,
        backupCount=cfg.backup_count,
        encoding=cfg.encoding,
    )
    h.setFormatter(fmt)
    return h


def _suppress_third_party(suppress: Dict[str, str]) -> None:
    for name, level in (suppress or {}).items():
        value = getattr(logging, str(level).upper(), logging.WARNING)
        logging.getLogger(name).setLevel(value)


# ── Публичный API ─────────────────────────────────────────────────────
def init_logging(
    *,
    level: Optional[str] = None,
    console: Optional[bool] = None,
    json_mode: Optional[bool] = None,
    file: Optional[str] = None,
    suppress: Optional[Dict[str, str]] = None,
) -> logging.Logger:
    """Инициализация корневого логера приложения по единой схеме."""
    with _lock:
        cfg = LoggingConfig(
            level=level or "INFO",
            console=True if console is None else bool(console),
            json=False if json_mode is None else bool(json_mode),
            file=file or "logs/bot.log",
            suppress=suppress or {},  # гарантируем dict
        )

        root = logging.getLogger(LOG_NAME)
        root.setLevel(getattr(logging, cfg.level.upper(), logging.INFO))

        # Чистим только свои хендлеры
        for h in list(root.handlers):
            if isinstance(h, (logging.StreamHandler, TimedRotatingFileHandler)):
                root.removeHandler(h)

        fmt: logging.Formatter = JsonFormatter() if cfg.json else logging.Formatter(PLAIN_FORMAT)

        if cfg.console:
            root.addHandler(_make_console_handler(fmt))
        root.addHandler(_make_file_handler(cfg, fmt))

        _suppress_third_party(cfg.suppress)

        root.info(
            "✅ Logging initialized | level=%s console=%s json=%s file=%s",
            cfg.level.upper(),
            "ON" if cfg.console else "OFF",
            "ON" if cfg.json else "OFF",
            cfg.file,
        )
        return root


def init_logging_from_config(config: Dict[str, Any]) -> logging.Logger:
    """
    Обёртка: принимает dict из ConfigService().get('logging') и вызывает init_logging().
    Ожидаем структуру:
      logging:
        level: "INFO"
        console: true
        json: false
        file: "logs/bot.log"
        suppress:
          urllib3: "WARNING"
          playwright: "WARNING"
    """
    node = config or {}
    return init_logging(
        level=node.get("level"),
        console=node.get("console"),
        json_mode=node.get("json"),
        file=node.get("file"),
        suppress=node.get("suppress"),
    )


def get_logger(suffix: Optional[str] = None) -> logging.Logger:
    """Возвращает дочерний логер с единым префиксом LOG_NAME."""
    name = LOG_NAME if not suffix else f"{LOG_NAME}.{suffix}"
    return logging.getLogger(name)