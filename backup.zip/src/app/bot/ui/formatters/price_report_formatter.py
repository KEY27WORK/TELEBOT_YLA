# 🧾 app/bot/ui/formatters/price_report_formatter.py
"""
🧾 price_report_formatter.py — Форматер повідомлення з розрахунком ціни для Telegram.

Працює з НОВИМ доменним API (чиста презентація, без бізнес‑логіки):
  PriceInput → PriceBreakdown (IPriceService.build_quote)

🔹 Призначення:
- Перетворює доменні DTO у лаконічний текст повідомлення для Telegram.
- Дбає про коректне відображення валют та сум.
- Опціонально додає довідковий USD‑рядок для UAH‑звітів (best‑effort).

⚠️ Важливо:
- ЖОДНИХ обчислень всередині — лише форматування вже підготовлених даних.
"""

from __future__ import annotations

# 🔠 Системні імпорти
from typing import Final, Union, Protocol, runtime_checkable, cast			# 🧰 Типізація, протоколи та приведення типів
from decimal import Decimal												# 🔢 Десяткова арифметика для грошей

# 🧩 Внутрішні модулі проєкту
# ⚠️ У проєкті можуть співіснувати ДВІ декларації Money (у currency.interfaces і pricing.interfaces).
#    Щоб уникнути конфлікту типів у статичній перевірці (Pylance/mypy), приймаємо «структурний» тип MoneyLike.
from app.domain.currency.interfaces import (								# 💱 Інтерфейси/DTO валют (новий Decimal‑перший API)
    ICurrencyConverter,
    IMoneyConverter,
    Money as CurrencyMoney,
    CurrencyCode,
)
from app.domain.pricing.interfaces import PriceInput, PriceBreakdown		# 💸 Доменні DTO для ціноутворення
from app.domain.products.entities import ProductInfo						# 🛍 DTO товару для заголовку


# ================================
# 🧾 ПРОТОКОЛ ДЛЯ УНІФІКАЦІЇ MONEY
# ================================
@runtime_checkable
class MoneyLike(Protocol):
    """
    Мінімальний контракт для грошового DTO.

    🔹 Використовуємо властивості (read‑only), бо наші Money з domain можуть бути frozen (dataclass(frozen=True)),
       інакше Pylance скаржиться, що у протоколі атрибути «записні», а в реальному типі — тільки для читання.
    """

    @property
    def amount(self) -> Decimal: ...										# 📌 Сума (Decimal)

    @property
    def currency(self) -> Union[str, CurrencyCode]: ...						# 📌 Код валюти ("UAH"/"USD"/...)


# ================================
# 🧾 КЛАС ФОРМАТЕРА
# ================================
class PriceReportFormatter:
    """
    🧾 Форматує квоту ціни у читабельне Telegram‑повідомлення.

    Особливості:
    - Однорідний вигляд сум та валют.
    - Опціональний довідковий USD‑рядок (для UAH).
    """

    _BULLET: Final[str] = "•"												# 🔹 Маркер списку для рядків розбивки

    # ================================
    # 🔤 ДОПОМІЖНЕ ФОРМАТУВАННЯ
    # ================================
    @staticmethod
    def _fmt_money(m: MoneyLike) -> str:
        """
        Повертає суму у форматі: '123.45 UAH'.

        Args:
            m: Будь‑який об’єкт із властивостями amount: Decimal та currency: str/CurrencyCode.

        Returns:
            Рядок із завжди 2 знаками після коми.
        """
        return f"{m.amount:.2f} {str(m.currency)}"							# 🧮 Фіксуємо 2 знаки після коми

    @staticmethod
    def _ref_usd_line(total: MoneyLike, conv: Union[ICurrencyConverter, IMoneyConverter]) -> str | None:
        """
        Будує довідковий рядок з еквівалентом у USD (best‑effort) для UAH‑тотала.

        Підтримує:
        - Новий IMoneyConverter (Money → Money) ІЗ currency.interfaces.
        - Легасі ICurrencyConverter (float → float) — результат нормалізуємо у Decimal.

        Повертає None, якщо конверсія недоступна або сталася помилка.

        💡 Типізація:
        - Приймаємо `MoneyLike`, щоб не «зштовхувати» різні реалізації Money.
        - Для нового конвертера створюємо `CurrencyMoney` із currency.interfaces локально.
        """
        try:
            if str(total.currency) == "UAH":									# 🎯 Референсний USD показуємо лише для гривні
                # ВАРІАНТ 1: новий IMoneyConverter (має метод convert_money)
                if hasattr(conv, "convert_money"):								# 🔎 Ознака нового API
                    mconv = cast(IMoneyConverter, conv)							# 🧷 Підказуємо типізатору точний протокол
                    src_money = CurrencyMoney(									# 🧱 Локально будуємо Money для конвертера
                        amount=Decimal(total.amount),
                        currency=cast(CurrencyCode, "UAH"),
                    )
                    usd_money = mconv.convert_money(src_money, cast(CurrencyCode, "USD"))	# 💱 Money(UAH) → Money(USD)
                    usd_amount = usd_money.amount								# 🧮 Decimal amount
                else:
                    # ВАРІАНТ 2: легасі ICurrencyConverter (float API)
                    fconv = cast(ICurrencyConverter, conv)						# 🧷 Звужуємо до легасі‑інтерфейсу
                    usd_amount = fconv.convert(float(total.amount), "UAH", "USD")	# 🔁 float → float
                    if not isinstance(usd_amount, Decimal):						# 🧷 Стандартизуємо тип
                        usd_amount = Decimal(str(usd_amount))						# 🔒 Безпечно загортаємо у Decimal
                return f"≈ {usd_amount:.2f} USD (довідково)"						# 👁 Референс для візуального контролю
        except Exception:
            return None														# 🤷 best‑effort: у разі збою просто не додаємо рядок
        return None

    # ================================
    # 🏗️ ПУБЛІЧНЕ API
    # ================================
    def format_message(
        self,
        product: ProductInfo,
        details: PriceBreakdown,
        price_input: PriceInput,
        converter: Union[ICurrencyConverter, IMoneyConverter],				# 🔌 Може знадобитися для довідкових рядків
    ) -> str:
        """
        Будує фінальне повідомлення для Telegram (HTML‑режим).

        Args:
            product: DTO товару для заголовку.
            details: Розбивка ціни (усі суми вже у target_currency).
            price_input: Вхідні параметри прайсингу (містить target_currency).
            converter: Активний конвертер валют (новий або легасі).

        Returns:
            Готовий HTML‑рядок повідомлення.
        """
        lines = [
            f"🛍 <b>{product.title}</b>",									# 🏷 Заголовок із назвою товару
            "",
            f"💱 Валюта звіту: <b>{price_input.target_currency}</b>",					# 💱 Поточна валюта розрахунку
            "",
            "💸 <b>Прайс-квота</b>",										# 📊 Заголовок блоку розбивки
            f"{self._BULLET} База: {self._fmt_money(details.base_converted)}",		# 💵 Базова ціна після конвертації
            f"{self._BULLET} Доставка: {self._fmt_money(details.shipping)}",			# 🚚 Доставка
            f"{self._BULLET} Комісія: {self._fmt_money(details.commission)}",		# 🧾 Комісія
            f"{self._BULLET} Знижка: −{self._fmt_money(details.discount)}",		# 🎁 Знижка (показуємо зі знаком мінус)
            f"{self._BULLET} Сума до округлення: {self._fmt_money(details.total_before_round)}",  # 🧮 Проміжний підсумок
            "",
            f"✅ <b>Разом до оплати: {self._fmt_money(details.total)}</b>",			# ✅ Фінальна сума
        ]

        # Додатковий референс у USD для UAH‑тотала — допомагає швидко звірити еквівалент
        ref = self._ref_usd_line(details.total, converter)							# 🔎 Спроба порахувати USD‑еквівалент
        if ref:
            lines.append(ref)												# ➕ Додаємо рядок наприкінці

        return "\n".join(lines)												# 🧵 Склеюємо рядки у готове повідомлення