# app/infrastructure/collection_processing/collection_processing_service.py
"""
Сервис извлекает ссылки на товары со страницы коллекции:
— валидирует и нормализует URL,
— создаёт провайдер через фабрику,
— отдаёт список нормализованных Url.
"""

from __future__ import annotations

import logging
from typing import List

from app.shared.utils.logger import LOG_NAME
from app.shared.utils.url_parser_service import UrlParserService
from app.errors.custom_errors import AppError, ParsingError

from app.domain.products.entities import Url
from app.domain.products.interfaces import (
    ICollectionProcessingService,
    ICollectionLinksProvider,
)
from app.infrastructure.parsers.contracts import IParserFactory

logger = logging.getLogger(LOG_NAME)


class CollectionProcessingService(ICollectionProcessingService):
    """
    ⚙️ Оркестратор для витягування посилань із колекції.

    Алгоритм:
      1) normalize(raw_url) → str
      2) is_collection_url(...)
      3) factory.create_collection_provider(Url)
      4) provider.get_product_links() → List[Url]
    """

    def __init__(self, *, parser_factory: IParserFactory, url_parser: UrlParserService) -> None:
        self._factory = parser_factory
        self._urls = url_parser

    async def get_product_links(self, raw_url: str) -> List[Url]:
        logger.info("⚙️ Старт парсингу колекції: %s", raw_url)

        try:
            # 1) Нормалізація та груба перевірка
            normalized = self._urls.normalize(raw_url)
            if not self._urls.is_collection_url(normalized):
                raise ParsingError("Посилання не є сторінкою колекції", url=raw_url)

            url = Url(normalized)

            # 2) Провайдер посилань через фабрику
            provider: ICollectionLinksProvider = self._factory.create_collection_provider(url)

            # 3) Отримуємо посилання
            links: List[Url] = await provider.get_product_links()

            if not links:
                logger.warning("⚠️ Порожня колекція або не знайдені товари: %s", normalized)
            else:
                logger.info("✅ Знайдено посилань: %d (колекція: %s)", len(links), normalized)

            return links

        except AppError as e:
            logger.error(
                "❌ Помилка обробки колекції: %s",
                getattr(e, "message", str(e)),
                extra={"url": raw_url},
            )
            raise
        except Exception as e:
            logger.exception("🔥 Непередбачена помилка під час парсингу: %s", raw_url)
            raise ParsingError(
                "Не вдалося обробити сторінку колекції.",
                details=str(e),
                url=raw_url,
            ) from e


__all__ = ["CollectionProcessingService"]