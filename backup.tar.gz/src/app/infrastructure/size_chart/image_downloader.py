from __future__ import annotations

"""
Асинхронная и безопасная загрузка изображений.

Возможности:
- Ограничение размера (по Content-Length и по накапливаемым байтам)
- Атомарная запись: пишем во временный .part в той же директории → os.replace()
- Валидации: Content-Type (image/*) + сигнатуры (PNG/JPEG/GIF/WebP)
- Стриминг (httpx.stream) + таймауты + follow_redirects
- Ретраи с экспоненциальным backoff и лёгким джиттером
- Опциональный подсчёт sha256

Результат:
- Успех → DownloadResult
- Отказ → DownloadError (enum с причинами, согласовано со steps IMP-009)
- И download(...), и download_info(...) возвращают Union[DownloadResult, DownloadError].

Дополнительно (сахар):
- Структурированные поля в логах: extra={"download_error": <reason>}
- Опциональные метрики Prometheus: download_errors_total{reason}, download_ok_total
"""

import asyncio
import hashlib
import logging
import os
import tempfile
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Iterable, Optional, Tuple, Union

import httpx

# ── Prometheus (опционально) ──────────────────────────────────────────────
try:
    from prometheus_client import Counter  # type: ignore
except Exception:  # pragma: no cover
    Counter = None  # type: ignore

from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(f"{LOG_NAME}.downloader")

# ── Метрики (если prometheus_client доступен) ─────────────────────────────
if Counter:
    DOWNLOAD_ERRORS_TOTAL = Counter(
        "download_errors_total",
        "Количество ошибок загрузки изображений по причинам",
        ["reason"],
    )
    DOWNLOAD_OK_TOTAL = Counter(
        "download_ok_total",
        "Количество успешных загрузок изображений",
    )
else:  # заглушки
    DOWNLOAD_ERRORS_TOTAL = None  # type: ignore
    DOWNLOAD_OK_TOTAL = None      # type: ignore


def _inc_error(reason: str) -> None:
    if DOWNLOAD_ERRORS_TOTAL:
        try:
            DOWNLOAD_ERRORS_TOTAL.labels(reason=reason).inc()
        except Exception:
            pass


def _inc_ok() -> None:
    if DOWNLOAD_OK_TOTAL:
        try:
            DOWNLOAD_OK_TOTAL.inc()
        except Exception:
            pass


# ────────────────────────────────────────────────────────────────────────────
# Константы/настройки по умолчанию
# ────────────────────────────────────────────────────────────────────────────

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; SizeChartBot/1.0; +https://example.org/bot)",
    "Accept": "image/avif,image/webp,image/apng,image/*;q=0.8,*/*;q=0.5",
}
DEFAULT_CT_PREFIXES: Tuple[str, ...] = ("image/",)


# ────────────────────────────────────────────────────────────────────────────
# DTO результата и коды ошибок
# ────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class DownloadResult:
    path: Path
    content_type: str
    content_length: Optional[int]
    bytes_written: int
    sha256: Optional[str]


class DownloadError(Enum):
    """Именованные причины отказа загрузки (steps IMP-009)."""
    HTTP_STATUS = "http_status"          # неуспешный HTTP-статус
    TOO_LARGE = "too_large"              # превышен лимит размера
    NOT_IMAGE = "not_image"              # Content-Type не image/* и магию не проверяем
    MAGIC_MISMATCH = "magic_mismatch"    # сигнатура «не похоже на изображение»
    IO_ERROR = "io_error"                # локальная ошибка ввода-вывода
    EMPTY_BODY = "empty_body"            # тело ответа нулевой длины
    UNKNOWN = "unknown"                  # непредвиденная ошибка


DownloadOutcome = Union[DownloadResult, DownloadError]


# ────────────────────────────────────────────────────────────────────────────
# Собственно загрузчик
# ────────────────────────────────────────────────────────────────────────────

class ImageDownloader:
    """Асинхронная загрузка изображений с защитами и стримингом."""

    def __init__(
        self,
        *,
        timeout_s: float = 30.0,
        headers: Optional[dict] = None,
        ct_prefixes: Iterable[str] = DEFAULT_CT_PREFIXES,
        max_bytes: int = 20 * 1024 * 1024,      # 20 MB
        max_attempts: int = 3,
        backoff_base_s: float = 1.0,
        verify_magic: bool = True,
        compute_sha256: bool = False,
        chunk_size: int = 64 * 1024,            # 64 KB
    ) -> None:
        self.timeout_s = float(timeout_s)
        self.headers = {**DEFAULT_HEADERS, **(headers or {})}
        self.ct_prefixes = tuple(ct_prefixes)
        self.max_bytes = int(max_bytes)
        self.max_attempts = max(1, int(max_attempts))
        self.backoff_base_s = float(backoff_base_s)
        self.verify_magic = bool(verify_magic)
        self.compute_sha256 = bool(compute_sha256)
        self.chunk_size = int(chunk_size)

    # ── Единое API: возвращаем Union для строгого логирования по коду ──────
    async def download(self, img_url: str, output_path: Path) -> DownloadOutcome:
        """Короткая обёртка над download_info(...), но со строго типизированным outcome."""
        return await self.download_info(img_url, output_path)

    # ── Подробная версия: типизированный outcome ──────────────────────────
    async def download_info(self, img_url: str, output_path: Path) -> DownloadOutcome:
        """
        Возвращает DownloadResult (успех) либо DownloadError (причина отказа).
        Реализует ретраи самостоятельно (без HEAD-запросов).
        """
        if not img_url:
            logger.error("❌ URL изображения отсутствует", extra={"download_error": DownloadError.UNKNOWN.value})
            _inc_error(DownloadError.UNKNOWN.value)
            return DownloadError.UNKNOWN

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        for attempt in range(1, self.max_attempts + 1):
            tmp_path: Optional[Path] = None
            try:
                timeout = httpx.Timeout(self.timeout_s)
                async with httpx.AsyncClient(
                    headers=self.headers,
                    timeout=timeout,
                    follow_redirects=True,
                ) as client:
                    async with client.stream("GET", img_url) as resp:
                        # HTTP статус
                        try:
                            resp.raise_for_status()
                        except httpx.HTTPStatusError as e:
                            code = getattr(e.response, "status_code", None)
                            logger.warning(
                                "🌐 HTTP %s при загрузке %s [attempt %s/%s]",
                                code, img_url, attempt, self.max_attempts,
                                extra={"download_error": DownloadError.HTTP_STATUS.value, "http_status": code},
                            )
                            _inc_error(DownloadError.HTTP_STATUS.value)
                            return DownloadError.HTTP_STATUS

                        ct = (resp.headers.get("Content-Type") or "").lower().strip()
                        cl_header = resp.headers.get("Content-Length")
                        content_length = int(cl_header) if cl_header and cl_header.isdigit() else None

                        # Жёсткий лимит по Content-Length
                        if content_length is not None and content_length > self.max_bytes:
                            logger.error(
                                "❌ Файл слишком большой: %s B > лимита %s B (%s)",
                                content_length, self.max_bytes, img_url,
                                extra={"download_error": DownloadError.TOO_LARGE.value, "content_length": content_length},
                            )
                            _inc_error(DownloadError.TOO_LARGE.value)
                            return DownloadError.TOO_LARGE

                        # Базовая проверка Content-Type
                        if not any(ct.startswith(p) for p in self.ct_prefixes):
                            # если разрешена проверка магии — продолжаем; иначе сразу NOT_IMAGE
                            if not self.verify_magic:
                                logger.error(
                                    "❌ Невалидный Content-Type (%s) для %s",
                                    ct or "n/a", img_url,
                                    extra={"download_error": DownloadError.NOT_IMAGE.value, "content_type": ct or "n/a"},
                                )
                                _inc_error(DownloadError.NOT_IMAGE.value)
                                return DownloadError.NOT_IMAGE

                        # Временный файл для атомарной записи
                        fd, tmp_name = tempfile.mkstemp(
                            prefix=output_path.name + ".", suffix=".part", dir=str(output_path.parent)
                        )
                        os.close(fd)
                        tmp_path = Path(tmp_name)

                        hasher = hashlib.sha256() if self.compute_sha256 else None
                        bytes_written = 0
                        first_chunk_checked = False

                        try:
                            with tmp_path.open("wb") as f:
                                async for chunk in resp.aiter_bytes(self.chunk_size):
                                    if not chunk:
                                        continue

                                    # Проверка сигнатуры на первом куске
                                    if self.verify_magic and not first_chunk_checked:
                                        first_chunk_checked = True
                                        if not self._looks_like_image(chunk):
                                            logger.error(
                                                "❌ Сигнатура не похожа на изображение (%s)",
                                                img_url,
                                                extra={"download_error": DownloadError.MAGIC_MISMATCH.value},
                                            )
                                            _inc_error(DownloadError.MAGIC_MISMATCH.value)
                                            return DownloadError.MAGIC_MISMATCH

                                    bytes_written += len(chunk)
                                    if bytes_written > self.max_bytes:
                                        logger.error(
                                            "❌ Превышен лимит размера: %s B > %s B (%s)",
                                            bytes_written, self.max_bytes, img_url,
                                            extra={"download_error": DownloadError.TOO_LARGE.value, "bytes_written": bytes_written},
                                        )
                                        _inc_error(DownloadError.TOO_LARGE.value)
                                        return DownloadError.TOO_LARGE

                                    try:
                                        f.write(chunk)
                                    except Exception:
                                        logger.exception(
                                            "❌ Ошибка записи файла (%s)",
                                            tmp_path,
                                            extra={"download_error": DownloadError.IO_ERROR.value},
                                        )
                                        _inc_error(DownloadError.IO_ERROR.value)
                                        return DownloadError.IO_ERROR

                                    if hasher:
                                        hasher.update(chunk)
                        finally:
                            # cleanup делаем ниже, если replace не сработал
                            pass

                        if bytes_written == 0:
                            logger.error(
                                "❌ Пустой ответ при загрузке %s",
                                img_url,
                                extra={"download_error": DownloadError.EMPTY_BODY.value},
                            )
                            _inc_error(DownloadError.EMPTY_BODY.value)
                            return DownloadError.EMPTY_BODY

                        # Атомарная замена
                        try:
                            os.replace(tmp_path, output_path)
                            tmp_path = None  # чтобы не удалили ниже
                        except Exception:
                            logger.exception(
                                "❌ Ошибка атомарной замены %s → %s",
                                tmp_path, output_path,
                                extra={"download_error": DownloadError.IO_ERROR.value},
                            )
                            _inc_error(DownloadError.IO_ERROR.value)
                            return DownloadError.IO_ERROR

                        sha_hex = hasher.hexdigest() if hasher else None
                        logger.info(
                            "✅ Изображение сохранено: %s (%s B, %s)",
                            output_path, bytes_written, ct or "n/a",
                            extra={"download_status": "ok", "bytes_written": bytes_written, "content_type": ct or "n/a"},
                        )
                        _inc_ok()
                        return DownloadResult(
                            path=output_path,
                            content_type=ct,
                            content_length=content_length,
                            bytes_written=bytes_written,
                            sha256=sha_hex,
                        )

            except httpx.HTTPError as e:
                code = getattr(getattr(e, "response", None), "status_code", None)
                logger.warning(
                    "🌐 HTTP ошибка (%s) при загрузке %s [attempt %s/%s]",
                    code, img_url, attempt, self.max_attempts,
                    extra={"download_error": DownloadError.HTTP_STATUS.value, "http_status": code},
                )
                # даём шанс ретраю; финальное решение — после цикла
            except Exception as e:
                logger.warning(
                    "⚠️ Неожиданная ошибка загрузки %s [attempt %s/%s]: %s",
                    img_url, attempt, self.max_attempts, e,
                    extra={"download_error": DownloadError.UNKNOWN.value},
                )
                # тоже ретраим
            finally:
                # Чистим временный .part, если он остался
                if tmp_path and tmp_path.exists():
                    try:
                        tmp_path.unlink(missing_ok=True)
                    except Exception:
                        pass

            # backoff + лёгкий джиттер перед следующей попыткой
            if attempt < self.max_attempts:
                delay = self.backoff_base_s * attempt + (0.1 * attempt)
                await asyncio.sleep(delay)

        logger.error(
            "❌ Не удалось скачать изображение после %s попыток: %s",
            self.max_attempts, img_url,
            extra={"download_error": DownloadError.HTTP_STATUS.value},
        )
        _inc_error(DownloadError.HTTP_STATUS.value)
        return DownloadError.HTTP_STATUS  # финальный код по умолчанию

    # ────────────────────────────────────────────────────────────────────────
    # Утилиты
    # ────────────────────────────────────────────────────────────────────────
    @staticmethod
    def _looks_like_image(first_bytes: bytes) -> bool:
        """Проверка сигнатур PNG/JPEG/GIF/WebP."""
        b = first_bytes[:16]
        if b.startswith(b"\x89PNG\r\n\x1a\n"):  # PNG
            return True
        if b.startswith(b"\xFF\xD8"):           # JPEG
            return True
        if b.startswith(b"GIF8"):               # GIF
            return True
        # WEBP: 'RIFF' .... 'WEBP'
        if len(b) >= 12 and b[:4] == b"RIFF" and b[8:12] == b"WEBP":
            return True
        return False