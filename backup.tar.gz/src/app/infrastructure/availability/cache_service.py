# 💾 app/infrastructure/availability/cache_service.py
"""
💾 cache_service.py — In‑memory кеш із простим TTL.

Особенности:
- Потокобезпечний (thread‑safe) завдяки RLock — не прив’язаний до asyncio event loop.
- Зворотно сумісний інтерфейс: get(key, ttl) / set(key, data).
- Монотонний годинник для TTL (стійко до зміни системного часу).
- Підтримка TTL як int/float секунд або datetime.timedelta.
- Додаткові утиліти: set_with_ttl, get_or_set, invalidate, clear, prune_expired, stats.
- Розширена статистика: last_prune_at (epoch seconds) і лічильник evictions.

Примітка:
Семантика сумісна з попередньою версією: якщо item записаний без фіксованого expires_at,
то під час get(key, ttl) застосовується TTL «на читанні».
"""

from __future__ import annotations

# 🔠 Системні імпорти
from dataclasses import dataclass
from datetime import timedelta
import time
from threading import RLock
from typing import Any, Callable, Dict, Optional, Union, TypeVar, Generic

T = TypeVar("T")


# ================================
# ⏱️ Допоміжні утиліти часу/TTL
# ================================
def _now() -> float:
    """Поточний монотонний час (секунди)."""
    return time.monotonic()


def _normalize_ttl(ttl: Optional[Union[int, float, timedelta]]) -> float:
    """Приводить TTL до секунд (float, ≥0). None → 0."""
    if ttl is None:
        return 0.0
    if isinstance(ttl, timedelta):
        return max(0.0, ttl.total_seconds())
    try:
        return max(0.0, float(ttl))
    except (TypeError, ValueError):
        return 0.0


# ================================
# 📦 Внутрішня структура кеш‑елемента
# ================================
@dataclass(slots=True)
class _CacheItem:
    data: Any
    # 0.0 → без фіксованого терміну (TTL застосовується «на читанні» при get)
    expires_at: float


# ================================
# 🧠 Основний кеш‑клас
# ================================
class AvailabilityCacheService(Generic[T]):
    """
    📊 In‑memory кеш результатів перевірки (thread‑safe).

    Семантика (зворотна сумісність):
      • set(key, data) — зберігає значення без фіксованого терміну.
      • get(key, ttl) — повертає значення, якщо воно ще «живе» на момент читання:
          - якщо у елемента expires_at == 0 → застосовується переданий ttl;
          - якщо у елемента зафіксований expires_at → використовуємо його, ttl ігноруємо.

    Додатково:
      • set_with_ttl(key, data, ttl) — зафіксувати термін життя одразу під час запису.
      • get_or_set(key, ttl, supplier) — ледача ініціалізація.
      • prune_expired() — видалити прострочене (із фіксацією часу «останньої чистки»).
      • stats() — прості метрики (усього / живих / last_prune_at / evictions).
    """

    def __init__(self, *, max_items: Optional[int] = None) -> None:
        """
        Args:
            max_items: опціональне обмеження кількості записів (простий запобіжник від росту).
                       Якщо досягнуто ліміту — перед set() виконується prune_expired(),
                       а потім може бути виселений довільний елемент (eviction).
        """
        self._cache: Dict[str, _CacheItem] = {}
        self._lock = RLock()
        self._last_prune_at: float = 0.0
        self._evictions: int = 0
        self._max_items = max(1, int(max_items)) if max_items else None

    # ================================
    # 🧪 Читання (Backward compatible)
    # ================================
    def get(self, key: str, ttl: Union[int, float, timedelta]) -> Optional[T]:
        """
        Отримує кешовані дані, якщо вони ще не прострочені.

        Args:
            key: 🔑 Унікальний ключ.
            ttl: ⏳ Час життя (секунди або timedelta) — застосовується,
                 якщо елемент збережено без фіксованого expires_at.

        Returns:
            Дані або None (якщо немає або прострочено).
        """
        ttl_sec = _normalize_ttl(ttl)
        with self._lock:
            item = self._cache.get(key)
            if item is None:
                return None

            now = _now()
            # якщо під час set() не фіксували термін, застосуємо TTL «на читанні»
            effective_expires_at = item.expires_at or (now + ttl_sec)
            if now < effective_expires_at:
                return item.data  # type: ignore[return-value]

            # протухло — видаляємо
            self._cache.pop(key, None)
            return None

    # ================================
    # 💾 Запис (Backward compatible)
    # ================================
    def set(self, key: str, data: T) -> None:
        """
        Зберігає об'єкт без зафіксованого TTL (expires_at = 0.0).
        Зручно поєднувати з get(key, ttl), де TTL задається під час читання.
        """
        with self._lock:
            self._maybe_compact_locked()
            self._cache[key] = _CacheItem(data=data, expires_at=0.0)

    # ================================
    # 🆕 Зручні методи
    # ================================
    def set_with_ttl(self, key: str, data: T, ttl: Union[int, float, timedelta]) -> None:
        """Записати значення із фіксацією терміну життя одразу."""
        ttl_sec = _normalize_ttl(ttl)
        with self._lock:
            self._maybe_compact_locked()
            self._cache[key] = _CacheItem(
                data=data,
                expires_at=(_now() + ttl_sec) if ttl_sec > 0 else 0.0,
            )

    def get_or_set(self, key: str, ttl: Union[int, float, timedelta], supplier: Callable[[], T]) -> T:
        """
        🦥 Ледача ініціалізація кешу:
          - якщо актуальне значення є — повертає його;
          - якщо немає — обчислює supplier(), кладе у кеш і повертає.
        TTL застосовується «на читанні» (через get), як у базовій семантиці.
        """
        existing = self.get(key, ttl)
        if existing is not None:
            return existing
        fresh = supplier()
        self.set(key, fresh)
        return fresh

    def invalidate(self, key: str) -> None:
        """🧹 Видаляє один ключ з кешу (якщо існує)."""
        with self._lock:
            self._cache.pop(key, None)

    def clear(self) -> None:
        """🧼 Повністю очищає кеш."""
        with self._lock:
            self._cache.clear()

    def prune_expired(self) -> int:
        """
        🔪 Видаляє всі прострочені елементи (корисно викликати періодично).
        Повертає кількість видалених елементів і фіксує момент останньої чистки.
        """
        now = _now()
        removed = 0
        with self._lock:
            to_delete = [k for k, item in self._cache.items() if item.expires_at and now >= item.expires_at]
            for k in to_delete:
                self._cache.pop(k, None)
                removed += 1
            self._last_prune_at = now
        return removed

    def stats(self) -> Dict[str, int | float]:
        """
        📈 Прості метрики: кількість записів, ще «живих», час останнього prune і кількість евікцій.
        """
        now = _now()
        with self._lock:
            total = len(self._cache)
            live = sum(1 for item in self._cache.values() if item.expires_at == 0.0 or now < item.expires_at)
            return {
                "items_total": total,
                "items_live": live,
                "last_prune_at": self._last_prune_at,  # epoch seconds (0.0 якщо не чистили)
                "evictions": self._evictions,
            }

    # ================================
    # 🔒 Внутрішні допоміжні
    # ================================
    def _maybe_compact_locked(self) -> None:
        """
        Якщо задано max_items і ми впираємося в ліміт — спочатку приберемо прострочене,
        а якщо все ще тісно — виселимо довільний елемент.
        """
        if self._max_items is None or len(self._cache) < self._max_items:
            return

        # 1) Спробуємо прибрати прострочені:
        self.prune_expired()
        if len(self._cache) < self._max_items:
            return

        # 2) Якщо все ще багато — видалимо довільний (простий запобіжник від переростання)
        #    Навмисно НЕ реалізуємо LRU: зайва складність для нашої задачі.
        try:
            victim_key = next(iter(self._cache.keys()))
        except StopIteration:
            return
        self._cache.pop(victim_key, None)
        self._evictions += 1

    # Невеликі зручності (необов’язково)
    def __len__(self) -> int:
        with self._lock:
            return len(self._cache)

    def __contains__(self, key: str) -> bool:
        with self._lock:
            return key in self._cache


__all__ = ["AvailabilityCacheService"]