# 🤖 app/infrastructure/ai/prompt_service.py
"""
Адаптер над shared PromptService:
— формує готовий ChatPrompt (DTO) для OpenAIService.
— бере temperature/max_tokens з config.yaml (per-prompt overrides).
"""

from __future__ import annotations

import logging
from typing import Optional, Tuple

from app.shared.utils.logger import LOG_NAME
from app.shared.utils.prompt_service import PromptService as SharedPromptBuilder
from app.shared.utils.prompt_service import PromptType, ChartType
from app.config.config_service import ConfigService
from .dto import ChatPrompt, ChatMessage, Role

logger = logging.getLogger(f"{LOG_NAME}.ai")


class PromptService:
    """
    Інфраструктурний сервіс: повертає НЕ рядки, а ChatPrompt (DTO).
    Усередині користується shared PromptService як builder'ом текстів
    та підтягує температуру/токени з конфіга.
    """

    def __init__(
        self,
        cfg: ConfigService,
        builder: Optional[SharedPromptBuilder] = None,
    ) -> None:
        self._cfg = cfg
        self._builder = builder or SharedPromptBuilder()

    # ── helpers ────────────────────────────────────────────────────────────
    def _tt(self, key: str) -> Tuple[float, int]:
        """temperature/max_tokens с учётом defaults + overrides."""
        defaults = self._cfg.get("openai.defaults", {}) or {}
        overrides = (self._cfg.get(f"openai.prompts.{key}", {}) or {})
        temp = float(overrides.get("temperature", defaults.get("temperature", 0.3)))
        mtok = int(overrides.get("max_tokens", defaults.get("max_tokens", 1024)))
        return temp, mtok

    # ── паблик API: возвращаем DTO ─────────────────────────────────────────
    def slogan(self, *, title: str, description: str) -> ChatPrompt:
        text = self._builder.get_prompt(PromptType.SLOGAN, title=title, description=description)
        t, k = self._tt("slogan")
        return ChatPrompt(messages=[ChatMessage(Role.USER, text)], temperature=t, max_tokens=k)

    def music(self, *, title: str, description: str, image_url: str) -> ChatPrompt:
        text = self._builder.get_prompt(PromptType.MUSIC, title=title, description=description, image_url=image_url)
        t, k = self._tt("music")
        return ChatPrompt(messages=[ChatMessage(Role.USER, text)], temperature=t, max_tokens=k)

    def translation(self, *, text: str) -> ChatPrompt:
        p = self._builder.get_prompt(PromptType.TRANSLATION, text=text)
        t, k = self._tt("translation")
        return ChatPrompt(messages=[ChatMessage(Role.USER, p)], temperature=t, max_tokens=k)

    def weight(self, *, title: str, description: str, image_url: str) -> ChatPrompt:
        p = self._builder.get_prompt(PromptType.WEIGHT, title=title, description=description, image_url=image_url)
        t, k = self._tt("weight")
        return ChatPrompt(messages=[ChatMessage(Role.USER, p)], temperature=t, max_tokens=k)

    def clothing_type(self, *, title: str) -> ChatPrompt:
        p = self._builder.get_prompt(PromptType.CLOTHING_TYPE, title=title)
        t, k = self._tt("clothing_type")
        return ChatPrompt(messages=[ChatMessage(Role.USER, p)], temperature=t, max_tokens=k)

    def hashtags(self, *, title: str, description: str) -> ChatPrompt:
        p = self._builder.get_prompt(PromptType.HASHTAGS, title=title, description=description)
        t, k = self._tt("hashtags")
        return ChatPrompt(messages=[ChatMessage(Role.USER, p)], temperature=t, max_tokens=k)

    def size_chart(self, *, chart_type: ChartType) -> ChatPrompt:
        p = self._builder.get_size_chart_prompt(chart_type)
        t, k = self._tt("size_chart")
        return ChatPrompt(messages=[ChatMessage(Role.USER, p)], temperature=t, max_tokens=k)