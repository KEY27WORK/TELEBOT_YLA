# 📋 app/bot/commands/main_menu_feature.py
"""
📋 main_menu_feature.py — Фіча головного меню Telegram‑бота.

- Перемикає режими роботи бота (product/collection/size/etc.).
- Відображає допоміжні меню (валюта, допомога, замовлення).
- Тонкий UI‑шар: жодної бізнес‑логіки, лише маршрутизація натискань.
"""

from __future__ import annotations

# 🌐 Зовнішні бібліотеки
from telegram import Update                                                    # 📬 Об'єкт оновлення Telegram

# 🔠 Системні імпорти
import logging                                                                 # 🧾 Логування
from typing import Any, Awaitable, Callable, Dict, MutableMapping, Optional, Tuple, cast  # 🧰 Типізація

# 🧩 Внутрішні модулі проєкту
from app.bot.commands.base import BaseFeature                                  # 🏛️ Базовий контракт фічі
from app.bot.services.custom_context import CustomContext                      # 🧠 Розширений контекст застосунку
from app.bot.ui.keyboards.keyboards import Keyboard                                      # ⌨️ Побудова клавіатур
from app.bot.ui import static_messages as msg                                  # 🗒️ Статичні тексти UI
from app.config.setup.constants import AppConstants                            # ⚙️ Константи застосунку
from app.shared.utils.logger import LOG_NAME                                   # 🏷️ Ім'я логера

# ================================
# 🧭 НАЛАШТУВАННЯ ЛОГУВАННЯ
# ================================
logger = logging.getLogger(LOG_NAME)                                           # 🧾 Виділений логер для цієї фічі


# ================================
# 🏛️ ФІЧА ГОЛОВНОГО МЕНЮ
# ================================
class MainMenuFeature(BaseFeature):
    """✨ Обробка кнопок головного меню (маршрутизація без бізнес‑логіки)."""

    def __init__(self, constants: AppConstants) -> None:
        self.const = constants                                                 # ⚙️ Доступ до UI/LOGIC констант
        modes = self.const.LOGIC.MODES                                         # 🎚️ Перелік режимів роботи
        buttons = self.const.UI.REPLY_BUTTONS                                  # ⌨️ Тексти кнопок reply‑клавіатури

        # текст кнопки → (mode, reply_text)
        self.mode_map: Dict[str, Tuple[str, str]] = {
            buttons.INSERT_LINKS: (modes.PRODUCT, msg.MENU_MODE_PRODUCT_ENABLED),
            buttons.COLLECTION_MODE: (modes.COLLECTION, msg.MENU_MODE_COLLECTION_ENABLED),
            buttons.SIZE_CHART_MODE: (modes.SIZE_CHART, msg.MENU_MODE_SIZE_CHART_ENABLED),
            buttons.REGION_AVAILABILITY: (modes.REGION_AVAILABILITY, msg.MENU_MODE_AVAILABILITY_ENABLED),
            buttons.PRICE_CALC_MODE: (modes.PRICE_CALCULATION, msg.MENU_MODE_PRICE_CALC_ENABLED),
        }                                                                      # 🗺️ Мапа перемикачів режимів

        # текст кнопки → async‑обробник
        self.action_map: Dict[str, Callable[[Update, CustomContext], Awaitable[None]]] = {
            buttons.MY_ORDERS: self._show_my_orders,
            buttons.CURRENCY: self._show_currency_menu,
            buttons.HELP: self._show_help_menu,
            buttons.DISABLE_MODE: self._disable_mode,
        }                                                                      # 🎬 Мапа дій (асинхронні хендлери)

    # ================================
    # 🗄️ HELPERS: USER_DATA
    # ================================

    def _get_ud(self, context: CustomContext) -> MutableMapping[str, Any]:
        """
        Повертає dict‑подібний об'єкт user_data.

        ✅ Якщо у типах це Optional і зараз там None — створюємо порожній dict
        і, якщо можливо, записуємо назад у context.user_data (щоб зміни збереглись).
        """
        ud: Any = getattr(context, "user_data", None)
        if ud is None:
            ud = {}                                                            # 🆕 Створюємо volatile‑сховище
            try:
                setattr(context, "user_data", ud)  # type: ignore[attr-defined] # 💾 Пробуємо зберегти у контекст
            except Exception:
                pass                                                            # 🙈 Контекст може бути read‑only — тоді просто повернемо dict
        return cast(MutableMapping[str, Any], ud)

    def _set_mode(self, context: CustomContext, value: Optional[str]) -> None:
        """
        Встановлює режим через property `context.mode` (якщо є)
        або через словник `user_data` — fallback‑шлях.
        """
        key = self.const.LOGIC.USER_DATA.MODE                                  # 🔑 Ключ у user_data

        # 1) Типобезпечний шлях — кастомне property `mode`
        try:
            if hasattr(context, "mode"):
                context.mode = value  # type: ignore[attr-defined]             # 🎚️ Актуалізуємо режим у контексті
                return
        except Exception as e:  # noqa: BLE001
            logger.warning("Failed to set mode via context.mode: %s", e)      # ⚠️ Логуємо, не падаємо

        # 2) Фолбек — user_data
        ud = self._get_ud(context)
        if value is None:
            ud.pop(key, None)                                                  # 🧹 Видаляємо режим
        else:
            ud[key] = value                                                    # 💾 Зберігаємо новий режим

    # ================================
    # 🎛️ ПУБЛІЧНИЙ ОБРОБНИК
    # ================================

    async def handle_menu(self, update: Update, context: CustomContext) -> None:
        """Маршрутизує натиснуті кнопки головного меню."""
        text = self._get_message_text(update)
        if text is None:
            return                                                              # 🚫 Нема тексту — нічого обробляти

        user_id = update.effective_user.id if update.effective_user else "unknown"
        logger.debug("Menu click: user=%s, text=%r", user_id, text)            # 🔍 Трасування кліку

        # 1) Перемикачі режимів
        if text in self.mode_map:
            mode, reply_text = self.mode_map[text]
            self._set_mode(context, mode)                                      # 🎚️ Перемкнули режим у контексті

            if update.message:
                await update.message.reply_text(reply_text)                    # 💬 Відповідь користувачу
            return

        # 2) Кнопки‑дії
        handler = self.action_map.get(text)
        if handler:
            await handler(update, context)                                     # ▶️ Виклик відповідного хендлера
            return

        # 3) Невідома кнопка
        logger.warning("Unknown menu item: %r (user=%s)", text, user_id)      # ⚠️ Фіксуємо кейс у логах
        if update.message:
            await update.message.reply_text(msg.MENU_UNKNOWN_OPTION)           # ℹ️ Пояснюємо користувачу

    # ================================
    # 🔒 ПРИВАТНІ ХЕЛПЕРИ
    # ================================

    def _get_message_text(self, update: Update) -> Optional[str]:
        if not update.message or not update.message.text:
            return None                                                        # 📨 Захист від порожнього апдейту
        return update.message.text.strip()                                     # ✂️ Обрізаємо пробіли

    # ================================
    # 🎬 ДІЇ
    # ================================

    async def _show_my_orders(self, update: Update, context: CustomContext) -> None:  # noqa: ARG002
        if update.message:
            await update.message.reply_text(msg.MENU_MY_ORDERS_EMPTY)          # 📦 Поки що порожньо

    async def _show_currency_menu(self, update: Update, context: CustomContext) -> None:  # noqa: ARG002
        if update.message:
            await update.message.reply_text(
                msg.MENU_CURRENCY_PROMPT,
                reply_markup=Keyboard.currency_menu(),                         # ⌨️ Показуємо кнопки вибору валюти
            )

    async def _show_help_menu(self, update: Update, context: CustomContext) -> None:  # noqa: ARG002
        if update.message:
            await update.message.reply_text(
                msg.MENU_HELP_PROMPT,
                reply_markup=Keyboard.help_menu(),                             # 📖 Підказки та довідка
            )

    async def _disable_mode(self, update: Update, context: CustomContext) -> None:
        if update.message:
            self._set_mode(context, None)                                      # 📴 Вимикаємо всі режими
            await update.message.reply_text(
                msg.MENU_ALL_MODES_DISABLED,
                reply_markup=Keyboard.main_menu(),                             # ⌨️ Повертаємо головне меню
            )
