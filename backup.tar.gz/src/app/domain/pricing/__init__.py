# 💸 app/domain/pricing/__init__.py
"""
💸 Pricing — чистый домен ценообразования (Decimal‑only, без I/O).

Экспортирует:
  • Контракты и DTO: Money, PriceInput, PriceBreakdown, PricingContext,
    FullPriceDetails, IPriceService (новый), IPricingService (legacy).
  • Сервис и правила: PriceService, PricingRules.
  • Утилиты округления: q2, percent.

Заметки:
  • Для нового кода используйте IPriceService + PriceService.build_quote().
  • IPricingService оставлен для обратной совместимости.
"""

# 🧱 Контракты и DTO домена
from .interfaces import (
    Money,
    PriceInput,
    PriceBreakdown,
    IPriceService,     # новый минималистичный контракт
    PricingContext,    # legacy‑контекст
    FullPriceDetails,  # legacy‑выход
    IPricingService,   # legacy‑контракт
)

# 🔢 Утилиты округления для Decimal
from .rounding import q2, percent

# 💼 Реализация сервиса и набор правил
from .services import PriceService, PricingRules


# ================================
# 📖 ПУБЛИЧНЫЙ ИНТЕРФЕЙС ПАКЕТА
# ================================
__all__ = [
    # DTO / типы
    "Money",
    "PriceInput",
    "PriceBreakdown",
    "PricingContext",
    "FullPriceDetails",
    # контракты
    "IPriceService",
    "IPricingService",
    # сервис и правила
    "PriceService",
    "PricingRules",
    # утилиты
    "q2",
    "percent",
]