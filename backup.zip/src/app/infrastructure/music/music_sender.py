# 🎵 app/infrastructure/music/music_sender.py
"""
Оркестратор отправки музыки в Telegram.
Понимает доменные DTO: RecommendedTrack и MusicRecommendationResult.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Dict, Iterable, List, Sequence

from telegram import Update
from telegram.constants import ChatAction
from telegram.error import RetryAfter

from app.bot.services.custom_context import CustomContext
from app.config.config_service import ConfigService
from app.domain.music.interfaces import IMusicDownloader, RecommendedTrack, MusicRecommendationResult
from app.shared.utils.logger import LOG_NAME
from .music_file_manager import MusicFileManager

logger = logging.getLogger(LOG_NAME)


class MusicSender:
    """
    UX: сначала отправляем список треков (быстро), затем — сами аудио в фоне.
    """

    def __init__(self, downloader: IMusicDownloader, file_manager: MusicFileManager, config: ConfigService) -> None:
        self._downloader = downloader
        self._file_manager = file_manager
        self._config = config

        self._dl_semaphore = asyncio.Semaphore(int(config.get("music.download.concurrent_downloads", 3) or 3))
        self._send_semaphore = asyncio.Semaphore(int(config.get("music.send.concurrent_sends", 3) or 3))

        # защита от повторной одновременной загрузки одного и того же трека
        self._inflight: Dict[str, asyncio.Future] = {}

    # ── Публичное API ──────────────────────────────────────────────────────
    async def send_recommendations(self, update: Update, context: CustomContext, result: MusicRecommendationResult) -> None:
        """
        Современный путь: принимает MusicRecommendationResult с RecommendedTrack внутри.
        """
        if not update.message or not result.tracks:
            return

        await update.message.reply_text(
            self._format_track_list([t.display_name for t in result.tracks]),
            parse_mode="HTML",
        )

        try:
            await update.message.chat.send_action(ChatAction.UPLOAD_DOCUMENT)
        except Exception:
            pass

        for track in result.tracks:
            asyncio.create_task(self._process_track_in_background(update, track))

        # отложенная очистка кеша
        clear_delay = int(self._config.get("music.cache.clear_delay_sec", 600) or 600)
        asyncio.create_task(self._delayed_cache_clear(clear_delay))

    # ✅ Легаси-вариант: если у тебя пока список строк — мы аккуратно преобразуем в DTO
    async def send_recommendations_legacy(self, update: Update, context: CustomContext, track_names: Sequence[str]) -> None:
        tracks = [self._str_to_track(name) for name in track_names if (name or "").strip()]
        await self.send_recommendations(update, context, MusicRecommendationResult(tracks=tuple(tracks), raw_text="", model=""))

    # ── Внутреннее ─────────────────────────────────────────────────────────
    async def _process_track_in_background(self, update: Update, track: RecommendedTrack) -> None:
        if not update.message:
            return

        key = track.display_name
        fut = self._inflight.get(key)
        if fut:
            await fut
            return

        fut = asyncio.get_running_loop().create_future()
        self._inflight[key] = fut

        try:
            async with self._dl_semaphore:
                track_info = await self._downloader.download(track)

            if track_info.file_path:
                async with self._send_semaphore:
                    try:
                        with open(track_info.file_path, "rb") as audio_file:
                            await update.message.reply_audio(
                                audio=audio_file,
                                caption=f"🎧 {track_info.name}",
                                parse_mode="HTML",
                                disable_notification=True,
                            )
                    except FileNotFoundError:
                        logger.warning("Файл исчез до момента отправки: %s", track_info.file_path)
            else:
                logger.warning("Трек «%s» не отправлен: %s", key, track_info.error)

        except RetryAfter as e:
            logger.warning("⏳ Лимит отправки Telegram. Ждём %s сек.", e.retry_after)
            await asyncio.sleep(e.retry_after)
            await self._process_track_in_background(update, track)
        except Exception as e:  # noqa: BLE001
            logger.exception("Критическая ошибка при обработке трека «%s»: %s", key, e)
        finally:
            fut.set_result(True)
            self._inflight.pop(key, None)

    async def _delayed_cache_clear(self, delay_seconds: int) -> None:
        await asyncio.sleep(max(0, int(delay_seconds)))
        await self._file_manager.clear_cache()

    @staticmethod
    def _format_track_list(track_names: Iterable[str]) -> str:
        lines = [f"{i + 1}. {name}" for i, name in enumerate(track_names)]
        return "🎵 <b>Музика для посту:</b>\n" + "\n".join(lines)

    # ── Утилиты ────────────────────────────────────────────────────────────
    @staticmethod
    def _str_to_track(s: str) -> RecommendedTrack:
        """
        Преобразует строку вида «Artist — Title» (разные тире/дефисы) в DTO.
        Если разделить не удалось — считаем это названием трека без артиста.
        """
        text = (s or "").strip()
        for sep in (" — ", " – ", " - ", "—", "–", "-"):
            if sep in text:
                artist, title = (part.strip() for part in text.split(sep, 1))
                if artist and title:
                    return RecommendedTrack(artist=artist, title=title)
        return RecommendedTrack(artist="", title=text)