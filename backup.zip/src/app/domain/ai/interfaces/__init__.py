"""
Підпакет `domain.ai.interfaces`.
Експортує контракт побудови промтів і пов'язані DTO/Enums.
"""

from .prompt_service_interface import (  # re-export для зручності
    IPromptService,
    ProductPromptDTO,
    ChatPrompt,
    ChatMessage,
    TextPart,
    ImagePart,
    ContentPart,
    Tone,
    Lang,
    Role,
)

__all__ = [
    "IPromptService",
    "ProductPromptDTO",
    "ChatPrompt",
    "ChatMessage",
    "TextPart",
    "ImagePart",
    "ContentPart",
    "Tone",
    "Lang",
    "Role",
]