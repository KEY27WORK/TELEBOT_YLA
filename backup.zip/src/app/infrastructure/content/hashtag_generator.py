# app/infrastructure/content/hashtag_generator.py
"""
Генерация хештегов для товара YoungLA.
Инфраструктурная реализация доменного интерфейса IHashtagGenerator.
"""
from __future__ import annotations

import re
import logging
import asyncio
from typing import List, Set, Dict

from app.config.config_service import ConfigService
from app.infrastructure.ai.open_ai_serv import OpenAIService
from app.infrastructure.ai.prompt_service import PromptService
from app.shared.utils.logger import LOG_NAME

from app.domain.content.interfaces import IHashtagGenerator
from app.domain.products.entities import ProductInfo

logger = logging.getLogger(f"{LOG_NAME}.ai")


class HashtagGenerator(IHashtagGenerator):
    """
    Возвращает МНОЖЕСТВО валидных хештегов (без '#'-дублей и мусора).
    Склейку в строку делает вызывающая сторона.
    """

    def __init__(
        self,
        config_service: ConfigService,
        openai_service: OpenAIService,
        prompt_service: PromptService,
        gender_rules: Dict[str, List[str]],
    ) -> None:
        self.config = config_service
        self.openai = openai_service
        self.prompts = prompt_service
        self.gender_rules = gender_rules

        # ⚙️ Берём базовые хештеги строго как список строк (устраняем warning Pylance)
        raw_base: List[str] = self.config.get(
            "hashtags.base",
            [],
            cast=lambda v: [str(x) for x in v] if isinstance(v, (list, tuple, set)) else [],
        ) or []
        self.base_hashtags: List[str] = [s.strip() for s in raw_base if isinstance(s, str) and s.strip()]

    async def generate(self, product: ProductInfo) -> Set[str]:
        title = product.title
        description = product.description

        logger.info("🔍 Генерация хештегов для: %s", title)
        tags: Set[str] = set(self.base_hashtags)

        article = self._extract_article(title)
        tags.update(self._gender_tags(article))

        clothing_task = self._extract_clothing_type(title)
        ai_tags_task = self._generate_ai_hashtags(title, description)
        clothing_type, ai_tags = await asyncio.gather(clothing_task, ai_tags_task)

        if clothing_type:
            tags.add(f"#{clothing_type.replace(' ', '').lower()}")

        tags.update(ai_tags)

        sanitized = {self._sanitize_hashtag(h) for h in tags if self._sanitize_hashtag(h)}
        return sanitized

    # ── helpers ────────────────────────────────────────────────────────────
    def _extract_article(self, title: str) -> str:
        m = re.match(r"^([A-Za-z0-9]+)", title or "")
        return m.group(1) if m else ""

    def _gender_tags(self, article: str) -> List[str]:
        for prefix, tags in self.gender_rules.items():
            if prefix != "default" and article.startswith(prefix):
                return tags
        return self.gender_rules.get("default", [])

    async def _extract_clothing_type(self, title: str) -> str:
        prompt = self.prompts.clothing_type(title=title)
        resp = await self.openai.chat_completion(prompt)
        return resp.strip().lower() if resp else ""

    async def _generate_ai_hashtags(self, title: str, description: str) -> Set[str]:
        prompt = self.prompts.hashtags(title=title, description=description)
        resp = await self.openai.chat_completion(prompt)
        if not resp:
            return set()
        return set(re.findall(r"#\w+", resp))

    def _sanitize_hashtag(self, hashtag: str) -> str:
        clean = re.sub(r"[^a-zA-Z0-9а-яА-ЯіІїЇєЄ_]", "", (hashtag or "").replace("#", ""))
        return f"#{clean.lower()}" if clean else ""