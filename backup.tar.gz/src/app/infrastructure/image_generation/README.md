# 🖼️ Image Generation Infrastructure

## FontService
Переносимий сервіс шрифтів:
- Першочергово читає шрифти з `app/assets/fonts`.
- Підтримує явні шляхи з конфігів.
- Має кеш завантажених шрифтів.
- Має системні fallback'и і останній fallback — `ImageFont.load_default()`.

### Використання
```python
from app.infrastructure.image_generation import FontService
from app.domain.image_generation.interfaces import FontType

fs = FontService()
font = fs.get_font(FontType.BOLD, 28)
w = fs.get_text_width("Hello", font)
```
---

## Что улучшили сверх ответа Гемени
- Поддержка **конфига** (можешь указать свои пути к шрифтам без правок кода).
- **Кеширование** `@lru_cache` уже в методе `get_font`.
- Тихие, но полезные логи, если assets отсутствуют.
- Стабильные системные **fallback-пути** и финальный **Pillow fallback**.
- Аккуратный расчёт ширины текста с двойным механизмом (textlength → textbbox).

Если хочешь, дам минимальный YAML-пример для конфигов или быстро добавлю тонкую проверку наличия файла на старте (с raise) — но и так уже “боевой” и переносимый вариант.