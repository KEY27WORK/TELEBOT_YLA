# 🧩 Domain Layer

Чистый домен приложения: **контракты**, **DTO/сущности** и **бизнес‑сервисы без I/O**.  
Никаких HTTP, файлов, SDK и логгеров — только детерминированная логика.

---

## 🧱 Принципы

- **Чистота:** реализаций инфраструктуры здесь нет.
- **Точность:** финансы — через `Decimal`; никаких `float`.
- **Единицы:** вес — всегда **в граммах (int)**.
- **Детерминизм:** одинаковый вход → одинаковый выход.
- **Типобезопасность:** `Enum`, `Literal`, `Protocol`/`ABC`, `@dataclass(frozen=True, slots=True)`.

---

## 📂 Структура

```bash
domain/
├─ ai/            # Промпты/LLM: контракты и DTO
├─ availability/  # Агрегация наличия по регионам
├─ currency/      # Деньги/конвертация (контракты + Money DTO)
├─ delivery/      # Контракты расчёта доставки
├─ music/         # Контракты музыкальной подсистемы
├─ pricing/       # Чистый прайсинг (Decimal) + сервис/правила
└─ products/      # Сущности товара + контракты и сервисы
```

---

## 🔌 Быстрые ссылки

- **AI:** `app/domain/ai/interfaces/prompt_service_interface.py`  
  Контракт `IPromptService`, DTO `ChatPrompt`, `ProductPromptDTO`, мультимодальные части `TextPart`/`ImagePart`.

- **Availability:** `app/domain/availability`  
  DTO `RegionStock`, `AvailabilityReport`, enum `AvailabilityStatus`, сервис `AvailabilityService`  
  и ключ сортировки `default_size_sort_key`.

- **Currency:** `app/domain/currency/interfaces.py`  
  DTO `Money`, контракты `IMoneyConverter` (основной) и `ICurrencyConverter` (legacy).

- **Delivery:** `app/domain/delivery/interfaces.py`  
  DTO `DeliveryQuote`, контракт `IDeliveryService` (вес — **граммы**).

- **Music:** `app/domain/music/interfaces.py`  
  DTO `RecommendedTrack`, `MusicRecommendationResult`, `TrackInfo`; контракты `IMusicRecommender` и др.  
  Использует `ProductPromptDTO` из домена `ai`.

- **Pricing:** `app/domain/pricing`  
  Контракт `IPriceService` (`build_quote`), DTO `PriceInput` → `PriceBreakdown`, утилиты `q2`, `percent`,  
  и реализация `PriceService` + `PricingRules`.

- **Products:** `app/domain/products`  
  Сущность `ProductInfo` (валидируемая, immutable), контракты `IProductDataProvider` и т.д.,  
  сервис `WeightResolver` (локальные веса → AI‑fallback).

---

## ✅ Тестируемость

- Все зависимости — через контракты ⇒ легко мокаются.
- Деньги сравнивайте через `quantize`/`q2`.
- Для availability используйте фиксированные стратегии сортировки (например, `default_size_sort_key`).

---

## 🧭 Как использовать

Импортируйте из конкретного подпакета, например:

```python
from app.domain.pricing import PriceService, PricingRules, Money, PriceInput
from app.domain.currency.interfaces import IMoneyConverter
```

Инфраструктурные реализации (реальные конвертеры, провайдеры курсов, загрузчики треков, парсеры и т.д.) находятся вне домена и внедряются через DI.

---