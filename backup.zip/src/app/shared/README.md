# 🧰 Модуль `shared`

Модуль **shared** містить крос-функціональні компоненти, які використовуються у всіх шарах архітектури (`bot`, `infrastructure`, `domain`, `config`).  
Він об’єднує утиліти, сервіси та текстові шаблони, що **не належать до конкретного доменного контексту**.

---

## 📦 Структура

### `utils/` — Утиліти та сервіси

- **`logger.py`** — централізована система логування (консоль + файл, ротація, suppress).
- **`interfaces.py`** — контракт `IUrlParsingStrategy` (патерн **Strategy** для парсингу URL).
- **`url_parser_service.py`** — фасад для роботи з URL (делегує конкретним стратегіям з `infrastructure`).
- **`prompt_service.py`** — головний сервіс роботи з промтами (ледаче завантаження, кешування, валідація).
- **`prompts.py`** — **shim** для зворотної сумісності (старий API: `get_prompt()`, `get_size_chart_prompt()`).
- **`prompt_loader.py`** — **shim** для старого API (`load_prompt()`, `load_ocr_asset()`).

> ⚠️ Новий код має використовувати `PromptService` напряму.  
> Старі модулі (`prompts.py`, `prompt_loader.py`) залишені тільки для backward compatibility.

---

### `prompts/` — Текстові шаблони

Містить лише контент для генерації запитів до GPT.

- **`uk/`** — україномовні шаблони:
  - `music.txt`, `hashtags.txt`, `slogan.txt`, `weight.txt`, `translation.txt`, `clothing_type.txt`
- **`ocr/`** — базовий OCR-шаблон і JSON-приклади:
  - `base.txt`, `example_general.json`, `example_unique.json`

Файли завантажуються через `PromptService`, кешуються в памʼяті і легко редагуються без зміни Python-коду.

---

## ✅ Призначення

- Централізація спільних сервісів (логування, промти, парсинг URL).
- Винесення текстових промтів у файли.
- Мінімізація дублювання та залежностей між модулями.
- Чистий код: SRP, KISS, ізоляція бізнес-логіки.

---

## 📚 Приклад використання

```python
from app.shared.utils import PromptService, PromptType

ps = PromptService()
prompt = ps.get_prompt(PromptType.SLOGAN, title="4044 Gladiator", description="Тканина, посадка, вайб...")
print(prompt)
```

