# app/bot/main.py
from __future__ import annotations

# 🪵 Единая инициализация логирования из YAML (base/80_logging.yaml + local/99_local.yaml)
try:
    from app.config.setup.container import bootstrap_logging  # наш хелпер, который дергает init_logging_from_config
except Exception:  # на случай локальной сборки без bootstrap'а — no-op
    def bootstrap_logging() -> None:  # type: ignore
        pass

bootstrap_logging()

# 🌐 telegram (PTB v21)
from telegram.ext import (
    Application,
    ApplicationBuilder,
    MessageHandler,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    filters,
)

import logging
import os

# 🧩 проект
from app.shared.utils.logger import LOG_NAME
from app.config.config_service import ConfigService
from app.config.setup.constants import AppConstants, CONST
from app.bot.services import CallbackRegistry, CustomContext
from app.bot.commands import CoreCommandsFeature, CurrencyFeature, MainMenuFeature
from app.bot.handlers import (
    CallbackHandler,
    LinkHandler,
    ProductHandler,
    CollectionHandler,
    SizeChartHandlerBot,
)
from app.bot.handlers.product import ImageSender
from app.bot.ui.messengers.product_messenger import ProductMessenger
from app.bot.ui.messengers.size_chart_messenger import SizeChartMessenger
from app.errors.exception_handler_service import ExceptionHandlerService
from app.infrastructure.currency.currency_manager import CurrencyManager
from app.infrastructure.parsers.parser_factory import ParserFactory
from app.infrastructure.services.product_processing_service import (
    ProductProcessingService,
)
from app.infrastructure.collection_processing.collection_processing_service import (
    CollectionProcessingService,
)
from app.infrastructure.size_chart.size_chart_service import SizeChartService
from app.infrastructure.availability.availability_handler import AvailabilityHandler
from app.domain.products.search.search_provider import ProductSearchProvider
from app.domain.pricing.interfaces import IPricingService
from app.infrastructure.pricing.pricing_service import PricingServiceImpl
from app.shared.utils.url_parser_service import UrlParserService


# =========================
# 🔧 ЛОГИ
# =========================
logger = logging.getLogger(LOG_NAME)


# =========================
# 🧩 СБОРКА DI
# =========================
def build_application(token: str) -> Application:
    # ⚙️ Конфиги/константы
    config = ConfigService()
    const: AppConstants = CONST

    # 🛡️ Централизованный обработчик исключений
    exception_handler = ExceptionHandlerService(const)

    # 💱 Валюты
    currency_manager = CurrencyManager(config, const)

    # 🔗 URL-парсер
    url_parser = UrlParserService(config, const)

    # 🧭 Парсеры/процессинг товара
    parser_factory = ParserFactory(config, const)
    processing_service = ProductProcessingService(
        parser_factory=parser_factory,
        currency_manager=currency_manager,
        config=config,
        constants=const,
    )

    # 🖼️ Отправители сообщений/картинок
    image_sender = ImageSender(exception_handler, const)
    product_messenger = ProductMessenger(
        image_sender=image_sender,
        currency_manager=currency_manager,
        constants=const,
        exception_handler=exception_handler,
    )

    # 📦 Коллекции
    collection_proc = CollectionProcessingService(
        parser_factory=parser_factory,
        url_parser_service=url_parser,
        config=config,
        constants=const,
    )

    # 📏 Size chart
    size_chart_service = SizeChartService(config, const)
    size_chart_messenger = SizeChartMessenger(
        image_sender=image_sender,
        constants=const,
        exception_handler=exception_handler,
    )

    # 🔎 Поиск по тексту → URL товара
    search_provider = ProductSearchProvider(config, const)

    # 🧮 Ценообразование
    pricing_service: IPricingService = PricingServiceImpl(config, const)
    _ = pricing_service  # для будущих хендлеров — остаётся в DI

    # 🤖 Telegram Application
    app = (
        ApplicationBuilder()
        .token(token)
        .context_types(ContextTypes(context=CustomContext))  # важен кастомный контекст
        .build()
    )

    # 📚 Реестр callback-ов
    cb_registry = CallbackRegistry()

    # =========================
    # 🧱 Хендлеры/фичи (DI)
    # =========================
    product_handler = ProductHandler(
        currency_manager=currency_manager,
        processing_service=processing_service,
        messenger=product_messenger,
        exception_handler=exception_handler,
        constants=const,
        url_parser_service=url_parser,
    )

    collection_handler = CollectionHandler(
        product_handler=product_handler,
        url_parser_service=url_parser,
        collection_processing_service=collection_proc,
        exception_handler=exception_handler,
        constants=const,
    )

    size_chart_handler = SizeChartHandlerBot(
        parser_factory=parser_factory,
        size_chart_service=size_chart_service,
        messenger=size_chart_messenger,
        exception_handler=exception_handler,
        constants=const,
    )

    # — Фичи команд/меню
    core_cmds = CoreCommandsFeature(cb_registry, const)
    currency_feature = CurrencyFeature(
        currency_manager=currency_manager,
        registry=cb_registry,
        constants=const,
        exception_handler=exception_handler,
    )
    main_menu_feature = MainMenuFeature(const)

    # — Роутер текста/ссылок
    link_handler = LinkHandler(
        product_handler=product_handler,
        collection_handler=collection_handler,
        size_chart_handler=size_chart_handler,
        price_calculator=None,  # если появится PriceCalculationHandler — подставить сюда
        availability_handler=AvailabilityHandler(config, const, exception_handler),
        search_resolver=search_provider,
        url_parser_service=url_parser,
        currency_manager=currency_manager,
        constants=const,
        exception_handler=exception_handler,
    )

    # — Централизованный обработчик inline-кнопок
    callback_handler = CallbackHandler(cb_registry, exception_handler)

    # =========================
    # 🔌 Регистрация в PTB
    # =========================
    # Команды базовой фичи
    core_cmds.register_handlers(app)
    currency_feature.register_handlers(app)
    main_menu_feature.register_handlers(app)

    # Прямые команды (алиасы)
    app.add_handler(CommandHandler("start", core_cmds.start_command))
    app.add_handler(CommandHandler("help", core_cmds.help_command))

    # CallbackQuery — единая точка
    app.add_handler(CallbackQueryHandler(callback_handler.handle))

    # Текст/ссылки — роутер
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, link_handler.handle_link))

    # Глобальный error handler (страховка)
    async def _on_error(update, context):
        err = context.error
        try:
            await exception_handler.handle(err, update)
        except Exception:
            logger.exception("Global error handler failed")

    app.add_error_handler(_on_error)
    return app


# =========================
# 🚀 ENTRYPOINT (v21)
# =========================
def run() -> None:
    token = os.getenv("BOT_TOKEN") or os.getenv("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError("Set BOT_TOKEN (or TELEGRAM_BOT_TOKEN) in environment.")

    app = build_application(token)
    logger.info("🤖 Bot is starting…")
    app.run_polling(allowed_updates=app.allowed_updates)
    logger.info("👋 Stopped")


if __name__ == "__main__":
    run()