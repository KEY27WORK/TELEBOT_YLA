# 🧰 app/bot/ui/__init__.py
"""
🧰 __init__.py — Публічний фасад пакета **ui** (View‑рівень Telegram-бота).

🔹 Призначення:
    • Надати єдину точку імпорту елементів інтерфейсу (клавіатури, форматери, месенджери, статичні тексти)
    • Сховати внутрішню структуру підпакетів та файлів від зовнішнього коду
    • Забезпечити стабільний API через `__all__`

Приклад використання:
    from app.bot.ui import (
        Keyboard,
        MessageFormatter, PriceReportFormatter,
        ProductMessenger, SizeChartMessenger, AvailabilityMessenger,
        static_messages as msg,
    )
"""

# 🧩 Внутрішні модулі проєкту
from .keyboards import Keyboard													# ⌨️ Фасад клавіатур (inline/reply)
from .formatters import MessageFormatter, PriceReportFormatter						# 🧩 Форматери повідомлень/звітів
from .messengers import ProductMessenger, SizeChartMessenger, AvailabilityMessenger		# ✉️ Надсилання блоків у Telegram
from . import static_messages as static_messages									# 📝 Статичні тексти (UI copy)


# ================================
# 📦 ПУБЛІЧНИЙ API ПАКЕТА
# ================================
__all__ = [
    # keyboards
    "Keyboard",															# Експортувати фасад клавіатур
    # formatters
    "MessageFormatter",													# Експортувати форматер повідомлень
    "PriceReportFormatter",												# Експортувати форматер цінових звітів
    # messengers
    "ProductMessenger",													# Експортувати месенджер товарів
    "SizeChartMessenger",												# Експортувати месенджер таблиць розмірів
    "AvailabilityMessenger",												# Експортувати месенджер наявності
    # texts
    "static_messages",													# Експортувати статичні тексти як модуль
]