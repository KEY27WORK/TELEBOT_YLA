# 🧠 services

Оркестратор обробки товару: парсинг → наявність → контент → музика.  
Головний "мозковий центр" для підготовки даних перед відправкою в Telegram-бот.

---

## 📂 Склад

- **product_processing_service.py** — сервіс-оркестратор:
  - виконує парсинг карточки товару (через `ParserFactory`)
  - отримує дані про наявність (`AvailabilityProcessingService`)
  - формує контент (опис, хештеги, ціни, фото) через `ProductContentService`
  - добирає музику для товару (`MusicRecommendation`) на основі `ProductPromptDTO`
  - повертає єдиний DTO `ProcessedProductData` для UI-рівня

---

## 📦 DTO

### `ProcessedProductData`
Містить усю інформацію, потрібну для відображення товару:
- `url: str` — вихідний URL
- `page_source: str` — HTML-джерело (для дебагу)
- `region_display: str` — регіон (US / EU / UK)
- `content: ProductContentDTO` — зібраний контент (слоган, хештеги, ціни тощо)
- `music_text: str` — текстовий результат музичних рекомендацій

---

## 🏛️ Архітектурні принципи

- ✅ Єдиний вхідний метод `process_url(url: str)`
- ✅ Залежність від **доменних DTO** (`ProductInfo`, `ProductPromptDTO`)
- ✅ Асинхронний пайплайн з `asyncio.gather` для швидкої роботи
- ✅ Стійкий до помилок: музика/наявність не валять увесь цикл
- ✅ Чистий розподіл: цей шар не містить Telegram-логіки, лише підготовку даних

---

## 📌 Використання

```python
from app.infrastructure.services.product_processing_service import ProductProcessingService

service = ProductProcessingService(
    parser_factory=parser_factory,
    availability_processing_service=availability_service,
    content_service=content_service,
    music_recommendation=music_service,
    url_parser_service=url_parser,
)

result = await service.process_url("https://youngla.com/products/12345")
if result:
    print(result.content.slogan)
    print(result.music_text)
```

---

## 🛠 Призначення

Цей модуль є центральною точкою обробки продуктів.  
Він ізолює інфраструктурні деталі та готує єдиний об’єкт для рівня **бота/UI**, що спрощує підтримку та тестування.
