"""
🎼 music_file_manager.py — керування файловим кешем для mp3-треків.
"""

from __future__ import annotations

import asyncio
import glob
import logging
import os
import re
from typing import Optional

from app.config.config_service import ConfigService
from app.domain.music.interfaces import IMusicFileManager, RecommendedTrack
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


class MusicFileManager(IMusicFileManager):
    """
    SRP: тільки файлові операції (без завантажень).
    """

    def __init__(self, config: ConfigService) -> None:
        # шлях керується конфігом; fallback — "music_cache"
        self._cache_dir: str = str(config.get("files.music_cache", "music_cache"))
        os.makedirs(self._cache_dir, exist_ok=True)

    # ── Публічний API ──────────────────────────────────────────────────────
    def get_cached_path(self, track: RecommendedTrack) -> Optional[str]:
        """
        Повертає абсолютний шлях до mp3, якщо файл уже є в кеші.

        Args:
            track: RecommendedTrack (artist + title)
        """
        file_path = self._generate_path(track.display_name)
        return file_path if os.path.exists(file_path) else None

    async def clear_cache(self) -> None:
        """Асинхронне очищення кешу у фоні."""
        await asyncio.to_thread(self._blocking_clear_cache)

    # ── Внутрішнє ─────────────────────────────────────────────────────────
    def _blocking_clear_cache(self) -> None:
        logger.info("🧹 Очищення музичного кешу…")
        pattern = os.path.join(self._cache_dir, "*.mp3")
        for filepath in glob.glob(pattern):
            try:
                os.remove(filepath)
                logger.debug("🧺 Видалено з кешу: %s", filepath)
            except Exception as exc:  # noqa: BLE001
                logger.warning("⚠️ Не вдалося видалити %s: %s", filepath, exc)

    def _generate_path(self, name: str) -> str:
        """Детермінований та безпечний шлях до mp3."""
        clean = self._clean_track_name(name)
        return os.path.join(self._cache_dir, f"{clean}.mp3")

    @staticmethod
    def _clean_track_name(name: str) -> str:
        """Уніфікована нормалізація: дозволені [a-zA-Z0-9] + пробіли + -_()[]."""
        name = re.sub(r"[^\w\s\-\(\)\[\]]", "", name or "").strip()
        return re.sub(r"\s+", "_", name)


__all__ = ["MusicFileManager"]