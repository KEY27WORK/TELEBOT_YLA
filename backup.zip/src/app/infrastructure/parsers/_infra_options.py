# app/infrastructure/parsers/_infra_options.py
"""
Инфра-опции для слоя парсеров.

Задача модуля — хранить и валидировать параметры, которые относятся
исключительно к инфраструктуре (как грузим HTML, лимиты, ретраи и т.п.),
и НЕ протекают в domain-уровень.

Ключевые фичи:
- Иммутабельная dataclass-модель (frozen + slots) с валидацией в __post_init__
- Безопасные значения по умолчанию
- Загрузка из ENV (prefix по умолчанию PARSER_)
- Сборка из dict и удобное merge-переопределение
- to_kwargs() — удобно передавать дальше в конструкторы инфра-классов

ENV-переменные (prefix="PARSER_"):
  PARSER_HTML_PARSER           : "lxml" | "html.parser" | "html5lib"
  PARSER_ENABLE_PROGRESS       : "1"/"0", "true"/"false", "yes"/"no"…
  PARSER_REQUEST_TIMEOUT_SEC   : int > 0
  PARSER_RETRY_ATTEMPTS        : int >= 0
  PARSER_RETRY_BACKOFF_SEC     : float > 0
  PARSER_MIN_HTML_BYTES        : int >= 0
  PARSER_IMAGES_LIMIT          : 1..200
  PARSER_FILTER_SMALL_IMAGES   : bool
  PARSER_LOG_LEVEL             : "CRITICAL"/"ERROR"/"WARNING"/"INFO"/"DEBUG"
  PARSER_USER_AGENT            : str
  PARSER_LOCALE                : str (например, "en-US")

Пример:
    from app.infrastructure.parsers._infra_options import (
        ParserInfraOptions, DEFAULT_PARSER_INFRA_OPTIONS
    )

    opts = ParserInfraOptions.from_env().merge(images_limit=40)
    driver = WebDriverService(user_agent=opts.user_agent, timeout=opts.request_timeout_sec)
    parser = BaseParser(..., html_parser=opts.html_parser, enable_progress=opts.enable_progress)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Mapping, Any, Dict, Literal
import os
import logging


_BOOL_TRUE = {"1", "true", "yes", "on", "y", "t"}
_BOOL_FALSE = {"0", "false", "no", "off", "n", "f"}

_LOG_LEVELS: Dict[str, int] = {
    "CRITICAL": logging.CRITICAL,
    "ERROR": logging.ERROR,
    "WARNING": logging.WARNING,
    "INFO": logging.INFO,
    "DEBUG": logging.DEBUG,
}


def _parse_bool(val: Optional[str], default: bool) -> bool:
    if val is None:
        return default
    s = val.strip().lower()
    if s in _BOOL_TRUE:
        return True
    if s in _BOOL_FALSE:
        return False
    return default


@dataclass(frozen=True, slots=True)
class ParserInfraOptions:
    """
    Идеальная конфигурация инфраструктурных опций для парсеров.

    Поля:
      html_parser         : парсер для BeautifulSoup ("lxml" | "html.parser" | "html5lib")
      enable_progress     : показывать ли прогресс-спиннеры в консоли
      request_timeout_sec : таймаут сетевых запросов (сек)
      retry_attempts      : сколько ретраев делать при загрузке HTML
      retry_backoff_sec   : базовая задержка между ретраями (экспоненциально)
      min_html_bytes      : минимальный размер HTML, чтобы считать загрузку валидной
      images_limit        : верхний лимит для количества картинок, возвращаемых экстрактором
      filter_small_images : выкидывать ли миниатюры/плейсхолдеры (логика в экстракторе)
      log_level           : уровень логирования для инфры ("INFO", "DEBUG" и т.п.)
      user_agent          : переопределение User-Agent для веб-клиента/браузера
      locale              : желаемая локаль/регион (например, "en-US") для заголовков/рендеринга
    """

    html_parser: Literal["lxml", "html.parser", "html5lib"] = "lxml"
    enable_progress: bool = True
    request_timeout_sec: int = 30

    retry_attempts: int = 3
    retry_backoff_sec: float = 0.6

    min_html_bytes: int = 1000
    images_limit: int = 30
    filter_small_images: bool = True

    log_level: Optional[str] = None
    user_agent: Optional[str] = None
    locale: Optional[str] = None

    # -------------------------
    # Валидация инвариантов
    # -------------------------
    def __post_init__(self) -> None:
        allowed_parsers = {"lxml", "html.parser", "html5lib"}
        if self.html_parser not in allowed_parsers:
            raise ValueError(f"html_parser must be one of {allowed_parsers}, got: {self.html_parser!r}")

        if self.request_timeout_sec <= 0:
            raise ValueError("request_timeout_sec must be > 0")

        if self.retry_attempts < 0:
            raise ValueError("retry_attempts must be >= 0")

        if self.retry_backoff_sec <= 0:
            raise ValueError("retry_backoff_sec must be > 0")

        if self.min_html_bytes < 0:
            raise ValueError("min_html_bytes must be >= 0")

        if not (1 <= self.images_limit <= 200):
            raise ValueError("images_limit must be within [1, 200]")

        if self.log_level is not None:
            allowed_levels = set(_LOG_LEVELS.keys())
            if self.log_level.upper() not in allowed_levels:
                raise ValueError(f"log_level must be one of {allowed_levels}, got: {self.log_level!r}")

    # -------------------------
    # Конструкторы
    # -------------------------
    @classmethod
    def default(cls) -> "ParserInfraOptions":
        """Явная точка получения дефолтов (идентична вызову cls())."""
        return cls()

    @classmethod
    def from_env(cls, prefix: str = "PARSER_") -> "ParserInfraOptions":
        """
        Собирает опции из ENV-переменных с указанным префиксом.
        Неизвестные/битые значения игнорируются в пользу дефолтов.
        """
        defaults = cls.default()

        html_parser = os.getenv(f"{prefix}HTML_PARSER", defaults.html_parser)

        enable_progress = _parse_bool(
            os.getenv(f"{prefix}ENABLE_PROGRESS"), defaults.enable_progress
        )

        request_timeout_sec = os.getenv(f"{prefix}REQUEST_TIMEOUT_SEC")
        retry_attempts = os.getenv(f"{prefix}RETRY_ATTEMPTS")
        retry_backoff_sec = os.getenv(f"{prefix}RETRY_BACKOFF_SEC")
        min_html_bytes = os.getenv(f"{prefix}MIN_HTML_BYTES")
        images_limit = os.getenv(f"{prefix}IMAGES_LIMIT")
        filter_small_images = _parse_bool(
            os.getenv(f"{prefix}FILTER_SMALL_IMAGES"), defaults.filter_small_images
        )

        log_level = os.getenv(f"{prefix}LOG_LEVEL", defaults.log_level)
        user_agent = os.getenv(f"{prefix}USER_AGENT", defaults.user_agent)
        locale = os.getenv(f"{prefix}LOCALE", defaults.locale)

        def _to_int(val: Optional[str], default_val: int) -> int:
            try:
                return int(val) if val is not None else default_val
            except Exception:
                return default_val

        def _to_float(val: Optional[str], default_val: float) -> float:
            try:
                return float(val) if val is not None else default_val
            except Exception:
                return default_val

        return cls(
            html_parser=html_parser,  # type: ignore[arg-type]
            enable_progress=enable_progress,
            request_timeout_sec=_to_int(request_timeout_sec, defaults.request_timeout_sec),
            retry_attempts=_to_int(retry_attempts, defaults.retry_attempts),
            retry_backoff_sec=_to_float(retry_backoff_sec, defaults.retry_backoff_sec),
            min_html_bytes=_to_int(min_html_bytes, defaults.min_html_bytes),
            images_limit=_to_int(images_limit, defaults.images_limit),
            filter_small_images=filter_small_images,
            log_level=log_level,
            user_agent=user_agent,
            locale=locale,
        )

    @classmethod
    def from_dict(cls, data: Optional[Mapping[str, Any]]) -> "ParserInfraOptions":
        """
        Сборка из словаря. Лишние ключи игнорируются.
        """
        if not data:
            return cls.default()

        keys = {
            "html_parser",
            "enable_progress",
            "request_timeout_sec",
            "retry_attempts",
            "retry_backoff_sec",
            "min_html_bytes",
            "images_limit",
            "filter_small_images",
            "log_level",
            "user_agent",
            "locale",
        }
        kwargs: Dict[str, Any] = {k: data[k] for k in keys if k in data}
        return cls(**kwargs)

    # -------------------------
    # Удобные методы
    # -------------------------
    def merge(self, **overrides: Any) -> "ParserInfraOptions":
        """
        Возвращает НОВЫЙ экземпляр с подменой указанных полей (immutability friendly).
        None-значения в overrides игнорируются.
        """
        base = self.to_kwargs()
        base.update({k: v for k, v in overrides.items() if v is not None})
        return ParserInfraOptions.from_dict(base)

    def to_kwargs(self) -> Dict[str, Any]:
        """
        Представляет объект как dict. Удобно для прокидывания параметров,
        логирования или сериализации.
        """
        return {
            "html_parser": self.html_parser,
            "enable_progress": self.enable_progress,
            "request_timeout_sec": self.request_timeout_sec,
            "retry_attempts": self.retry_attempts,
            "retry_backoff_sec": self.retry_backoff_sec,
            "min_html_bytes": self.min_html_bytes,
            "images_limit": self.images_limit,
            "filter_small_images": self.filter_small_images,
            "log_level": self.log_level,
            "user_agent": self.user_agent,
            "locale": self.locale,
        }

    # -------------------------
    # Крохотные удобства
    # -------------------------
    def effective_log_level(self) -> int:
        """
        Возвращает числовой logging level (если log_level не задан — INFO).
        Удобно для быстрой конфигурации логгера: logging.getLogger().setLevel(opts.effective_log_level()).
        """
        if self.log_level is None:
            return logging.INFO
        return _LOG_LEVELS.get(self.log_level.upper(), logging.INFO)


# Готовый объект по умолчанию: можно импортить как глобальные дефолты
DEFAULT_PARSER_INFRA_OPTIONS = ParserInfraOptions.default()

__all__ = ["ParserInfraOptions", "DEFAULT_PARSER_INFRA_OPTIONS"]