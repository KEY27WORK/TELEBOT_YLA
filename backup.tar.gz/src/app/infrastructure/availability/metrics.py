# app/infrastructure/availability/metrics.py
"""
📈 Prometheus‑метрики для подсистемы Availability.

Экспортируются константы‑метрики:
  • AV_CACHE_HITS     — количество попаданий в кэш AvailabilityReports
  • AV_CACHE_MISSES   — количество промахов кэша
  • AV_REPORT_LATENCY — гистограмма времени сборки отчёта
"""

from prometheus_client import Counter, Histogram

AV_CACHE_HITS = Counter(
    "availability_cache_hits_total",
    "Cache hits for availability reports",
)

AV_CACHE_MISSES = Counter(
    "availability_cache_misses_total",
    "Cache misses for availability reports",
)

AV_REPORT_LATENCY = Histogram(
    "availability_report_seconds",
    "Time to build availability report",
)