# 🎯 app/infrastructure/ai/ai_task_service.py
"""
AITaskService — високорівневі задачі AI: вага, переклад, слогани тощо.
Працює через OpenAIService (клієнт) + PromptService (DTO-промпти).
"""

from __future__ import annotations

import logging
from typing import Dict, Optional

from app.shared.utils.logger import LOG_NAME
from app.domain.ai.task_contracts import IWeightEstimator, ITranslator, ISloganGenerator
from .open_ai_serv import OpenAIService
from .prompt_service import PromptService

logger = logging.getLogger(f"{LOG_NAME}.ai")

DEFAULT_SLOGAN = "YoungLA вайб, твій щоденний драйв 🚀"


class AITaskService(IWeightEstimator, ITranslator, ISloganGenerator):  # 👈 доменные контракты
    def __init__(self, openai: OpenAIService, prompts: PromptService) -> None:
        self._openai = openai
        self._prompts = prompts
        logger.info("✅ AITaskService ініціалізовано")

    # ── Вага ────────────────────────────────────────────────────────────────
    async def estimate_weight_g(self, *, title: str, description: str, image_url: str) -> int:
        """
        Повертає вагу в грамах (int). Безпечна нормалізація + обрізання діапазону.
        """
        prompt = self._prompts.weight(title=title, description=description, image_url=image_url)
        txt = await self._openai.chat_completion(prompt)
        if not txt:
            logger.warning("Порожня відповідь при оцінці ваги — fallback 1000 г")
            return 1000
        try:
            kg = float(txt.strip())
            grams = int(round(max(0.1, min(kg, 5.0)) * 1000))
            return grams
        except ValueError:
            logger.error("Не вдалося розпізнати вагу з відповіді: %r — fallback 1000 г", txt)
            return 1000

    # ── Переклад ───────────────────────────────────────────────────────────
    async def translate_sections(self, *, text: str) -> Dict[str, str]:
        prompt = self._prompts.translation(text=text)
        txt = await self._openai.chat_completion(prompt)
        if not txt:
            return {}

        sections = {"МАТЕРІАЛ": "", "ПОСАДКА": "", "ОПИС": "", "МОДЕЛЬ": ""}
        current: Optional[str] = None
        for line in txt.splitlines():
            line = line.strip()
            for key in list(sections.keys()):
                if line.startswith(f"{key}:"):
                    current = key
                    line = line[len(key) + 1 :].strip()
                    break
            if current and line:
                sections[current] += (line + " ")
        return {k: v.strip() for k, v in sections.items() if v.strip()}

    # ── Слоган ─────────────────────────────────────────────────────────────
    async def generate_slogan(self, *, title: str, description: str) -> str:
        prompt = self._prompts.slogan(title=title, description=description)
        txt = await self._openai.chat_completion(prompt)
        if not txt:
            return DEFAULT_SLOGAN
        # жёсткая пост-валидация (≤10 слов, без кавычек)
        words = txt.replace('"', '').replace("'", "").split()
        cleaned = " ".join(words[:10])
        return cleaned