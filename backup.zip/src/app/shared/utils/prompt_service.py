# app/shared/utils/prompt_service.py
from __future__ import annotations

import json
from enum import Enum
from functools import lru_cache
from pathlib import Path
from typing import Optional, Dict

from app.shared.utils.logger import LOG_NAME
import logging

logger = logging.getLogger(f"{LOG_NAME}.prompts")

class PromptType(str, Enum):
    MUSIC = "music"
    HASHTAGS = "hashtags"
    WEIGHT = "weight"
    CLOTHING_TYPE = "clothing_type"
    TRANSLATION = "translation"
    SLOGAN = "slogan"

class ChartType(str, Enum):
    GENERAL = "general"
    UNIQUE = "unique"
    UNIQUE_GRID = "unique_grid"

class PromptService:
    """
    Ленивый и безопасный сервис для работы с шаблонами:
      • не загружает всё на старте (без краша при отсутствии пары файлов);
      • даёт понятные ошибки ровно на запрошенный шаблон;
      • кэширует загруженные файлы (@lru_cache).
    """

    def __init__(self, prompts_root: Optional[Path] = None, lang: str = "uk") -> None:
        self._root = prompts_root or (Path(__file__).parent.parent / "prompts")
        self._lang = lang

    # ── Публичное API ───────────────────────────────────────────────────────
    def get_prompt(self, prompt_type: PromptType, **kwargs) -> str:
        """
        Вернуть отформатированный текст шаблона для указанного PromptType.
        """
        template = self._load_lang_text(f"{prompt_type.value}.txt", lang=self._lang)
        safe_kwargs = {k: ("" if v is None else v) for k, v in kwargs.items()}
        try:
            return template.format(**safe_kwargs)
        except KeyError as e:
            missing = e.args[0]
            raise ValueError(f"Missing placeholder '{missing}' for prompt '{prompt_type.value}.txt'") from e

    def get_size_chart_prompt(self, chart_type: ChartType) -> str:
        """
        Собирает OCR-промт из текстового шаблона + JSON-примера.
        """
        base = self._load_ocr_file("base.txt")
        example_name = f"example_{chart_type.value}.json"
        try:
            example = json.loads(self._load_ocr_file(example_name))
        except FileNotFoundError:
            raise ValueError(f"OCR example file not found: {example_name}")

        conditions = {
            ChartType.UNIQUE: "Поверни лише JSON і нічого більше...",
            ChartType.GENERAL: "Поверни JSON з масивами значень..."
        }
        prompt = base.format(
            extra_conditions=conditions.get(chart_type, ""),
            example_json=json.dumps(example, indent=4, ensure_ascii=False),
        )
        return prompt

    # ── Приватные загрузчики (ленивые + кэш) ───────────────────────────────
    @lru_cache
    def _load_lang_text(self, fname: str, *, lang: str) -> str:
        p = self._root / lang / fname
        try:
            with open(p, "r", encoding="utf-8") as f:
                text = f.read()
            logger.debug("Loaded prompt file: %s", p)
            return text
        except FileNotFoundError:
            logger.error("Prompt file not found: %s", p)
            raise

    @lru_cache
    def _load_ocr_file(self, fname: str) -> str:
        p = self._root / "ocr" / fname
        try:
            with open(p, "r", encoding="utf-8") as f:
                text = f.read()
            logger.debug("Loaded OCR asset: %s", p)
            return text
        except FileNotFoundError:
            logger.error("OCR asset not found: %s", p)
            raise