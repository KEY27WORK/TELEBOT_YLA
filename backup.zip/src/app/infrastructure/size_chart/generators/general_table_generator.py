from __future__ import annotations

import logging
from typing import List

from app.shared.utils.logger import LOG_NAME
from app.infrastructure.image_generation.font_service import FontService
from app.domain.image_generation.interfaces import FontType, FontLike
from .base_generator import BaseTableGenerator

logger = logging.getLogger(LOG_NAME)


class GeneralTableGenerator(BaseTableGenerator):
    """
    Классическая таблица (размер → параметры).
    Слева — «Розмір», справа — колонки параметров.
    """

    TITLE_FONT_SIZE = 42
    HEADER_FONT_SIZE = 30
    CELL_FONT_SIZE = 28
    ROW_HEIGHT = 60

    def __init__(self, size_chart: dict, output_path: str, font_service: FontService, **kwargs) -> None:
        super().__init__(size_chart, output_path, font_service, **kwargs)

        # колонки справа от «Розмір»
        self.params: List[str] = list(self.parameters_map.keys())
        self.num_columns = max(1, len(self.params) + 1)  # +1 — первый столбец «Розмір»

        self.col_width = max(1, (self.IMG_WIDTH - 2 * self.PADDING) // self.num_columns)
        total_table_height = (len(self.headers) + 1) * self.ROW_HEIGHT
        self.TABLE_START_Y = max(self.PADDING, (self.IMG_HEIGHT - total_table_height) // 2)

        # шрифты (через enum) + возможное даунскейление
        self.title_font: FontLike = self.font_service.get_font(FontType.BOLD, self.TITLE_FONT_SIZE)
        self.header_font: FontLike = self.font_service.get_font(FontType.BOLD, self.HEADER_FONT_SIZE)
        self.cell_font: FontLike = self.font_service.get_font(FontType.MONO, self.CELL_FONT_SIZE)
        self._maybe_downscale_fonts()

    def _maybe_downscale_fonts(self) -> None:
        min_col_for_headers = 90
        if self.col_width < min_col_for_headers:
            factor = max(0.7, self.col_width / float(min_col_for_headers))
            self.title_font = self.font_service.get_font(FontType.BOLD, max(16, int(self.TITLE_FONT_SIZE * factor)))
            self.header_font = self.font_service.get_font(FontType.BOLD, max(12, int(self.HEADER_FONT_SIZE * factor)))
            self.cell_font = self.font_service.get_font(FontType.MONO, max(10, int(self.CELL_FONT_SIZE * factor)))

    def _draw_title(self) -> None:
        self.draw_text_centered(self.title, self.IMG_WIDTH // 2, self.TABLE_START_Y - 60, self.title_font)

    def _draw_table(self) -> None:
        y = self.TABLE_START_Y
        x = self.PADDING

        # шапка
        for col in range(self.num_columns):
            self.draw.rectangle([x, y, x + self.col_width, y + self.ROW_HEIGHT], outline="black", width=2)
            text = "Розмір" if col == 0 else self.params[col - 1]
            self.draw_text_centered(text, x + self.col_width // 2, y + self.ROW_HEIGHT // 2, self.header_font)
            x += self.col_width

        y += self.ROW_HEIGHT

        # строки с данными
        for r in range(len(self.headers)):
            x = self.PADDING
            for col in range(self.num_columns):
                self.draw.rectangle([x, y, x + self.col_width, y + self.ROW_HEIGHT], outline="black", width=2)
                if col == 0:
                    cell_text = self.headers[r] if r < len(self.headers) else ""
                else:
                    param = self.params[col - 1]
                    values = self._get_values(param)  # List[str]
                    cell_text = values[r] if r < len(values) else ""
                self.draw_text_centered(str(cell_text), x + self.col_width // 2, y + self.ROW_HEIGHT // 2, self.cell_font)
                x += self.col_width
            y += self.ROW_HEIGHT

    async def generate(self) -> str:
        self._draw_title()
        self._draw_table()
        logger.info("✅ Таблицю збережено у %s", self.output_path)
        return self.save_png()