# 🏃 app/bot/handlers/product/collection_runner.py
"""
🏃 CollectionRunner — керує паралельною обробкою товарів з колекції.

🔹 Можливості:
    • Обмежує паралелізм через семафор (керований рівень concurrency)
    • Ретраї з експоненційною затримкою для кожного товару (exponential backoff)
    • Троттлить оновлення прогресу, щоб не заспамити UI-редагуваннями
    • Акуратно завершує задачі при `CancelledError` (graceful cancellation)
"""

# 🌐 Зовнішні бібліотеки
from telegram import Update                                             # 📬 Telegram Update (використовується у handler)

# 🔠 Системні імпорти
import asyncio                                                          # 🔄 Асинхронність / таски / семафори
import contextlib                                                       # 🧰 Безпечне подавлення винятків
import logging                                                          # 🧾 Логування подій
import time                                                             # ⏱️ Вимірювання часу для тротлінгу
from typing import Awaitable, Callable, List                            # 🧰 Типи для колбеків та списків

# 🧩 Внутрішні модулі проєкту
from app.bot.handlers.product.product_handler import ProductHandler     # 🛍️ Обробник одного товару (UI‑шар)
from app.bot.services.custom_context import CustomContext               # 🧠 Розширений контекст бота
from app.shared.utils.logger import LOG_NAME                            # 🏷️ Ім'я логера з єдиного централізованого місця


# ==========================
# 🧾 ЛОГЕР
# ==========================
logger = logging.getLogger(LOG_NAME)


# ==========================
# 🏛️ КЛАС RUNNER
# ==========================
class CollectionRunner:
    """
    🏃 Запускає обробку товарів з обмеженням паралелізму, ретраями та тротлінгом прогресу.
    """

    def __init__(
        self,
        product_handler: ProductHandler,
        concurrency: int = 4,
        per_item_retries: int = 2,
        progress_interval_sec: float = 2.5,
    ) -> None:
        """
        ⚙️ Ініціалізує Runner необхідними залежностями та політиками виконання.

        Args:
            product_handler: Обробник одного товару (UI‑шар), який уміє опрацьовувати URL.
            concurrency: Скільки товарів обробляємо одночасно (розмір семафора).
            per_item_retries: Кількість повторних спроб на один URL (включно з першою спробою + N ретраїв).
            progress_interval_sec: Мінімальний інтервал між оновленнями прогресу (сек).
        """
        self._product_handler = product_handler								# 🛍️ Зберігаємо посилання на UI‑обробник товару
        self._sem = asyncio.Semaphore(concurrency)							# 🚦 Семафор лімітує кількість одночасних задач
        self._retries = per_item_retries									# 🔁 Політика кількості ретраїв на товар
        self._progress_interval = progress_interval_sec						# ⏱️ Мінімальний інтервал пушів прогресу

    # ==========================
    # ▶️ ПУБЛІЧНИЙ МЕТОД
    # ==========================
    async def run(
        self,
        update: Update,
        context: CustomContext,
        urls: List[str],
        on_progress: Callable[[int, int], Awaitable[None]],
        is_cancelled: Callable[[], bool],
    ) -> int:
        """
        ▶️ Запускає обробку списку URL з контрольною логікою паралелізму, ретраїв і тротлінгу.

        Args:
            update: Об'єкт Telegram Update (прокидується в product_handler).
            context: Кастомний контекст (дані сесії, кеші, DI).
            urls: Перелік URL товарів для обробки.
            on_progress: Колбек оновлення прогресу: `processed, total`.
            is_cancelled: Функція-перевірка, чи скасована операція зверху (наприклад, користувачем).

        Returns:
            Кількість успішно оброблених товарів.
        """
        processed_count = 0												# 🔢 Лічильник успішно оброблених позицій
        total = len(urls)												# 📦 Загальна кількість робіт
        last_push_time = 0.0											# 🕓 Останній час пушу прогресу (для тротлінгу)

        # --------------------------
        # 🔧 Локальна обробка одного URL
        # --------------------------
        async def _process_one_url(url: str) -> bool:
            if is_cancelled():
                return False											# 🛑 Якщо зверху вже скасували — виходимо без роботи

            async with self._sem:
                delay = 0.6											# ⏳ Початкова затримка для exponential backoff
                for attempt in range(self._retries + 1):
                    try:
                        await self._product_handler.handle_url(
                            update,
                            context,
                            url=url,
                            update_currency=False,							# 💱 Колекція не повинна постійно смикати оновлення курсів
                        )
                        return True									# ✅ Успішно
                    except asyncio.CancelledError:
                        logger.info("🛑 Cancelled item: %s", url)
                        return False									# 🧹 Коректно завершуємо цей айтем
                    except Exception as e:  # noqa: BLE001 (свідомо логимо будь-яку помилку як попередження)
                        logger.warning(
                            "[CollectionRunner] Помилка (%s/%s) на %s: %s",
                            attempt + 1,
                            self._retries + 1,
                            url,
                            e,
                        )
                        if attempt >= self._retries:
                            return False								# ❌ Вичерпали спроби — фіксуємо провал
                        await asyncio.sleep(delay)						# 😴 Backoff перед наступною спробою
                        delay *= 2										# 📈 Експоненційно збільшуємо затримку
                return False											# 🧯 Невдача після циклу спроб

        tasks = [asyncio.create_task(_process_one_url(u)) for u in urls]				# 🧵 Створюємо задачі одразу — виконуємо конкурентно

        try:
            # Обходимо по мірі завершення
            for fut in asyncio.as_completed(tasks):
                success = await fut
                if success:
                    processed_count += 1								# ➕ Рахуємо лише успішні

                # ⏱️ Троттлимо прогрес, щоб не дудосити UI
                now = time.monotonic()
                if (now - last_push_time) >= self._progress_interval or processed_count == total:
                    last_push_time = now
                    try:
                        await on_progress(processed_count, total)				# 📣 Акуратне оновлення прогресу
                    except Exception:  # noqa: BLE001
                        # 🙈 Не зриваємо основний цикл через проблеми з UI‑оновленням
                        pass

        except asyncio.CancelledError:
            logger.info("🛑 CollectionRunner cancelled")
            # 🧹 Акуратно відміняємо інші таски
            for t in tasks:
                t.cancel()
            with contextlib.suppress(Exception):
                await asyncio.gather(*tasks, return_exceptions=True)
            return processed_count										# 🔙 Повертаємо, що встигли обробити

        return processed_count											# ✅ Загальний результат після успішного проходу
