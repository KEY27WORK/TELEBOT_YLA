# ⚙️ Пакет `config`

Цей пакет є **центром управління** усього застосунку. Він відповідає за повний цикл ініціалізації: від завантаження конфігурації до створення та зв'язування всіх сервісів через **DI-контейнер**.

---

## 🗂 Структура

```bash
📦 config/
┣ 📂 setup/              # Компоненти "збірки" (DI, константи, реєстратор)
┃ ┣ 📜 container.py
┃ ┣ 📜 bot_registrar.py
┃ ┗ 📜 constants.py
┣ 📂 yamls/              # Усі YAML-конфіги, розбиті по змісту
┃ ┣ 📂 base/            # Базові налаштування
┃ ┃ ┣ 📜 00_regions.yaml
┃ ┃ ┣ 📜 ...
┃ ┃ ┗ 📜 80_logging.yaml
┃ ┣ 📂 features/        # Опціональні фічі (музика, генерація зображень)
┃ ┃ ┣ 📜 50_music.yaml
┃ ┃ ┗ 📜 95_telegram.yaml
┃ ┣ 📂 providers/       # Тарифи зовнішніх сервісів (доставка)
┃ ┃ ┗ 📜 delivery.yaml
┃ ┗ 📂 local/           # Локальні override-конфіги (не комітяться)
┃   ┗ 📜 99_local.yaml
┣ 📜 config_service.py   # Singleton сервіс читання конфігів
┣ 📜 __init__.py         # Публічний API пакета
┗ 📜 README.md          # Цей файл
```

### Чому префікси `00_… 99_…`?

`ConfigService` завантажує **всі** `*.yaml` рекурсивно з `config/yamls/**` і застосовує **глибоке злиття у лексикографічному порядку шляху**. Завдяки цьому:
- `base/00_*.yaml` закладає основу.
- Далі йдуть інші файли, доповнюючи конфігурацію.
- `local/99_local.yaml` завжди застосовується **останнім** і може безпечно перевизначити будь-який ключ для локальної розробки.

---

## 🔐 Робота з `.env`

Секрети читаються за префіксом із констант: `CONST.LOGIC.ENV_PREFIX` (за замовчуванням `APP_`). Кожна змінна з таким префіксом автоматично перетворюється у вкладений ключ:
- `APP_TELEGRAM_BOT_TOKEN=xxx` → `telegram.bot.token`
- `APP_OPENAI_API_KEY=xxx` → `openai.api.key`

---

## 🧩 Основні компоненти

### **ConfigService** (Singleton)
- Читає `.env` + всі `*.yaml` із `config/yamls/**`.
- Надає універсальний метод `get('a.b.c', default=..., cast=int)` та `reload()`.

### **Container** (DI)
- Ініціалізує всі сервіси у правильному порядку, передаючи залежності через конструктори.

### **BotRegistrar**
- Реєструє команди/хендлери в `telegram.ext.Application`, обгортаючи їх декоратором помилок з контейнера.

---

## 🚀 Приклади використання

#### Отримати доступ до конфігурації:
```python
from app.config import ConfigService

config = ConfigService()
# Отримати токен, який завантажено з .env змінної APP_TELEGRAM_BOT_TOKEN
token = config.get("telegram.bot.token")
# Отримати таймаут з default-значенням та приведенням до int
timeout = config.get("telegram.http.read_timeout_sec", default=30, cast=int)
```

#### Використати контейнер (у `main.py`):
```python
from app.config import ConfigService, Container

config_service = ConfigService()
# Створюємо екземпляр контейнера, який збирає весь додаток
app_container = Container(config_service)

# Тепер можна отримати доступ до будь-якого готового сервісу
link_handler = app_container.link_handler
```

---

## 💾 Файли конфігурації
- **config.yaml** — Основні налаштування: регіони, API, логування, таймаути.
- **delivery.yaml** — Тарифи на доставку.
- **weights.json** — Локальна база даних ваг товарів для розрахунку доставки.
