# ⌨️ Keyboards (Telegram UI layer)

Пакет **`app/bot/ui/keyboards`** отвечает за построение и централизованное хранение всех клавиатур  
(Reply и Inline), используемых ботом.

## 📦 Состав

- `keyboards.py` — фабрики клавиатур (Reply / Inline) на основе констант.  
- `__init__.py` — публичные экспорты для удобного импорта (`Keyboard`, готовые билдеры).

## 🧭 Потоки

- **Reply flow:**  
  Тексты кнопок → `AppConstants.UI.REPLY_BUTTONS` →  
  `Keyboard.build_main_menu()` → `reply_markup` в `update.message.reply_text()`.

- **Inline flow:**  
  Callback-данные → `AppConstants.CALLBACKS.*` →  
  `Keyboard.build_inline_menu()` → `InlineKeyboardMarkup`.

## 🛡️ Принципы

- **SRP:** `keyboards.py` отвечает только за генерацию клавиатур.  
- **Централизация:** все тексты кнопок лежат в `AppConstants.UI.*`.  
- **Типобезопасность:** callback-данные описаны в `CallbackDataFactory`.  
- **Расширяемость:** новые билдеры добавляются без изменения существующих.  

## ➕ Как добавить новую клавиатуру

1. Добавить текст кнопки в `AppConstants.UI.REPLY_BUTTONS` или `INLINE_BUTTONS`.  
2. В `keyboards.py` реализовать метод-билдер:
   ```python
   @staticmethod
   def build_xxx_menu() -> ReplyKeyboardMarkup:
       ...
3.	Экспортировать метод в __init__.py.

## 🧪 Тесты
Рекомендуется проверять:
	•	правильную структуру Reply/Inline клавиатур,
	•	соответствие текстов AppConstants,
	•	корректное формирование callback-данных.