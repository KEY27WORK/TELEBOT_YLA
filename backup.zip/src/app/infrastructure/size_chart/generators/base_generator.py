from __future__ import annotations

"""
Базовый класс генераторов PNG-таблиц.

— Параметризуемая канва (canvas_size, padding)
— Безопасное извлечение Title/Розмір
— Приведение параметров к безопасному виду Dict[str, List[str]]
— Утилиты центрирования текста
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

from PIL import Image, ImageDraw
from app.infrastructure.image_generation.font_service import FontService
from app.domain.image_generation.interfaces import FontLike  # единый тип шрифтов


class BaseTableGenerator(ABC):
    def __init__(
        self,
        size_chart: Mapping[str, object],
        output_path: str,
        font_service: FontService,
        *,
        canvas_size: Tuple[int, int] = (1080, 1920),
        padding: int = 20,
        background: str = "white",
        text_color: str = "black",
    ) -> None:
        # работаем с копией входных данных
        self.size_chart: Dict[str, object] = dict(size_chart or {})
        self.output_path = output_path
        self.font_service = font_service

        self.IMG_WIDTH, self.IMG_HEIGHT = canvas_size
        self.PADDING = int(padding)
        self._bg = background
        self._text = text_color

        # Title (str или [str])
        raw_title = self.size_chart.pop("Title", "Таблиця розмірів")
        if isinstance(raw_title, (list, tuple)) and raw_title:
            self.title: str = str(raw_title[0])
        else:
            self.title = str(raw_title)

        # Заголовки размеров (укр/рус)
        headers_raw = self.size_chart.pop("Розмір", self.size_chart.pop("Размер", []))
        if isinstance(headers_raw, (list, tuple)):
            self.headers: List[str] = [str(x) for x in headers_raw]
        elif headers_raw:
            self.headers = [str(headers_raw)]
        else:
            self.headers = []

        # 🔐 Безопасная карта параметров: Dict[str, List[str]]
        self.parameters_map: Dict[str, List[str]] = self._build_parameters_map(self.size_chart)

        # Канва
        self.image = Image.new("RGB", (self.IMG_WIDTH, self.IMG_HEIGHT), self._bg)
        self.draw = ImageDraw.Draw(self.image)

    # ── превратить "сырые" параметры в безопасную карту ─────────────────
    @staticmethod
    def _build_parameters_map(raw: Mapping[str, object]) -> Dict[str, List[str]]:
        out: Dict[str, List[str]] = {}
        for key, val in raw.items():
            # берём только последовательности, но не строки/байты
            if isinstance(val, Sequence) and not isinstance(val, (str, bytes)):
                out[key] = [str(x) for x in val]
        return out

    def _get_values(self, param: str) -> List[str]:
        """Безопасно вернуть список значений параметра (или пустой список)."""
        return self.parameters_map.get(param, [])

    # ── утилиты рисования ────────────────────────────────────────────────
    def _text_size(self, text: str, font: FontLike) -> Tuple[int, int]:
        """Возвращает (w, h) текста. Приводим bbox Pillow (float) к int и даём стабильный fallback."""
        t = "" if text is None else str(text)
        try:
            bbox = self.draw.textbbox((0, 0), t, font=font)
            return int(bbox[2] - bbox[0]), int(bbox[3] - bbox[1])
        except Exception:
            # fallback: width по textlength, height по метрикам (или по size при недоступности)
            try:
                w = int(self.draw.textlength(t, font=font))  # type: ignore[arg-type]
            except Exception:
                w = len(t) * max(getattr(font, "size", 16) // 2, 6)  # type: ignore[attr-defined]
            try:
                ascent, descent = font.getmetrics()  # type: ignore[attr-defined]
                h = ascent + descent
            except Exception:
                h = getattr(font, "size", 16)  # type: ignore[attr-defined]
            return int(w), int(h)

    def draw_text_centered(
        self,
        text: str,
        x_center: int,
        y_center: int,
        font: FontLike,
        fill: Optional[str] = None,
    ) -> None:
        fill = fill or self._text
        w, h = self._text_size(text, font)
        self.draw.text(
            (int(x_center - w // 2), int(y_center - h // 2)),
            str(text),
            font=font,  # FontLike подходит для Pillow
            fill=fill,
        )

    def save_png(self) -> str:
        self.image.save(self.output_path, "PNG")
        return self.output_path

    # ───────────────────────────
    # 🔌 КОНТРАКТ ДЛЯ НАСЛЕДНИКОВ
    # ───────────────────────────
    @abstractmethod
    async def generate(self) -> str:
        """
        Наследники реализуют полный сценарий отрисовки и сохраняют PNG.
        Должен вернуть абсолютный/относительный путь к сохранённому файлу.
        """
        raise NotImplementedError("Метод generate() должен быть реализован в подклассе.")