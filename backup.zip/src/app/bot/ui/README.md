# 🎨 UI (Telegram Presentation Layer)

Пакет **`app/bot/ui`** реализует слой представления (View) в архитектуре:
он отвечает за всё, что видит пользователь в Telegram — форматирование сообщений,
создание клавиатур, статические тексты и оркестрацию отправки медиа.

---

## 📦 Состав

- `static_messages.py` — централизованное хранилище текстов (кнопки, подписи, уведомления).
- `formatters/` — модуль для HTML-форматирования:
  - `message_formatter.py` — генерация описания товара в HTML.
  - `price_report_formatter.py` — форматирование отчёта по цене.
- `keyboards/` — конструкторы Telegram-клавиатур:
  - `keyboards.py` — reply/inline кнопки на основе `AppConstants.UI.*`.
- `messengers/` — отправка разных типов контента:
  - `availability_messenger.py` — публичные/админские отчёты о наличии.
  - `product_messenger.py` — комплексная отправка карточки товара (фото, описание, цена, музыка, size chart).
  - `size_chart_messenger.py` — отправка таблиц размеров как изображений.
- `__init__.py` — единая точка импорта (`Keyboard`, `MessageFormatter`, `ProductMessenger`, ...).

---

## 🧭 Потоки

- **Product flow:**
  DTO товара → `MessageFormatter` / `PriceReportFormatter` →
  `ProductMessenger.send()` → фото → описание → музыка → size-chart.

- **Availability flow:**
  Данные наличия → `AvailabilityMessenger.format_report()` →
  Telegram (admin/public) → текст + фото (опционально).

- **Size chart flow:**
  HTML/изображение → OCR/генерация таблицы →
  `SizeChartMessenger.send(update, context, images)` → надёжная отправка фото.

---

## 🛡️ Принципы

- **SRP:** каждый подмодуль выполняет ровно одну задачу (formatter / messenger / keyboard).
- **DI:** все зависимости внедряются через конструктор.
- **Надёжность:** фото и альбомы отправляются через `ImageSender` с ретраями и backoff.
- **Без магии:** все тексты и подписи централизованы в `static_messages.py`.
- **Единый parse_mode:** задаётся `AppConstants.UI.DEFAULT_PARSE_MODE`.

---

## ➕ Как добавить новый UI-элемент

1. Если нужен новый **formatter** → создать в `formatters/` файл `xxx_formatter.py`, реализовать метод `format_xxx(dto)`.
2. Если нужен новый **messenger** → создать в `messengers/` файл `xxx_messenger.py` с методом:
   ```python
   async def send(self, update: Update, context: CustomContext, data: Any) -> None:
       ...
   ```
3. Если нужны **кнопки** → добавить константу в `AppConstants.UI`, реализовать билдер в `keyboards.py`.

---

## ⚠️ Ошибки

- Все исключения обрабатываются через `ExceptionHandlerService`.
- Отправка медиа оборачивается в safe-fallback.

---

## 🧪 Тесты

Рекомендуется мокать `python-telegram-bot` и инфраструктурные сервисы.
Юнит-тесты должны проверять:
- корректное форматирование HTML,
- безопасную отправку фото/альбомов,
- отсутствие «магических строк» (всё берётся из `static_messages.py`).