# 🌐 Domain · Web

Контракти для доступу до веб‑сторінок (чиста архітектура).  
Тут **немає** залежностей від Playwright/httpx тощо — лише інтерфейси.

## 📦 Склад
```bash
app/domain/web
├─ __init__.py
└─ interfaces.py   ← IWebClient (контракт клієнта веб‑сторінок)
```

## 🔌 Контракт: `IWebClient`
Інтерфейс, який має реалізувати будь‑яка інфраструктура (Playwright, httpx, Selenium, …).

```python
class IWebClient(Protocol):
    async def startup(self) -> None: ...
    async def shutdown(self) -> None: ...
    async def get_page_content(self, url: str) -> Optional[str]: ...
```

### Поведінка за контрактом
- **`startup()`** — виділення ресурсів (запуск браузера/сесії).
- **`shutdown()`** — коректне звільнення ресурсів.
- **`get_page_content(url)`** — повертає фінальний HTML сторінки або `None` у разі невдачі.
  Реалізація може містити ретраї, антибот‑обхід тощо — це **деталі інфраструктури**.

## 🧰 Приклад інфраструктурної реалізації
В інфраструктурі (`app/infrastructure/web/webdriver_service.py`) реалізовано `WebDriverService`, який:
- працює поверх **Playwright**,
- має явні `startup()/shutdown()`,
- включає **stealth** та **ретраї**,
- реалізує контракт `IWebClient`.

## 🧪 Тестування
Завдяки контракту можна легко підміняти реалізацію у тестах:
```python
class FakeWebClient(IWebClient):
    async def startup(self): pass
    async def shutdown(self): pass
    async def get_page_content(self, url: str) -> Optional[str]:
        return "<html>fixture</html>"
```
Підсуньте `FakeWebClient` у парсер — і тестуйте без реального браузера.

## 🔗 Де використовується
Усі парсери/сервіси, яким потрібен HTML, мають залежати **від `IWebClient`**, а не від конкретного Playwright‑сервісу. Це робить код гнучким і замінним.
