"""
🚚 delivery — інфраструктурні реалізації сервісів доставки.

Публічний API пакета:
• MeestDeliveryService — розрахунок тарифів Meest
"""

from .meest_delivery_service import MeestDeliveryService

__all__ = ["MeestDeliveryService"]