# 🧮 app/bot/handlers/price_calculation_handler.py
"""
🧮 Обробник розрахунку ціни для Telegram.

Оркестрація: URL → парсер (ProductInfo) → PriceInput → IPriceService → форматування → reply.

Принципи:
- 🧩 SRP: лише координація кроків і форматування відповіді для Telegram (без бізнес-логіки).
- 🧷 DIP: усі залежності надходять через конструктор (DI).
- 🛡️ Надійність: централізований ExceptionHandlerService, таймаут на CPU-обчислення, перевірки update.message.
"""

# ==========================
# 🌐 ЗОВНІШНІ БІБЛІОТЕКИ
# ==========================
from telegram import Update  # 🤖 Telegram API типи

# ==========================
# 🔠 СИСТЕМНІ ІМПОРТИ
# ==========================
import asyncio  # 🔄 Асинхронні операції / таймаути
import logging  # 🧾 Логування
from decimal import Decimal  # 💵 Точні гроші (Decimal-only)
from typing import Any, Dict, Optional  # 🧰 Типізація

# ==========================
# 🧩 ВНУТРІШНІ МОДУЛІ ПРОЄКТУ
# ==========================
from app.bot.services.custom_context import CustomContext  # 🧠 Розширений контекст Telegram
from app.bot.ui.formatters.price_report_formatter import PriceReportFormatter  # 🧾 Форматування повідомлення
from app.bot.ui import static_messages as msg  # 🗒️ Статичні UI‑повідомлення
from app.config.config_service import ConfigService  # ⚙️ Доступ до конфігів
from app.config.setup.constants import AppConstants  # 📜 Статичні константи застосунку
from app.domain.currency.interfaces import ICurrencyConverter  # 💱 Контракт конвертера валют
from app.domain.pricing.interfaces import (
    IPriceService,      # ✅ новий мінімалістичний контракт
    PriceInput,         # ✅ DTO входу
    PriceBreakdown,     # ✅ DTO виходу
    Money,              # ✅ Грошовий тип
)
from app.domain.products.entities import ProductInfo, Currency  # 📦 Сутність товару та валюта
from app.errors.exception_handler_service import ExceptionHandlerService  # 🛡️ Центральний обробник помилок
from app.infrastructure.currency.currency_manager import CurrencyManager  # 💱 Менеджер курсів і конвертерів
from app.infrastructure.parsers.parser_factory import ParserFactory  # 🏭 Фабрика парсерів
from app.shared.utils.logger import LOG_NAME  # 🏷️ Ім'я логера
from app.shared.utils.url_parser_service import UrlParserService  # 🔗 Нормалізація URL

# ==========================
# 🧾 ЛОГЕР
# ==========================
logger = logging.getLogger(LOG_NAME)  # 🏷️ Єдине ім'я логера в усьому застосунку


# ==========================
# 🏛️ КЛАС ОБРОБНИКА
# ==========================
class PriceCalculationHandler:
    """
    Координує процес розрахунку ціни і складання повідомлення для Telegram.
    """

    def __init__(
        self,
        *,
        currency_manager: CurrencyManager,
        parser_factory: ParserFactory,
        pricing_service: IPriceService,           # 🔁 було: IPricingService
        config_service: ConfigService,
        constants: AppConstants,
        exception_handler: ExceptionHandlerService,
        url_parser_service: UrlParserService,
        formatter: Optional[PriceReportFormatter] = None,
    ) -> None:
        """Впровадження залежностей через конструктор (DI)."""
        self._currency_manager = currency_manager  # 💱 Оновлення курсів + конвертери
        self._parser_factory = parser_factory  # 🏭 Створення парсерів (товар/колекція)
        self._pricing_service = pricing_service  # 💸 Ядро ціноутворення (CPU-bound, новий контракт)
        self._config = config_service  # ⚙️ Конфігурація застосунку
        self._exception_handler = exception_handler  # 🛡️ Централізований обробник винятків
        self._url_parser = url_parser_service  # 🔗 Нормалізація/валідація URL
        self.const = constants  # 📜 Сталі (timeout-и, коефіцієнти)
        # 🧾 Форматер інжектимо через DI (зручніше для тестів); за замовчуванням створюємо тут
        self._formatter = formatter or PriceReportFormatter()

    # ==========================
    # 🔓 ПУБЛІЧНИЙ МЕТОД
    # ==========================
    async def handle_price_calculation(
        self,
        update: Update,
        context: CustomContext,
        url: str,
    ) -> None:
        """
        Вхідна точка з Telegram: приймає URL, рахує ціну і надсилає відповідь.
        """
        if not update.message:
            return  # 🛡️ Безпека: ігноруємо оновлення без message

        chat_id = update.effective_chat.id if update.effective_chat else "N/A"  # 🆔 Ідентифікатор чату (для логів)
        log_extra = {"chat_id": chat_id, "url": url}  # 🧾 Додаткові поля у логах

        try:
            logger.info("💸 PriceCalc: start", extra=log_extra)  # ▶️ Старт пайплайну

            # 🎛️ UX: коротке службове повідомлення, що йде розрахунок
            try:
                await update.message.reply_text(
                    msg.PRICE_CALC_IN_PROGRESS,
                    parse_mode=getattr(self.const.UI, "DEFAULT_PARSE_MODE", None),
                )
            except Exception:
                # best‑effort — не зриваємо основний флоу, якщо не вдалось
                pass

            message = await self._calculate_and_format(url)  # 🧮 Обчислення + форматування

            await update.message.reply_text(
                message,
                parse_mode=self.const.UI.DEFAULT_PARSE_MODE,  # ✍️ HTML/Markdown режим для UI
            )
            logger.info("💸 PriceCalc: sent", extra=log_extra)  # ✅ Повідомлення відправлено

        except asyncio.CancelledError:
            logger.warning("💸 PriceCalc: cancelled", extra=log_extra)  # ⏹️ Коректна відміна задач — пробрасуємо
            raise
        except Exception as e:  # noqa: BLE001
            logger.exception("💸 PriceCalc: failed", extra=log_extra)  # ❌ Будь-яка інша помилка
            # Централізований хендлер сам подбає про user-friendly повідомлення
            await self._exception_handler.handle(e, update)

    # ==========================
    # 🔧 ВНУТРІШНЯ ОРКЕСТРАЦІЯ
    # ==========================
    async def _calculate_and_format(self, url: str) -> str:
        """
        Оркестрація отримання даних, розрахунку й фінального форматування.
        """
        # 🔄 Актуалізація курсів при потребі
        await self._currency_manager.update_all_rates_if_needed()
        converter: ICurrencyConverter = self._currency_manager.get_converter()  # 💱 Поточний конвертер (для форматера/UI)

        normalized_url = self._url_parser.normalize_url(url)  # 🔗 Нормалізація (регіон/хвости)

        parser = self._parser_factory.create_product_parser(normalized_url)  # 🏭 Створюємо парсер товару
        product_info = await parser.get_product_info()  # 🧾 Отримуємо ProductInfo

        if not self._is_valid_product_info(product_info):
            # 🛑 Жорстка, але безпечна валідація (без залежності від текстів помилок парсера)
            raise ValueError(f"ProductInfo is invalid for url={url!r}: {product_info!r}")

        # 🧾 Будуємо вхідні дані для доменного сервісу (Decimal-only)
        price_input: PriceInput = self._build_price_input(product_info)

        # ⏱️ Таймаут CPU-розрахунку (залишаємо виконання у thread pool)
        timeout_sec = self.const.LOGIC.TIMEOUTS.PRODUCT_PROCESS_SEC

        details: PriceBreakdown = await asyncio.wait_for(
            asyncio.to_thread(
                self._pricing_service.build_quote,  # ✅ новий API домену
                price_input,
            ),
            timeout=timeout_sec,
        )  # ⛳ Обмежуємо тривалість операції

        # 🧾 Форматуємо повідомлення через інжектований форматер
        # NB: якщо форматер очікував старий FullPriceDetails — має бути оновлений під PriceBreakdown.
        message = self._formatter.format_message(product_info, details, price_input, converter)
        logger.debug("💸 PriceCalc: message formatted successfully")  # 🧩 Готово
        return message

    # ==========================
    # 🧭 ПОБУДОВА ВХОДУ ДЛЯ ПРАЙСИНГУ
    # ==========================
    def _build_price_input(self, pi: ProductInfo) -> PriceInput:
        """
        Трансформує ProductInfo + конфіг у строгий PriceInput (Decimal‑only).

        – Валюта результату (target) береться з конфіга: pricing.target_currency (fallback: "UAH").
        – Мапа валют → регіони: pricing.currency_map або константи (fallback: 'us').
        """
        # 🗺️ Регіон за валютою (безпечно читаємо конфіг)
        cfg_map: Dict[str, str] = self._config.get("pricing.currency_map", {}) or {}
        region_key = cfg_map.get(pi.currency.value) or self.const.LOGIC.CURRENCY_MAP.get(pi.currency.value, "us")

        # 🎯 Цільова валюта для репорту
        target_ccy = str(self._config.get("pricing.target_currency", "UAH")).upper()

        # 🧮 Акуратно переводимо у Decimal (без float)
        base_money = Money(amount=Decimal(str(pi.price)), currency=pi.currency.value)
        weight_kg = Decimal(str(pi.weight))

        return PriceInput(
            base_price=base_money,
            weight_kg=weight_kg,
            supplier_region=region_key,
            target_currency=target_ccy,
        )

    # ==========================
    # 🧰 ДОПОМІЖНЕ
    # ==========================
    @staticmethod
    def _is_valid_product_info(pi: Any) -> bool:
        """
        Жорстка, але безпечна валідація ProductInfo без прив'язки до текстів помилок.

        Необхідний мінімум для розрахунку:
        - екземпляр ProductInfo
        - price і weight задані (числа, не NaN, не від'ємні)
        - currency — валідний enum Currency
        - title — непорожній рядок (для звіту користувачу)
        """
        if not isinstance(pi, ProductInfo):
            return False  # ❌ Невірний тип

        try:
            price_ok = (pi.price is not None) and (float(pi.price) >= 0.0)  # 💵 Перевірка ціни
        except (TypeError, ValueError):
            price_ok = False

        try:
            weight_ok = (pi.weight is not None) and (float(pi.weight) >= 0.0)  # ⚖️ Перевірка ваги
        except (TypeError, ValueError):
            weight_ok = False

        currency_ok = isinstance(pi.currency, Currency)  # 💱 Валюта — enum
        title_ok = isinstance(pi.title, str) and pi.title.strip() != ""  # 🏷️ Назва не порожня

        return price_ok and weight_ok and currency_ok and title_ok  # ✅ Мінімальний набір умов
    
# ─────────────────────────────────────────────────────────────────────────────
# 🔓 Публічний API модуля (для Pylance/IDE)
# ─────────────────────────────────────────────────────────────────────────────
__all__ = ["PriceCalculationHandler"]