# 📦 app/infrastructure/music/__init__.py
"""
📦 Ініціалізація пакету infrastructure.music

Експортує:
- MusicSender — оркестратор відправки
- MusicRecommendation — підбір треків через AI
- MusicFileManager — файловий кеш треків
- YtDownloader — завантажувач аудіо з YouTube
"""

from .music_sender import MusicSender
from .music_recommendation import MusicRecommendation
from .music_file_manager import MusicFileManager
from .yt_downloader import YtDownloader

__all__ = [
    "MusicSender",
    "MusicRecommendation",
    "MusicFileManager",
    "YtDownloader",
]