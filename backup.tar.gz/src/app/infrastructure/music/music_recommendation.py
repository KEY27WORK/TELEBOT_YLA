# 🎵 app/infrastructure/music/music_recommendation.py
"""
Добір музики до товарів через AI (реалізація доменного IMusicRecommender).

Головне:
- Публічний контракт: recommend(product: ProductPromptDTO) -> MusicRecommendationResult
- Зворотна сумісність: recommend_legacy(title, description, image_url)
- Модель і температура кладемо у ChatPrompt (не передаємо в chat_completion параметрами)
"""

from __future__ import annotations

import logging
import re
from typing import List, Tuple

from app.config.config_service import ConfigService
from app.domain.ai import ProductPromptDTO
from app.domain.music.interfaces import (
    IMusicRecommender,
    MusicRecommendationResult,
    RecommendedTrack,
)
from app.infrastructure.ai.open_ai_serv import OpenAIService
from app.infrastructure.ai.prompt_service import PromptService  # у stubs може не бути методів
from app.shared.utils.logger import LOG_NAME

logger = logging.getLogger(LOG_NAME)


class MusicRecommendation(IMusicRecommender):
    """Сервіс підбору музики: будує ChatPrompt, питає LLM, парсить список треків."""

    def __init__(
        self,
        openai_service: OpenAIService,
        prompt_service: PromptService,
        config_service: ConfigService,
    ) -> None:
        self._openai = openai_service
        self._prompts = prompt_service
        self._config = config_service
        logger.info("✅ MusicRecommendation ініціалізовано.")

    # ===== Доменно правильний метод (вимога IMusicRecommender) =====
    async def recommend(self, product: ProductPromptDTO) -> MusicRecommendationResult:
        """Згенерувати добірку для продукту (title/description/image_url всередині DTO)."""
        title = product.title or ""
        logger.info("🎼 Підбір музики для: %s", title)

        # Налаштування моделі (строго приводимо типи, щоб не отримати Optional)
        model: str = self._config.get("music.recommendation.model", "gpt-4o-mini") or "gpt-4o-mini"
        temperature: float = self._config.get(  # type: ignore[assignment]
            "music.recommendation.temperature",
            0.7,
            cast=float,
        ) or 0.7

        # Формуємо ChatPrompt для LLM
        # Примітка: у типів PromptService метод може бути не прописаний у stubs → додаємо ignore
        prompt = self._prompts.get_music_prompt(product)  # type: ignore[attr-defined]

        # Кладемо модель/температуру прямо у prompt (так очікує OpenAIService.chat_completion)
        try:
            setattr(prompt, "model", model)
            setattr(prompt, "temperature", float(temperature))
        except Exception:
            logger.debug("ℹ️ Не вдалося виставити model/temperature у ChatPrompt; продовжую.", exc_info=False)

        # Запит до LLM
        raw = await self._openai.chat_completion(prompt)
        if not raw:
            logger.warning("⚠️ AI не повернув відповідь для музичних рекомендацій.")
            return MusicRecommendationResult(tracks=(), raw_text="", model=model)

        tracks = self._parse_response_to_tracks(raw)
        return MusicRecommendationResult(tracks=tuple(tracks), raw_text=raw, model=model)

    # ===== Легаси-обгортка для старих викликів (не входить у контракт) =====
    async def recommend_legacy(self, title: str, description: str, image_url: str) -> MusicRecommendationResult:
        """Сумісність зі старим API. Створює DTO та делегує у recommend()."""
        dto = ProductPromptDTO(title=title or "", description=description or "", image_url=image_url or "")
        return await self.recommend(dto)

    # =========================
    # Helpers (парсинг відповіді)
    # =========================
    def _parse_response_to_tracks(self, text: str) -> List[RecommendedTrack]:
        """
        Видобуває список `RecommendedTrack` з «сирого» тексту моделі.
        Забирає маркери списку і пробує поділити на «Артист — Трек».
        """
        lines = (text or "").splitlines()
        cleaned: List[str] = []
        for line in lines:
            # прибираємо 1), 1., -, • тощо на початку
            s = re.sub(r"^\s*(?:[-•*]|\d+[.)])\s*", "", line).strip()
            if s:
                cleaned.append(s)

        out: List[RecommendedTrack] = []
        seen: set[Tuple[str, str]] = set()

        for s in cleaned:
            artist, title = self._split_artist_title(s)
            key = (artist.lower(), title.lower())
            if key in seen:
                continue
            seen.add(key)
            out.append(RecommendedTrack(artist=artist, title=title))

        return out

    @staticmethod
    def _split_artist_title(s: str) -> Tuple[str, str]:
        """
        Пробуємо «Артист — Трек» з різними тире/дефісами.
        Якщо розділити не вдалося — вся строка вважається назвою треку.
        """
        for sep in (" — ", " – ", " - ", " —", " –", " -"):
            if sep in s:
                a, b = s.split(sep, 1)
                a, b = a.strip(), b.strip()
                if a and b:
                    return a, b
        # fallback: без артиста
        return "", s.strip()