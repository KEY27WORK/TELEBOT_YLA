# 🧩 app/domain/pricing/services.py
"""
Чистий домен прайсингу (Decimal-only).
— Жодного I/O, логів, HTTP — лише математика.
— Всі гроші через Money(Decimal, currency).
— Правила (тарифи/пороги/комісії/знижки) — параметрами сервісу, без «магічних чисел».
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .interfaces import IPriceService, PriceInput, PriceBreakdown, Money
from .rounding import q2, percent
from app.domain.currency.interfaces import IMoneyConverter

# ==========================
# ⚙️ Правила ціноутворення
# ==========================
@dataclass(frozen=True, slots=True)
class PricingRules:
    """
    Всі значення — як строки/Decimal, щоб уникнути float.
    Доставка рахується в UAH (base + per_kg * weight_kg),
    free_threshold_uah — поріг безкоштовної доставки (по базовій ціні, але порівняння в UAH).
    """
    shipping_base_uah: Decimal            # базова складова доставки (UAH)
    shipping_per_kg_uah: Decimal          # доплата за кг (UAH)
    commission_percent: Decimal           # % комісії від (base + shipping)
    discount_percent: Decimal             # % знижки від (base + shipping)
    free_threshold_uah: Decimal           # поріг безкоштовної доставки (UAH)

    @classmethod
    def from_strings(
        cls,
        *,
        shipping_base_uah: str = "0",
        shipping_per_kg_uah: str = "0",
        commission_percent: str = "0",
        discount_percent: str = "0",
        free_threshold_uah: str = "999999999",
    ) -> "PricingRules":
        D = Decimal
        return cls(
            shipping_base_uah=D(shipping_base_uah),
            shipping_per_kg_uah=D(shipping_per_kg_uah),
            commission_percent=D(commission_percent),
            discount_percent=D(discount_percent),
            free_threshold_uah=D(free_threshold_uah),
        )


# ==========================
# 🧠 Сервіс
# ==========================
class PriceService(IPriceService):
    """
    Реалізація IPriceService без жодного I/O.
    Працює лише з:
      — IMoneyConverter (доменний контракт),
      — PricingRules (чіткі правила).
    """

    def __init__(self, converter: IMoneyConverter, rules: PricingRules) -> None:
        self._conv = converter
        self._rules = rules

    # ---------- Публічний метод ----------
    def build_quote(self, data: PriceInput) -> PriceBreakdown:
        tgt = data.target_currency

        # 1) База → target
        base_tgt = self._convert_money(data.base_price, tgt)  # Money

        # 2) Доставка:
        #    2.1) перевіряємо free‑threshold у UAH (порівнюємо базу, сконвертовану в UAH)
        base_uah = self._convert_money(base_tgt, "UAH")  # Money у UAH
        if base_uah.amount >= self._rules.free_threshold_uah:
            shipping_uah = Decimal("0")
        else:
            shipping_uah = q2(self._rules.shipping_base_uah +
                              (self._rules.shipping_per_kg_uah * data.weight_kg))

        shipping_tgt = self._convert_money(Money(shipping_uah, "UAH"), tgt)

        # 3) Комісія (% від base + shipping)
        subtotal_tgt = q2(base_tgt.amount + shipping_tgt.amount)
        commission_tgt = q2(subtotal_tgt * percent(self._rules.commission_percent))

        # 4) Знижка (% від base + shipping)
        discount_tgt = q2(subtotal_tgt * percent(self._rules.discount_percent))

        # 5) Підсумки
        total_before = q2(subtotal_tgt + commission_tgt - discount_tgt)
        total_tgt = q2(total_before)

        return PriceBreakdown(
            base_converted=Money(q2(base_tgt.amount), tgt),
            shipping=Money(q2(shipping_tgt.amount), tgt),
            commission=Money(commission_tgt, tgt),
            discount=Money(discount_tgt, tgt),
            total_before_round=Money(total_before, tgt),
            total=Money(total_tgt, tgt),
        )

    # ---------- Внутрішні помічники ----------
    def _convert_money(self, money: Money, to_currency: str) -> Money:
        """
        Підтримує 2 форми конвертера:
          1) convert(Money, to: str) -> Money
          2) convert(amount: Decimal|float, from: str, to: str) -> Decimal|float
        """
        # Уже в потрібній валюті
        if money.currency == to_currency:
            return Money(q2(money.amount), to_currency)

        # Вариант 1: Money -> Money
        try:
            converted = self._conv.convert(money, to_currency)  # type: ignore[attr-defined]
            if isinstance(converted, Money):
                return Money(q2(converted.amount), converted.currency)  # OK
        except TypeError:
            pass  # попробуем вариант 2

        # Вариант 2: scalar -> scalar
        amount = money.amount
        # На всякий случай поддержим float‑конвертеры — приведём в Decimal потом
        converted_amount = self._conv.convert(amount, money.currency, to_currency)  # type: ignore[arg-type]
        if not isinstance(converted_amount, Decimal):
            converted_amount = Decimal(str(converted_amount))
        return Money(q2(converted_amount), to_currency)