# ⌨️ app/bot/ui/keyboards/keyboards.py
"""
⌨️ keyboards.py — фабрика клавіатур Telegram-бота.

🔹 Генерує:
   • головне меню (`main_menu`);
   • inline-меню для роботи з валютами (`currency_menu`);
   • меню допомоги (`help_menu`).

⚙️ Принципи:
   • SRP — тільки побудова клавіатур;
   • DI — тексти/колбеки приходять через `AppConstants`;
   • Кешування — щоб не створювати однакові об’єкти щоразу.
"""

# 🌐 Зовнішні бібліотеки
from telegram import (  # type: ignore
    ReplyKeyboardMarkup,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

# 🔠 Системні імпорти
from typing import Optional
import logging

# 🧩 Внутрішні модулі проєкту
from app.config.setup.constants import AppConstants, CONST
from app.shared.utils.logger import LOG_NAME


# ==========================
# 🧾 ЛОГЕР
# ==========================
logger = logging.getLogger(LOG_NAME)													# 🧾 Ініціалізуємо іменований логер для UI


# ==========================
# 🏛️ ФАБРИКА КЛАВІАТУР
# ==========================
class Keyboard:
    """
    🎛️ Інкапсулює побудову всіх клавіатур бота.

    Підтримує два режими використання:
      1) DI‑режим: створити екземпляр `Keyboard(constants)` і викликати методи.
      2) Backward‑сумісність: використовувати статичні методи, як раніше
         (`Keyboard.main_menu()`, `Keyboard.currency_menu()`, `Keyboard.help_menu()`),
         вони всередині інстанціюють клас із глобальним `CONST`.
    """

    def __init__(self, constants: AppConstants) -> None:
        """
        Args:
            constants: Набір UI/Callback констант (інʼєкція через DI).
        """
        self.const = constants														# 🧩 Зберігаємо посилання на константи інтерфейсу
        # Просте кешування вже зібраних розкладок (уникнення повторного створення)
        self._cache_main: Optional[ReplyKeyboardMarkup] = None					# 🧠 Кеш головного меню
        self._cache_currency: Optional[InlineKeyboardMarkup] = None				# 🧠 Кеш меню валют
        self._cache_help: Optional[InlineKeyboardMarkup] = None					# 🧠 Кеш меню допомоги

    # ==============================
    # 🧭 ГОЛОВНЕ МЕНЮ
    # ==============================
    def build_main_menu(self) -> ReplyKeyboardMarkup:
        """
        📋 Генерує головне меню бота на базі констант (з кешуванням).

        Returns:
            ReplyKeyboardMarkup: готова клавіатура з головними діями.
        """
        if self._cache_main is not None:
            return self._cache_main												# 🚀 Повертаємо з кешу, якщо вже зібрано

        kb = self.const.UI.REPLY_BUTTONS											# 🔤 Зручний псевдонім для текстових кнопок

        keyboard = [
            [kb.INSERT_LINKS, kb.MY_ORDERS],										# 🧰 Основні дії
            [kb.COLLECTION_MODE, kb.SIZE_CHART_MODE],							# 📚 Режими парсингу/розмірних таблиць
            [kb.CURRENCY, kb.HELP],												# 💱 Валюти та 🆘 допомога
            [kb.PRICE_CALC_MODE, kb.REGION_AVAILABILITY],						# 💸 Калькулятор та 🌍 наявність
            [kb.DISABLE_MODE],													# ❌ Вихід/вимкнення режиму
        ]

        self._cache_main = ReplyKeyboardMarkup(
            keyboard=keyboard,
            resize_keyboard=True,												# 📱 Компактні кнопки під екран користувача
            one_time_keyboard=False,											# ♻️ Залишати клавіатуру після натискання
            input_field_placeholder=getattr(self.const.UI, "REPLY_PLACEHOLDER", None) or "",	# 📝 Плейсхолдер інпуту
        )
        return self._cache_main													# ✅ Повертаємо зібрану клавіатуру й зберігаємо в кеші

    # ==============================
    # 💱 МЕНЮ КУРСІВ ВАЛЮТ
    # ==============================
    def build_currency_menu(self) -> InlineKeyboardMarkup:
        """
        💱 Генерує меню для керування курсом валют (з кешуванням).

        Returns:
            InlineKeyboardMarkup: інлайн-клавіатура з діями над курсами.
        """
        if self._cache_currency is not None:
            return self._cache_currency											# 🚀 Повертаємо з кешу, якщо вже зібрано

        ui = self.const.UI.INLINE_BUTTONS										# 🔤 Тексти для інлайн-кнопок
        cb = self.const.CALLBACKS												# 🧲 Будівники callback_data

        keyboard = [
            [
                InlineKeyboardButton(
                    text=ui.SHOW_RATE,
                    callback_data=cb.CURRENCY_SHOW_RATE.build(),
                )
            ],
            [
                InlineKeyboardButton(
                    text=ui.SET_RATE,
                    callback_data=cb.CURRENCY_SET_RATE.build(),
                )
            ],
        ]
        self._cache_currency = InlineKeyboardMarkup(keyboard)
        return self._cache_currency												# ✅ Кешуємо та повертаємо

    # ==============================
    # 🆘 МЕНЮ ДОПОМОГИ
    # ==============================
    def build_help_menu(self) -> InlineKeyboardMarkup:
        """
        🆘 Генерує меню допомоги (з кешуванням).

        Returns:
            InlineKeyboardMarkup: інлайн-клавіатура з посиланнями на довідку.
        """
        if self._cache_help is not None:
            return self._cache_help												# 🚀 Повертаємо з кешу, якщо вже зібрано

        ui = self.const.UI.INLINE_BUTTONS										# 🔤 Тексти для інлайн-кнопок
        cb = self.const.CALLBACKS												# 🧲 Будівники callback_data

        keyboard = [
            [InlineKeyboardButton(text=ui.HELP_FAQ,    callback_data=cb.HELP_SHOW_FAQ.build())],
            [InlineKeyboardButton(text=ui.HELP_USAGE,  callback_data=cb.HELP_SHOW_USAGE.build())],
            [InlineKeyboardButton(text=ui.HELP_SUPPORT, callback_data=cb.HELP_SHOW_SUPPORT.build())],
        ]
        self._cache_help = InlineKeyboardMarkup(keyboard)
        return self._cache_help													# ✅ Кешуємо та повертаємо

    # ==============================
    # 🔁 BACKWARD‑СУМІСНІ ОБГОРТКИ
    # ==============================
    @staticmethod
    def main_menu() -> ReplyKeyboardMarkup:
        """Backward‑сумісний статичний конструктор."""
        return Keyboard(CONST).build_main_menu()									# 🔙 Для сумісності зі старим API

    @staticmethod
    def currency_menu() -> InlineKeyboardMarkup:
        """Backward‑сумісний статичний конструктор inline‑меню валют."""
        return Keyboard(CONST).build_currency_menu()								# 🔙 Для сумісності зі старим API

    @staticmethod
    def help_menu() -> InlineKeyboardMarkup:
        """Backward‑сумісний статичний конструктор inline‑меню допомоги."""
        return Keyboard(CONST).build_help_menu()									# 🔙 Для сумісності зі старим API
