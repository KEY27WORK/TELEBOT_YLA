# 📜 app/errors/strategies.py
"""
Стратегии преобразования ошибок сторонних библиотек в доменные AppError.
Добавляйте новые стратегии — не меняя ExceptionHandlerService.
"""

from __future__ import annotations

from typing import Optional, Protocol

# Внешние импорты (могут быть опциональными в рантайме — поэтому try/except желательно снаружи DI)
import httpx
import openai
from telegram.error import RetryAfter, TelegramError

from .custom_errors import AppError, AIError, NetworkRequestError
from app.bot.ui import static_messages as msg


class IErrorHandlingStrategy(Protocol):
    """Контракт стратегии обработки ошибок."""
    def handle(self, error: Exception) -> Optional[AppError]:
        """Вернуть AppError, если распознали ошибку; иначе None."""
        ...


class OpenAIErrorStrategy(IErrorHandlingStrategy):
    def handle(self, error: Exception) -> Optional[AppError]:
        # NB: Имена исключений OpenAI SDK зависят от версии. Эти два — самые частые иерархические.
        if isinstance(error, openai.RateLimitError):
            return AIError(msg.ERROR_AI_RATE_LIMIT, details=str(error), model=getattr(error, "model", None))
        if isinstance(error, openai.OpenAIError):
            return AIError(msg.ERROR_AI_GENERAL, details=str(error), model=getattr(error, "model", None))
        return None


class HttpxErrorStrategy(IErrorHandlingStrategy):
    def handle(self, error: Exception) -> Optional[AppError]:
        if isinstance(error, (httpx.ReadTimeout, httpx.ConnectTimeout)):
            url = str(getattr(getattr(error, "request", None), "url", "N/A"))
            return NetworkRequestError(msg.ERROR_HTTP_TIMEOUT, url=url, details=str(error))

        if isinstance(error, httpx.ConnectError):
            url = str(getattr(getattr(error, "request", None), "url", "N/A"))
            return NetworkRequestError(msg.ERROR_HTTP_CONNECTION, url=url, details=str(error))

        if isinstance(error, httpx.HTTPStatusError):
            url = str(getattr(getattr(error, "request", None), "url", "N/A"))
            status = getattr(getattr(error, "response", None), "status_code", None)
            return NetworkRequestError(
                msg.ERROR_HTTP_STATUS.format(status_code=status),
                url=url,
                status_code=status,
                details=str(error),
            )

        return None


class TelegramErrorStrategy(IErrorHandlingStrategy):
    def handle(self, error: Exception) -> Optional[AppError]:
        if isinstance(error, RetryAfter):
            secs = int(getattr(error, "retry_after", 1))
            return NetworkRequestError(
                msg.ERROR_TELEGRAM_RETRY_AFTER.format(seconds=secs),
                details=str(error),
                retry_after_s=secs,
            )
        if isinstance(error, TelegramError):
            # общее сетевое в Telegram
            return NetworkRequestError(msg.ERROR_TELEGRAM_GENERAL, details=str(error))
        return None


# Пример: сюда же можно добавить Playwright стратегию при необходимости.
# from playwright.async_api import Error as PlaywrightError, TimeoutError as PlaywrightTimeout
# class PlaywrightErrorStrategy(IErrorHandlingStrategy): ...