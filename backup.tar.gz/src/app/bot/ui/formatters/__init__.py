# 🧩 app/bot/ui/formatters/__init__.py
"""
🧩 __init__.py — Публічний API підпакета *formatters* для форматування повідомлень перед відправкою в Telegram.

🔹 Експортує зручні форматери:
    • `MessageFormatter` — збірка тексту/медіа в єдину структуровану відповідь
    • `PriceReportFormatter` — генерація цінових звітів (вартість, націнка, прибуток)

Використання (зовнішнє API):
    from app.bot.ui import MessageFormatter, PriceReportFormatter
"""

# 🧩 Внутрішні модулі проєкту
from .message_formatter import MessageFormatter							# 🧾 Форматування карток/повідомлень
from .price_report_formatter import PriceReportFormatter					# 💸 Форматування звітів по цінах


# ================================
# 📦 ПУБЛІЧНИЙ API ПАКЕТА
# ================================
__all__ = [
    "MessageFormatter",											# Експортувати базовий форматер повідомлень
    "PriceReportFormatter",										# Експортувати форматер цінових звітів
]