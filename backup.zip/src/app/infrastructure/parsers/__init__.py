"""
🧠 Модуль `parsers` — логіка парсингу сторінок сайту YoungLA.

📌 Містить:
– Оркестратор повного парсингу товару (`BaseParser`)
– Екстрактор даних із DOM (`HtmlDataExtractor`)
– Фабрику та адаптер (`ParserFactory`, `ParserFactoryAdapter`)
– Парсери колекцій та пошуку (`UniversalCollectionParser`, `ProductSearchResolver`)
– Інфраструктурні опції (`ParserInfraOptions`)

⚙️ Інкапсулює складність витягування даних зі сторінок.
"""

# 🏗️ Основні класи
from .base_parser import BaseParser
from .html_data_extractor import HtmlDataExtractor
from .parser_factory import ParserFactory, ParserInfraOptions

# 📦 Адаптер фабрики під доменні контракти
from .factory_adapter import ParserFactoryAdapter

# 📚 Парсери колекцій
from .collections.universal_collection_parser import UniversalCollectionParser

# 🔎 Пошук
from .product_search.search_resolver import ProductSearchResolver

# 🧾 Контракти доменно-чистої фабрики
from .contracts import IParserFactory

__all__ = [
    "BaseParser",
    "HtmlDataExtractor",
    "ParserFactory",
    "ParserInfraOptions",
    "ParserFactoryAdapter",
    "UniversalCollectionParser",
    "ProductSearchResolver",
    "IParserFactory",
]